const $ = s => document.querySelector(s);
const esc = s => String(s == null ? '' : s).replace(/[&<>"]/g, c => ({'&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;'}[c]));
const money = n => n ? '$' + Number(n).toLocaleString(undefined, {minimumFractionDigits: 2, maximumFractionDigits: 2}) : '';
let clip = null, cfg = {};

const LAYER = {jsonld: 'the page’s own product data', microdata: 'page markup', meta: 'share tags', spec: 'the spec table', page: 'the visible page'};

function render(payload){
  const m = $('#main');
  if (!payload){ m.innerHTML = `<div class="empty"><span class="spin"></span>Reading the page…</div>`; return; }
  if (payload.error){ clip = null; $('#send').disabled = true; m.innerHTML = `<div class="note bad"><b>Could not read this page</b>${esc(payload.error)}</div>`; return; }
  clip = payload.clip;
  $('#send').disabled = false;
  const missing = clip.missing || [];
  const srcOf = k => clip.source?.[k] ? LAYER[clip.source[k]] || clip.source[k] : '';
  m.innerHTML = `
    <div class="row">
      ${clip.images?.[0] ? `<img class="thumb" src="${esc(clip.images[0])}" alt="">` : `<div class="thumb"></div>`}
      <div>
        <h1>${esc(clip.title || 'Untitled product')}</h1>
        <div class="meta">${[clip.brand, clip.sku && 'SKU ' + clip.sku, clip.vendor].filter(Boolean).map(esc).join(' · ')}</div>
        <div class="meta">${[clip.finish, clip.dims, clip.stock].filter(Boolean).map(esc).join(' · ')}</div>
        ${clip.price ? `<div class="price">${money(clip.price)}</div>` : ''}
      </div>
    </div>
    <div class="fields">
      <div><label>Project</label><select id="f-proj">${(cfg.projects || []).map(p => `<option value="${esc(p.id)}" ${cfg.lastProject === p.id ? 'selected' : ''}>${esc(p.name)}</option>`).join('') || '<option value="">Sign in on the board first</option>'}</select></div>
      <div class="two">
        <div><label>Room</label><input id="f-room" list="rooms" value="${esc(cfg.lastRoom || '')}" placeholder="Primary bath"><datalist id="rooms">${(cfg.rooms || []).map(r => `<option value="${esc(r)}">`).join('')}</datalist></div>
        <div><label>FM group</label><input id="f-fm" value="${esc(cfg.lastFM || '')}" placeholder="FM12"></div>
      </div>
      <div class="two">
        <div><label>Qty</label><input id="f-qty" type="number" min="1" step="1" value="1"></div>
        <div><label>Needed on site</label><input id="f-need" type="date" value=""></div>
      </div>
    </div>
    ${missing.length ? `<div class="note warn"><b>Not on the page: ${esc(missing.join(', '))}</b>These stay blank on the record rather than being guessed. The board will flag them.</div>` : ''}
    ${clip.docs?.length ? `<div class="note"><b>${clip.docs.length} document${clip.docs.length === 1 ? '' : 's'} found</b>${clip.docs.map(d => esc(d.name)).join(' · ')}</div>` : ''}
    ${clip.leadDays ? `<div class="note"><b>Lead time read as ${clip.leadDays} days</b>Taken from the far end of the range the page quotes.</div>` : ''}
    <div class="src">Read from ${esc([...new Set(Object.values(clip.source || {}))].map(l => LAYER[l] || l).join(', ') || 'the visible page')}.${clip.sku ? ` SKU came from <code>${esc(srcOf('sku'))}</code>.` : ''}</div>`;
}

async function load(){
  cfg = await chrome.storage.local.get(['endpoint', 'token', 'projects', 'rooms', 'lastProject', 'lastRoom', 'lastFM']);
  chrome.runtime.sendMessage({type: 'run'});
  const existing = await chrome.runtime.sendMessage({type: 'get'}).catch(() => null);
  if (existing && Date.now() - existing.at < 4000) render(existing);
}
chrome.runtime.onMessage.addListener(msg => { if (msg.type === 'clipped') render(msg.payload); });

$('#again').onclick = () => { render(null); chrome.runtime.sendMessage({type: 'run'}); };

$('#send').onclick = async () => {
  if (!clip) return;
  const btn = $('#send'); btn.disabled = true; btn.textContent = 'Sending…';
  const body = {
    clip,
    projectId: $('#f-proj')?.value || '',
    room: $('#f-room')?.value || '',
    fm: $('#f-fm')?.value || '',
    qty: Number($('#f-qty')?.value || 1),
    needOnSite: $('#f-need')?.value || '',
  };
  await chrome.storage.local.set({lastProject: body.projectId, lastRoom: body.room, lastFM: body.fm});
  const endpoint = cfg.endpoint || 'https://smartdesigns.netlify.app/api/clip';
  try {
    const r = await fetch(endpoint, {
      method: 'POST',
      headers: Object.assign({'content-type': 'application/json'}, cfg.token ? {authorization: 'Bearer ' + cfg.token} : {}),
      body: JSON.stringify(body),
    });
    const j = await r.json().catch(() => ({}));
    if (!r.ok) throw new Error(j.error || `HTTP ${r.status}`);
    btn.textContent = 'On the board ✓';
    setTimeout(() => window.close(), 800);
  } catch (e){
    btn.disabled = false; btn.textContent = 'Send to the board';
    $('#main').insertAdjacentHTML('beforeend', `<div class="note bad"><b>It did not reach the board</b>${esc(e.message)}. Set the board address and your token in the extension options, or copy the link into the board by hand.</div>`);
  }
};

load();
