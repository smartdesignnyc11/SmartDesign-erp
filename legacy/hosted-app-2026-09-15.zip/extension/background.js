// The extension's own worker. It runs the reader on the raw capture, so the parsing lives in one
// tested file rather than being retyped inside the page, and it holds the last capture for the popup.
import { fromJsonLd, fromMeta, fromItemprop, fromSpecTable, docsFrom, mergeCapture, num, clean } from './lib/extract.mjs';

let last = null;

function read(capture){
  const parts = {
    jsonld: fromJsonLd(capture.jsonld),
    meta: fromMeta(capture.metas),
    microdata: fromItemprop(capture.props),
    spec: fromSpecTable(capture.pairs),
    page: {title: clean(capture.h1 || capture.title), price: num(capture.priceText), images: capture.images, docs: docsFrom(capture.links)},
  };
  const out = mergeCapture(parts, capture.url, capture.text);
  if (capture.selection && capture.selection.length > 20 && !out.desc) out.desc = capture.selection;
  return out;
}

chrome.runtime.onMessage.addListener((msg, sender, reply) => {
  if (msg.type === 'capture'){
    try { last = {clip: read(msg.capture), at: Date.now(), tabId: sender.tab?.id}; }
    catch (e){ last = {error: String(e && e.message || e), at: Date.now()}; }
    chrome.runtime.sendMessage({type: 'clipped', payload: last}).catch(() => {});
    return;
  }
  if (msg.type === 'get'){ reply(last); return true; }
  if (msg.type === 'run'){
    chrome.tabs.query({active: true, currentWindow: true}, tabs => {
      const t = tabs[0]; if (!t) return;
      chrome.scripting.executeScript({target: {tabId: t.id}, files: ['content.js']}).catch(e => {
        chrome.runtime.sendMessage({type: 'clipped', payload: {error: 'This page will not allow the clipper to read it — a Chrome settings or store page, usually. Open the vendor page itself.'}}).catch(() => {});
      });
    });
    return;
  }
});

chrome.runtime.onInstalled.addListener(() => {
  chrome.contextMenus.create({id: 'sdp-clip', title: 'Clip to SmartDesigns', contexts: ['page', 'selection', 'image', 'link']});
});
chrome.contextMenus.onClicked.addListener((info, tab) => {
  if (info.menuItemId === 'sdp-clip' && tab?.id) chrome.scripting.executeScript({target: {tabId: tab.id}, files: ['content.js']}).catch(() => {});
});
