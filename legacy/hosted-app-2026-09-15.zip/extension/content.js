// Runs inside the vendor's page, on demand, when someone clicks the toolbar button.
//
// It reads the page the person already has open. That is the whole reason this works where a server
// does not: Ferguson, Wayfair and Build.com will refuse a request from a data centre, and they will
// serve the same page happily to the browser of the designer who is looking at it. No crawling, no
// background collection — one page, one click, on purpose.

(() => {
  const T = s => String(s == null ? '' : s).replace(/\s+/g, ' ').trim();

  const jsonld = [...document.querySelectorAll('script[type="application/ld+json"]')].map(s => s.textContent).filter(Boolean).slice(0, 30);

  const metas = [...document.querySelectorAll('meta[property],meta[name]')]
    .map(m => ({property: m.getAttribute('property') || '', name: m.getAttribute('name') || '', content: m.getAttribute('content') || ''}))
    .filter(m => m.content);

  const props = [...document.querySelectorAll('[itemprop]')].slice(0, 400).map(el => ({
    prop: el.getAttribute('itemprop'),
    value: el.getAttribute('content') || el.getAttribute('datetime') || el.getAttribute('href') || T(el.textContent).slice(0, 200),
  }));

  // Spec tables come in two shapes on nearly every site: <tr><th>k</th><td>v</td></tr>, and <dl><dt>k</dt><dd>v</dd>.
  const pairs = [];
  document.querySelectorAll('table tr').forEach(tr => {
    const c = tr.children;
    if (c.length === 2) pairs.push([T(c[0].textContent), T(c[1].textContent)]);
  });
  document.querySelectorAll('dl').forEach(dl => {
    const kids = [...dl.children];
    for (let i = 0; i < kids.length - 1; i++){
      if (kids[i].tagName === 'DT' && kids[i + 1].tagName === 'DD') pairs.push([T(kids[i].textContent), T(kids[i + 1].textContent)]);
    }
  });
  // and the label/value div pattern, which is everywhere and worth one cheap pass
  document.querySelectorAll('li,div').forEach(el => {
    if (el.children.length !== 2) return;
    const k = T(el.children[0].textContent), v = T(el.children[1].textContent);
    if (k && v && k.length < 40 && v.length < 120 && /:$|^(sku|model|finish|colou?r|dimensions|size|brand|lead)/i.test(k)) pairs.push([k, v]);
  });

  const links = [...document.querySelectorAll('a[href]')].slice(0, 600)
    .map(a => ({href: a.href, text: T(a.textContent).slice(0, 80)}))
    .filter(l => /\.pdf(\?|$)/i.test(l.href) || /spec|tear|install|submittal|cut ?sheet|manual|instruction/i.test(l.text));

  // Images: prefer what the page itself considers the hero, then anything large enough to be a product shot.
  const imgs = [...document.querySelectorAll('img')]
    .filter(i => (i.naturalWidth || i.width || 0) >= 300 && (i.naturalHeight || i.height || 0) >= 300)
    .sort((a, b) => (b.naturalWidth || 0) * (b.naturalHeight || 0) - (a.naturalWidth || 0) * (a.naturalHeight || 0))
    .map(i => i.currentSrc || i.src).filter(Boolean).slice(0, 6);

  const h1 = T(document.querySelector('h1')?.textContent || '');
  const bodyText = T(document.body?.innerText || '').slice(0, 12000);
  const priceEl = [...document.querySelectorAll('[class*="price" i],[data-testid*="price" i],[id*="price" i]')]
    .map(e => T(e.textContent)).find(t => /^\$?\s?[\d,]+(\.\d{2})?$/.test(t) || /^\$\s?[\d,]+/.test(t)) || '';

  const capture = {
    url: location.href, jsonld, metas, props, pairs, links, images: imgs,
    h1, priceText: priceEl, title: document.title, text: bodyText,
    selection: T(window.getSelection?.().toString() || '').slice(0, 500),
  };

  chrome.runtime.sendMessage({type: 'capture', capture});
})();
