const $ = s => document.querySelector(s);
chrome.storage.local.get(['endpoint', 'token']).then(c => { $('#endpoint').value = c.endpoint || ''; $('#token').value = c.token || ''; });
$('#save').onclick = async () => {
  await chrome.storage.local.set({endpoint: $('#endpoint').value.trim(), token: $('#token').value.trim()});
  $('#done').textContent = 'Saved';
  setTimeout(() => { $('#done').textContent = ''; }, 1600);
};
