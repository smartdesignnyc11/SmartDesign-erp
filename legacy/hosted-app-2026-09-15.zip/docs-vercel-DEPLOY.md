# SmartDesigns Projects — hosted app: setup (about 30 minutes, once)

What you get: one shared database for the whole team, sign-in with email + password, a link that installs on iPhone as an app (Add to Home Screen), live updates between phones and desktops, photos stored in the cloud, and the assistant working everywhere.

You will create two free accounts and paste three values into one file. I do the rest.

## 1. Supabase (database, sign-in, files) — 10 min

1. Go to supabase.com → **New project**. Name: `smartdesigns`. Region: **US East**. Set a database password (save it in your password manager; you won't need it day-to-day).
2. When the project is ready: left menu **SQL Editor** → **New query** → paste the whole of `supabase/schema.sql` → **Run**. It should say "Success". (This creates the tables, the money-stripping view for field roles, and the file bucket.)
3. Left menu **Authentication → Users → Add user → Create new user**. Add yourself first: your email, a password, and tick **Auto confirm**. Then add each team member the same way (Alan, Chen, Angel, Sarah…). They can change their password later with "Forgot password".
4. Left menu **Project Settings → API**. Copy two values: **Project URL** and the **anon public** key.
5. Authentication → **URL Configuration**: set *Site URL* to your Vercel address once you have it (step 2.4), so sign-in links and password resets come back to the app.

## 2. Vercel (hosting) — 10 min

1. Push this folder to a GitHub repo (private is fine), or use the Vercel CLI (`npx vercel`) from this folder.
2. vercel.com → **Add New → Project** → import the repo. Framework preset: **Other**. Output directory: `public`. Deploy.
3. **Settings → Environment Variables**: add `ANTHROPIC_API_KEY` = your Anthropic key (console.anthropic.com). This is what powers the Assistant, meeting intake and the rest; it never reaches the browser.
4. Note the app address, e.g. `https://smartdesigns.vercel.app`. (Add a custom domain like `app.smartdesign.nyc` under Settings → Domains whenever you like.)

## 3. Connect the two — 2 min

Edit `public/config.js` (copy from `config.example.js`):

```js
window.SDP_CONFIG = {
  appName: 'SmartDesigns Projects',
  supabaseUrl: 'https://xxxx.supabase.co',   // from step 1.4
  supabaseAnonKey: 'eyJ…',                    // from step 1.4 (anon key — public, safe in the page)
  workspace: 'default',
  aiUrl: '/api/ai'
};
```

Commit and push (or `npx vercel --prod`). Done.

## 4. First sign-in (you) — 3 min

1. Open the app address, sign in with your email. The first office sign-in seeds the demo data (121 State Street etc.) into the shared database so everyone sees the same thing. To start clean later: Settings → **Erase this device's copy** is local only; ask me for a "wipe workspace" SQL when you're ready to go live with real projects.
2. **Settings → Team accounts**: for each person, set their **role** (Foreman, Crew, Project manager, Coordinator, Designer…) and pick **which person in the app they are** (Angel → Angel). Roles come from here from now on — the app's own user list follows it.
3. Field roles (foreman, crew, driver, client) never receive money: the server strips rates, prices, budgets, invoices and bills before the data leaves the database, and restores them when the field saves something back.

## 5. Put it on phones — 1 min each

iPhone: open the address in **Safari** → Share → **Add to Home Screen**. It opens full-screen with the S icon, remembers the sign-in, and works with a weak signal (saves sync when back online). Android: Chrome shows an "Install app" banner.

## Day-to-day

- Updates: I push new builds; phones pick them up on next open (no store review).
- Adding a person: Supabase → Authentication → Add user, then set their role in Settings → Team accounts.
- Removing a person: Supabase → Authentication → delete the user. Their history stays.
- Backups: Supabase keeps daily backups on the free tier for 7 days; Pro ($25/mo) for 30 days and no pausing after inactivity — switch to Pro before the team relies on it.

## What's in this folder

```
public/            the app (index.html + app.js built from the prototype, cloud.js, config.js, sw.js, manifest, icons)
api/ai.js          Vercel function: Assistant calls go through here with the server-side key
supabase/schema.sql database, roles, money stripping, file storage rules
build.py           rebuilds public/ from the prototype sources
test/              Playwright tests against a mock server (cloud_test.py) — sign-in, sync, realtime, field-role stripping/restore
```

## Known limits (milestone 1)

- Data is stored as one row per collection (company, clients, purchase orders, time, field…, one per project). Two people editing the *same collection* within a second of each other: last save wins for that collection. Fine for a six-person team; milestone 3 moves to one row per record.
- No SMS/push yet: the app tells the foreman when he opens it. Twilio + web push are milestone 5.
- A realtime update while you are inside an open editor is held until you close it.
