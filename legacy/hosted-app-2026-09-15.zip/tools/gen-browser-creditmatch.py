#!/usr/bin/env python3
"""Generate the browser copy of the credit-matching rule from the canonical module.

The rule lives once, in netlify/functions/lib/creditmatch.mjs. The single-file prototype cannot
import a module, so this strips the ESM keywords and namespaces the identifiers. A test compares
the generated file against the source, so the two cannot drift apart quietly.
"""
import re, sys, pathlib

SRC = pathlib.Path(__file__).resolve().parents[1] / 'netlify/functions/lib/creditmatch.mjs'
OUT = pathlib.Path(sys.argv[1] if len(sys.argv) > 1 else '/home/claude/erp/creditmatch.gen.js')

src = SRC.read_text()
# `export const X` / `export function X` -> plain declarations, prefixed so they cannot collide
# with anything in the 7,000-line prototype.
body = re.sub(r'^export\s+', '', src, flags=re.M)
for name in ['RM_MIN', 'RM_STRONG', 'tokens', 'value', 'expected', 'vendorMatch', 'amountMatch',
             'timingMatch', 'scorePair', 'OPEN_STATES', 'AWAITING', 'proposals', 'orphans', 'overdue',
             'STOP', 'DAY', 'days', 'round2']:
    body = re.sub(r'\b%s\b' % name, 'CM_' + name, body)

header = ("/* GENERATED from netlify/functions/lib/creditmatch.mjs by tools/gen-browser-creditmatch.py.\n"
          "   Do not edit here — edit the module and regenerate. `npm test` fails if the two drift. */\n"
          "const CM = (() => {\n")
footer = ("\n  return {RM_MIN: CM_RM_MIN, RM_STRONG: CM_RM_STRONG, tokens: CM_tokens, value: CM_value,\n"
          "          expected: CM_expected, scorePair: CM_scorePair, proposals: CM_proposals,\n"
          "          orphans: CM_orphans, overdue: CM_overdue, OPEN_STATES: CM_OPEN_STATES, AWAITING: CM_AWAITING};\n})();\n")
OUT.write_text(header + body + footer)
print('wrote', OUT, len(body), 'bytes of rule')
