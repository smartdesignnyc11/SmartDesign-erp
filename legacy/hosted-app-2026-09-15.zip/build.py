# Builds public/index.html + public/app.js from the prototype sources (../erp/app_head.html + ../erp/app.js).
import re, os, shutil, hashlib
SRC = os.environ.get('SDP_SRC', os.path.join(os.path.dirname(os.path.abspath(__file__)), 'src'))
h = open(os.path.join(SRC, 'app_head.html')).read(); j = open(os.path.join(SRC, 'app.js')).read()
ver = hashlib.md5(j.encode()).hexdigest()[:8]
pwa = f'''<link rel="manifest" href="manifest.webmanifest">
<meta name="theme-color" content="#1B2A4A">
<meta name="apple-mobile-web-app-capable" content="yes">
<meta name="apple-mobile-web-app-status-bar-style" content="default">
<meta name="apple-mobile-web-app-title" content="SmartDesigns">
<link rel="apple-touch-icon" href="icons/apple-touch-icon.png">
<script src="https://cdn.jsdelivr.net/npm/@supabase/supabase-js@2/dist/umd/supabase.js"></script>
<script src="config.js?v={ver}"></script>
<script src="cloud.js?v={ver}"></script>
<script src="mail.js?v={ver}"></script>
'''
assert h.count('</head>') == 1
h = h.replace('<meta name="viewport" content="width=device-width, initial-scale=1">', '<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">')
h = h.replace('</head>', pwa + '</head>')
sw = '''<script>if ('serviceWorker' in navigator && location.protocol.startsWith('http')) { window.addEventListener('load', () => navigator.serviceWorker.register('sw.js').catch(e => console.warn('sw', e))); }</script>'''
out = h + f'<script src="app.js?v={ver}"></script>\n' + sw + '\n</body>\n</html>\n'
os.makedirs('public', exist_ok=True)
open('public/index.html', 'w').write(out); open('public/app.js', 'w').write(j)
sw = open(os.path.join(os.path.dirname(__file__) or '.', 'sw.src.js')).read()
open('public/sw.js', 'w').write(re.sub(r"const VERSION = '[^']*';", f"const VERSION = 'sdp-{ver}';", sw))
print('built public/index.html', ver)
