// The credit-matching rule, offline. This is the file both the browser and the 6am job obey,
// so the cases below are the ones that decide whether money gets found or lost.
import assert from 'node:assert';
import { execFileSync } from 'node:child_process';
import { readFileSync, existsSync, mkdtempSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { scorePair, proposals, orphans, overdue, tokens, value, expected, RM_MIN, RM_STRONG } from '../netlify/functions/lib/creditmatch.mjs';

let pass = 0, fail = 0;
const t = (name, fn) => { try { fn(); console.log('ok  ', name); pass++; } catch (e){ console.log('FAIL', name, '—', e.message); fail++; } };

const RET = (o = {}) => Object.assign({
  id: 'r1', name: '8 surplus cup pulls', vendor: 'House of Antique Hardware',
  qty: 8, unitCost: 18.5, restockPct: 15, freightBack: 0,
  status: 'shipped', raisedAt: '2026-07-25', rmaAt: '2026-08-09', shippedAt: '2026-08-13', returnBy: '2026-09-23',
}, o);
const TXN = (o = {}) => Object.assign({id: 't1', amt: 125.8, date: '2026-09-06', desc: 'HOUSE OF ANTIQUE HDW CREDIT', cat: 'uncat'}, o);
const codes = r => scorePair(RET(r.ret || {}), TXN(r.txn || {})).reasons.map(x => x.code);

/* ---------- the arithmetic that decides ---------- */
t('value is what we paid, expected is what comes back after restocking', () => {
  const r = RET();
  assert.equal(value(r), 148);
  assert.equal(expected(r), 125.8);
});

t('freight the vendor keeps comes off what we expect', () => {
  assert.equal(expected(RET({restockPct: 0, freightBack: 18})), 130);
});

/* ---------- who ---------- */
t('a statement line naming the vendor is the strongest ordinary signal', () => {
  assert.ok(codes({}).includes('vendor-token'));
});

t('a transaction already tagged with the vendor beats guessing at the description', () => {
  const tagged = scorePair(RET(), TXN({desc: 'CREDIT MEMO', vendor: 'House of Antique Hardware'}));
  const guessed = scorePair(RET(), TXN());
  assert.ok(tagged.score > guessed.score, `${tagged.score} vs ${guessed.score}`);
  assert.ok(tagged.reasons.some(r => r.code === 'vendor-tagged'));
});

t('generic trade words identify nothing', () => {
  assert.deepEqual(tokens('Nemo Tile Supply Co'), ['nemo']);
  assert.deepEqual(tokens('ABC Hardware Inc'), []);
  assert.ok(!tokens('House of Antique Hardware').includes('hardware'));
});

t('a different vendor entirely is not proposed, however well the amount fits', () => {
  const s = scorePair(RET(), TXN({desc: 'SOMEWHERE ELSE REFUND'}));
  assert.ok(s.score < RM_MIN, s.score);
});

/* ---------- how much ---------- */
t('the expected amount, to the penny, is the strongest amount signal', () => {
  assert.ok(codes({}).includes('amount-exact'));
});

t('a vendor who waives the restocking fee still matches', () => {
  const s = scorePair(RET(), TXN({amt: 148}));
  assert.ok(s.reasons.some(r => r.code === 'amount-full'));
  assert.ok(s.score >= RM_MIN, s.score);
});

t('a partial credit is proposed, but as the weaker signal it is', () => {
  const part = scorePair(RET(), TXN({amt: 90}));
  const exact = scorePair(RET(), TXN());
  assert.ok(part.reasons.some(r => r.code === 'amount-partial'));
  assert.ok(part.score < exact.score);
});

t('more money than we paid is a reason to stop, not to celebrate', () => {
  const s = scorePair(RET(), TXN({amt: 900}));
  assert.ok(s.reasons.some(r => r.code === 'amount-over'));
  assert.ok(s.score < RM_MIN, `${s.score} — it must not be proposed`);
});

/* ---------- when ---------- */
t('money that arrived before the return existed is not this return money', () => {
  const before = scorePair(RET(), TXN({date: '2026-07-01'}));
  const after = scorePair(RET(), TXN());
  assert.ok(before.reasons.some(r => r.code === 'before'));
  assert.ok(after.score - before.score >= 40, `${after.score} vs ${before.score}`);
  assert.ok(before.score < RM_MIN, before.score);
});

t('a credit that turns up half a year later is flagged as odd but still shown', () => {
  const s = scorePair(RET(), TXN({date: '2027-03-01'}));
  assert.ok(s.reasons.some(r => r.code === 'much-later'));
  assert.ok(s.score >= RM_MIN, s.score);
});

t('an unmistakable pair is marked strong', () => {
  const s = scorePair(RET(), TXN({vendor: 'House of Antique Hardware'}));
  assert.ok(s.score >= RM_STRONG, s.score);
});

/* ---------- the shortlist ---------- */
t('one credit cannot close three returns', () => {
  const rs = [RET({id: 'a'}), RET({id: 'b'}), RET({id: 'c'})];
  const p = proposals({returns: rs, txns: [TXN()]});
  assert.equal(p.length, 1, 'exactly one pairing');
  assert.equal(p[0].txnId, 't1');
});

t('and one return does not take two credits', () => {
  const p = proposals({returns: [RET()], txns: [TXN({id: 'x'}), TXN({id: 'y'})]});
  assert.equal(p.length, 1);
});

t('the strongest pairing wins the credit', () => {
  const weak = RET({id: 'weak', vendor: 'House of Antique Hardware', qty: 8, unitCost: 20, restockPct: 0});   // expects 160
  const exact = RET({id: 'exact'});                                                                          // expects 125.80
  const p = proposals({returns: [weak, exact], txns: [TXN()]});
  assert.equal(p[0].returnId, 'exact');
});

t('a return with no RMA yet is not expecting money', () => {
  assert.equal(proposals({returns: [RET({status: 'raise'})], txns: [TXN()]}).length, 0);
});

t('a transaction already matched to a return is left alone', () => {
  assert.equal(proposals({returns: [RET()], txns: [TXN({retId: 'other'})]}).length, 0);
});

t('a client payment is not a vendor credit', () => {
  assert.equal(proposals({returns: [RET()], txns: [TXN({cat: 'income'})]}).length, 0);
});

t('a rejected pair stays rejected', () => {
  const rej = {'r1|t1': {at: '2026-09-07'}};
  assert.equal(proposals({returns: [RET()], txns: [TXN()], rejects: rej}).length, 0);
});

/* ---------- money in with nothing behind it ---------- */
t('a credit from a vendor we buy from, with no return, is surfaced', () => {
  const o = orphans({returns: [], txns: [TXN({id: 'z', desc: 'BEDROSIANS TILE CREDIT MEMO', amt: 214.5})],
                     vendors: [{name: 'Bedrosians'}]});
  assert.equal(o.length, 1);
});

t('a credit that already has a proposal is not also an orphan', () => {
  const o = orphans({returns: [RET()], txns: [TXN()], vendors: [{name: 'House of Antique Hardware'}]});
  assert.equal(o.length, 0);
});

t('money from a stranger is not called a vendor credit', () => {
  const o = orphans({returns: [], txns: [TXN({desc: 'INTEREST PAID', amt: 3.2})], vendors: [{name: 'Bedrosians'}]});
  assert.equal(o.length, 0);
});

/* ---------- what else is worth waking someone for ---------- */
t('windows are read against the day it is run, not the day it was written', () => {
  const rs = [
    RET({id: 'gone', returnBy: '2026-08-01'}),
    RET({id: 'soon', returnBy: '2026-09-12'}),
    RET({id: 'later', returnBy: '2026-12-01'}),
  ];
  const o = overdue({returns: rs, today: '2026-09-09'});
  assert.deepEqual(o.expired.map(r => r.id), ['gone']);
  assert.deepEqual(o.closing.map(r => r.id), ['soon']);
});

t('shipped back and silent past the chase window is its own finding', () => {
  const o = overdue({returns: [RET({shippedAt: '2026-07-01', returnBy: '2026-12-01'})], today: '2026-09-09'});
  assert.equal(o.stale.length, 1);
  assert.equal(o.expired.length, 0, 'it is not late, it is ignored');
});

t('a box still in the office is counted separately from one in transit', () => {
  const o = overdue({returns: [RET({id: 'a', status: 'toship'}), RET({id: 'b', status: 'shipped'})], today: '2026-09-09'});
  assert.deepEqual(o.unshipped.map(r => r.id), ['a']);
});

t('outstanding is what we expect back, not what we paid', () => {
  const o = overdue({returns: [RET()], today: '2026-09-09'});
  assert.equal(o.outstanding, 125.8);
});

/* ---------- the two copies of the rule cannot drift ---------- */
t('the browser copy is generated from this file and is up to date', () => {
  const gen = '/home/claude/erp/creditmatch.gen.js';
  if (!existsSync(gen)){ console.log('     (browser copy not present here — skipped)'); return; }
  const before = readFileSync(gen, 'utf8');
  const tmp = join(mkdtempSync(join(tmpdir(), 'cm-')), 'creditmatch.gen.js');
  execFileSync('python3', ['tools/gen-browser-creditmatch.py', tmp], {cwd: process.cwd()});
  assert.equal(readFileSync(tmp, 'utf8'), before,
    'the browser copy is stale — run python3 tools/gen-browser-creditmatch.py and rebuild');
});

console.log(`\n${pass} passed, ${fail} failed`);
process.exit(fail ? 1 : 0);
