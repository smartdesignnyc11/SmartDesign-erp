// The clipper's reader, offline. Nothing here touches the network.
import assert from 'node:assert';
import { fromJsonLd, fromMeta, fromItemprop, fromSpecTable, docsFrom, mergeCapture, leadDaysFrom, normalizeUrl, vendorOf } from '../extension/lib/extract.mjs';
import { readCapture } from '../netlify/functions/clip.mjs';

let pass = 0, fail = 0;
const t = (name, fn) => { try { fn(); console.log('ok  ', name); pass++; } catch (e){ console.log('FAIL', name, '—', e.message); fail++; } };

/* ---------- JSON-LD, the layer vendors keep accurate because Google reads it ---------- */
const LD_FERGUSON = JSON.stringify({
  '@context': 'https://schema.org', '@type': 'Product',
  name: 'Waterworks Regulator Wall Mount Lavatory Faucet — Unlacquered Brass',
  sku: 'RGLS02-UB', mpn: 'RGLS02', brand: {'@type': 'Brand', name: 'Waterworks'},
  color: 'Unlacquered Brass',
  description: 'Wall mount lavatory faucet with cross handles. Trim only; rough-in valve sold separately.',
  image: ['https://cdn.ferguson.com/rgls02-ub-1.jpg', 'https://cdn.ferguson.com/rgls02-ub-2.jpg'],
  additionalProperty: [{name: 'Spread', value: '8 in'}, {name: 'Flow Rate', value: '1.2 gpm'}],
  offers: {'@type': 'Offer', price: '1180.00', priceCurrency: 'USD', availability: 'https://schema.org/InStock'},
});

t('json-ld: name, sku, brand, colour, price and availability', () => {
  const o = fromJsonLd([LD_FERGUSON]);
  assert.equal(o.sku, 'RGLS02-UB');
  assert.equal(o.brand, 'Waterworks');
  assert.equal(o.color, 'Unlacquered Brass');
  assert.equal(o.price, 1180);
  assert.equal(o.currency, 'USD');
  assert.equal(o.stock, 'In Stock');
  assert.equal(o.images.length, 2);
  assert.deepEqual(o.specs[0], ['Spread', '8 in']);
});

t('json-ld: a graph wrapper is walked, not just a bare Product', () => {
  const o = fromJsonLd([JSON.stringify({'@context': 'x', '@graph': [{'@type': 'WebPage'}, JSON.parse(LD_FERGUSON)]})]);
  assert.equal(o.sku, 'RGLS02-UB');
});

t('json-ld: a broken block does not lose the good one', () => {
  const o = fromJsonLd(['{not json at all', LD_FERGUSON]);
  assert.equal(o.sku, 'RGLS02-UB');
});

t('json-ld: an offer array takes the first real price', () => {
  const o = fromJsonLd([JSON.stringify({'@type': 'Product', name: 'x', offers: [{price: '0'}, {price: '240.50', priceCurrency: 'USD'}]})]);
  assert.equal(o.price, 240.5);
});

/* ---------- the other layers ---------- */
t('meta: OpenGraph fills a page with no product data', () => {
  const o = fromMeta([
    {property: 'og:title', content: 'Shaws Original 30" Fireclay Farmhouse Sink'},
    {property: 'og:image', content: 'https://cdn.build.com/rc3018.jpg'},
    {property: 'product:price:amount', content: '1495.00'},
    {name: 'description', content: 'Single bowl apron front.'},
  ]);
  assert.equal(o.title, 'Shaws Original 30" Fireclay Farmhouse Sink');
  assert.equal(o.price, 1495);
  assert.equal(o.images[0], 'https://cdn.build.com/rc3018.jpg');
});

t('microdata: itemprop attributes are read, unknown ones become specs', () => {
  const o = fromItemprop([{prop: 'sku', value: 'SL2811HAB'}, {prop: 'brand', value: 'Visual Comfort'},
                          {prop: 'price', value: '385.00'}, {prop: 'weight', value: '4 lb'}]);
  assert.equal(o.sku, 'SL2811HAB');
  assert.equal(o.price, 385);
  assert.deepEqual(o.specs, [['weight', '4 lb']]);
});

t('spec table: the four labels that matter are recognised', () => {
  const o = fromSpecTable([['SKU:', 'HW-1147-PB'], ['Finish', 'Polished Brass'], ['Dimensions', '2-3/8 in backset'],
                           ['Lead Time', 'Ships in 2 weeks'], ['Warranty', 'Lifetime']]);
  assert.equal(o.sku, 'HW-1147-PB');
  assert.equal(o.finish, 'Polished Brass');
  assert.equal(o.dims, '2-3/8 in backset');
  assert.equal(o.leadText, 'Ships in 2 weeks');
  assert.equal(o.specs.length, 5, 'everything is kept as a spec too');
});

t('spec table: a paragraph masquerading as a label is rejected', () => {
  const o = fromSpecTable([['This item is finished by hand and no two are identical, which means', 'Polished Brass']]);
  assert.equal(o.finish, undefined);
  assert.equal(o.specs.length, 0);
});

/* ---------- lead time ---------- */
t('lead time: quotes the far end of a range, not the near one', () => {
  assert.equal(leadDaysFrom('Lead time 6-8 weeks'), 56);
  assert.equal(leadDaysFrom('Usually ships within 3 business days'), 3);
  assert.equal(leadDaysFrom('Ships in 2 to 4 weeks'), 28);
  assert.equal(leadDaysFrom('12 week lead time on this finish'), 84);
  assert.equal(leadDaysFrom('Free shipping over $99'), 0, 'a shipping promotion is not a lead time');
});

/* ---------- documents ---------- */
t('docs: spec, tear and installation sheets are told apart', () => {
  const d = docsFrom([
    {href: 'https://x.com/a/spec.pdf', text: 'Specification sheet'},
    {href: 'https://x.com/a/install.pdf', text: 'Installation instructions'},
    {href: 'https://x.com/a/tear.pdf', text: 'Tear sheet'},
    {href: 'https://x.com/returns', text: 'Returns policy'},
  ]);
  assert.deepEqual(d.map(x => x.kind), ['spec', 'install', 'tear']);
});

t('docs: the same file linked twice appears once', () => {
  const d = docsFrom([{href: 'https://x.com/s.pdf', text: 'Spec'}, {href: 'https://x.com/s.pdf', text: 'Spec sheet (PDF)'}]);
  assert.equal(d.length, 1);
});

/* ---------- urls and vendors ---------- */
t('url: tracking is stripped so the same product clips to the same identity', () => {
  const a = normalizeUrl('https://www.ferguson.com/product/x?utm_source=email&gclid=abc&sku=RGLS02#reviews');
  assert.equal(a, 'https://www.ferguson.com/product/x?sku=RGLS02');
});
t('vendor: known hosts get their real name, others keep the domain', () => {
  assert.equal(vendorOf('https://www.ferguson.com/x'), 'Ferguson');
  assert.equal(vendorOf('https://www.houseofantiquehardware.com/x'), 'House of Antique Hardware');
  assert.equal(vendorOf('https://shop.someminorvendor.com/x'), 'shop.someminorvendor.com');
});

/* ---------- the merge: precedence and honesty ---------- */
t('merge: json-ld wins over a guess from the visible page', () => {
  const out = mergeCapture({
    jsonld: {title: 'Waterworks Regulator — Unlacquered Brass', sku: 'RGLS02-UB', price: 1180},
    page: {title: 'Ferguson | Bath | Faucets | Regulator', price: 999},
  }, 'https://www.ferguson.com/x', '');
  assert.equal(out.title, 'Waterworks Regulator — Unlacquered Brass');
  assert.equal(out.price, 1180);
  assert.equal(out.source.title, 'jsonld');
});

t('merge: a later layer fills a gap the first one left', () => {
  const out = mergeCapture({jsonld: {title: 'A faucet'}, spec: {sku: 'ABC-1', finish: 'Chrome'}}, 'https://x.com/p', '');
  assert.equal(out.sku, 'ABC-1');
  assert.equal(out.source.sku, 'spec');
  assert.equal(out.source.title, 'jsonld');
});

t('merge: colour becomes finish when no finish was declared', () => {
  const out = mergeCapture({jsonld: {title: 'x', color: 'Unlacquered Brass'}}, 'https://x.com/p', '');
  assert.equal(out.finish, 'Unlacquered Brass');
});

t('merge: what could not be read is named, not silently blank', () => {
  const out = mergeCapture({jsonld: {title: 'A sconce'}}, 'https://x.com/p', '');
  assert.deepEqual(out.missing.sort(), ['dims', 'finish', 'price', 'sku']);
});

t('merge: duplicate spec keys collapse and images are capped', () => {
  const out = mergeCapture({
    jsonld: {specs: [['Finish', 'Brass'], ['finish', 'Brass again']], images: Array.from({length: 9}, (_, i) => `i${i}.jpg`)},
    spec: {specs: [['Finish', 'Brass third time']]},
  }, 'https://x.com/p', '');
  assert.equal(out.specs.filter(s => /finish/i.test(s[0])).length, 1);
  assert.equal(out.images.length, 5);
});

t('merge: lead time is read out of the page body when no label carries it', () => {
  const out = mergeCapture({jsonld: {title: 'x'}}, 'https://x.com/p', 'Made to order. Lead time 10-12 weeks from order.');
  assert.equal(out.leadDays, 84);
});

/* ---------- end to end, the shape the extension actually sends ---------- */
t('capture: a full Ferguson-shaped page becomes a clean record', () => {
  const clip = readCapture({
    url: 'https://www.ferguson.com/product/waterworks-regulator?utm_campaign=x',
    jsonld: [LD_FERGUSON],
    metas: [{property: 'og:image', content: 'https://cdn.ferguson.com/hero.jpg'}],
    props: [],
    pairs: [['Lead Time', '6-8 weeks'], ['Rough-in valve', 'Sold separately']],
    links: [{href: 'https://cdn.ferguson.com/rgls02-spec.pdf', text: 'Specification Sheet'},
            {href: 'https://cdn.ferguson.com/rgls02-install.pdf', text: 'Installation Instructions'}],
    images: [], h1: 'Regulator Wall Mount Lavatory Faucet', title: 'Ferguson',
    priceText: '', text: 'Lead time 6-8 weeks. Rough-in valve sold separately.',
  });
  assert.equal(clip.sku, 'RGLS02-UB');
  assert.equal(clip.brand, 'Waterworks');
  assert.equal(clip.price, 1180);
  assert.equal(clip.finish, 'Unlacquered Brass');
  assert.equal(clip.vendor, 'Ferguson');
  assert.equal(clip.url, 'https://www.ferguson.com/product/waterworks-regulator', 'tracking stripped');
  assert.equal(clip.leadDays, 56);
  assert.equal(clip.docs.length, 2);
  assert.deepEqual(clip.missing, ['dims'], 'only the dimension was genuinely absent');
});

t('capture: a page with nothing machine-readable still yields a title and says what is missing', () => {
  const clip = readCapture({
    url: 'https://smallvendor.example/p/123', jsonld: [], metas: [], props: [], pairs: [], links: [],
    images: ['https://smallvendor.example/img.jpg'], h1: 'Solid Brass Cabinet Pull', title: 'Shop', priceText: '$42.00', text: '',
  });
  assert.equal(clip.title, 'Solid Brass Cabinet Pull');
  assert.equal(clip.price, 42);
  assert.ok(clip.missing.includes('sku'));
  assert.equal(clip.source.title, 'page');
});

console.log(`\n${pass} passed, ${fail} failed`);
process.exit(fail ? 1 : 0);
