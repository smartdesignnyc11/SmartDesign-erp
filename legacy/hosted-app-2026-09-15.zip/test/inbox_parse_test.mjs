// Offline test for the inbox parser. Fixtures are hand-written in the shape the portals send:
// table-based HTML alerts, a plain-text broker blast, and an auction notice.
import assert from 'node:assert';
import { parseListingEmail, firstAddress, firstPrice, normalizeUrl, enrich } from '../netlify/functions/lib/parse-listing-email.mjs';

let pass = 0, fail = 0;
const t = (name, fn) => { try { fn(); console.log('ok  ', name); pass++; } catch (e) { console.log('FAIL', name, '—', e.message); fail++; } };

// ---------- unit ----------
t('address: ordinal street with direction', () => assert.equal(firstAddress('Just listed: 254 W 121st Street, Harlem'), '254 W 121st Street'));
t('address: named street', () => assert.equal(firstAddress('166 Carlton Avenue, Fort Greene'), '166 Carlton Avenue'));
t('address: hyphenated house number', () => assert.equal(firstAddress('34-19 Broadway, Astoria'), '34-19 Broadway'));
t('address: none in navigation copy', () => assert.equal(firstAddress('Manage your saved searches'), ''));
t('price: plain', () => assert.equal(firstPrice('Asking $2,750,000'), 2750000));
t('price: millions shorthand', () => assert.equal(firstPrice('$8.75M'), 8750000));
t('price: ignores small noise', () => assert.equal(firstPrice('Save $5 today'), null));
t('url: strips tracking, keeps identity', () => assert.equal(
  normalizeUrl('https://streeteasy.com/building/140-prospect-place?utm_source=alert&utm_medium=email&featured=1'),
  'https://streeteasy.com/building/140-prospect-place?featured=1'));

// ---------- StreetEasy style alert, two listings ----------
const streeteasy = {
  from: 'StreetEasy <noreply@mail.streeteasy.com>',
  subject: '3 new listings match "Brooklyn townhouse under $4M"',
  date: '2026-09-08T11:02:00Z',
  html: `<html><body><table><tr><td><a href="https://streeteasy.com/unsubscribe?u=99">Manage alerts</a></td></tr>
    <tr><td><a href="https://streeteasy.com/building/140-prospect-place?utm_source=alert">140 Prospect Place</a></td></tr>
    <tr><td>Prospect Heights, Brooklyn</td></tr>
    <tr><td>$3,495,000 &middot; 4 beds &middot; 3.5 baths &middot; 3,200 sq ft</td></tr>
    <tr><td><a href="https://streeteasy.com/building/166-carlton-avenue">166 Carlton Avenue</a></td></tr>
    <tr><td>Fort Greene, Brooklyn</td></tr>
    <tr><td>$2,900,000 &middot; 3 beds &middot; 2 baths</td></tr>
    <tr><td><a href="https://streeteasy.com/search">See all results</a></td></tr></table></body></html>`,
};
t('streeteasy: two listings, navigation links dropped', () => {
  const r = parseListingEmail(streeteasy);
  assert.equal(r.length, 2, `got ${r.length}`);
  assert.equal(r[0].address, '140 Prospect Place');
  assert.equal(r[0].amount, 3495000);
  assert.equal(r[0].payload.beds, 4);
  assert.equal(r[0].payload.baths, 3.5);
  assert.equal(r[0].payload.sqft, 3200);
  assert.equal(r[0].payload.portal, 'StreetEasy');
  assert.equal(r[0].category, 'listing');
  assert.equal(r[0].signal, 'New listing');
  assert.equal(r[0].payload.neighborhood, 'Prospect Heights');
  assert.equal(r[1].address, '166 Carlton Avenue');
  assert.equal(r[1].amount, 2900000);
  assert.ok(!r[0].source_ref.includes('utm_'), 'tracking should be stripped from the dedupe key');
});
t('streeteasy: re-parsing the same mail yields the same refs', () => {
  const a = parseListingEmail(streeteasy).map(x => x.source_ref);
  const b = parseListingEmail(streeteasy).map(x => x.source_ref);
  assert.deepEqual(a, b);
});

// ---------- LoopNet, price cut ----------
t('loopnet: price cut raises the score and names the signal', () => {
  const r = parseListingEmail({
    from: 'LoopNet Alerts <alerts@loopnet.com>',
    subject: 'Price reduced on a property in your saved search',
    date: '2026-09-07T09:00:00Z',
    html: `<div><a href="https://www.loopnet.com/Listing/305-W-113th-St-New-York-NY/33445566/">305 W 113th Street</a></div>
           <div>Harlem, Manhattan &middot; 12 units</div><div>New price: $4,200,000 (was $4,650,000)</div>`,
  });
  assert.equal(r.length, 1);
  assert.equal(r[0].signal, 'Price cut');
  assert.equal(r[0].score, 55);
  assert.equal(r[0].payload.units, 12);
  assert.equal(r[0].amount, 4200000);
});

// ---------- Auction.com ----------
t('auction: scored as distress, category auction', () => {
  const r = parseListingEmail({
    from: 'Auction.com <no-reply@auction.com>',
    subject: 'Foreclosure auction: bid deadline Friday',
    date: '2026-09-06T14:00:00Z',
    html: `<div><a href="https://www.auction.com/details/17-hamilton-terrace-new-york-ny-10031_id123">17 Hamilton Terrace, New York, NY</a></div>
           <div>Opening bid $1,850,000 &middot; sold as-is</div>`,
  });
  assert.equal(r.length, 1);
  assert.equal(r[0].category, 'auction');
  assert.equal(r[0].address, '17 Hamilton Terrace');
  assert.ok(r[0].score >= 70, `score ${r[0].score}`);
});

// ---------- plain-text broker blast ----------
t('broker plain text: address and price without a portal', () => {
  const r = parseListingEmail({
    from: 'Michael Rosen <michael@brownstonebrokers.com>',
    subject: 'Off-market opportunity in Bed-Stuy',
    date: '2026-09-08T08:30:00Z',
    text: `Alan,\n\nQuietly available: 488 Macon Street, Bed-Stuy. 4 family, 3,600 sf.\nAsking $2.4M. Details here: https://brownstonebrokers.com/listings/488-macon\n\nBest,\nMichael`,
  });
  assert.equal(r.length, 1);
  assert.equal(r[0].address, '488 Macon Street');
  assert.equal(r[0].amount, 2400000);
  assert.equal(r[0].payload.units, 4);
  assert.equal(r[0].payload.portal, 'Email');
});

// ---------- noise ----------
t('newsletter with no address produces nothing', () => {
  const r = parseListingEmail({
    from: 'StreetEasy <news@mail.streeteasy.com>',
    subject: 'The Brooklyn market in August',
    html: `<div><a href="https://streeteasy.com/blog/august-market">Read the report</a></div><div>Median asking price rose 2%.</div>`,
  });
  assert.equal(r.length, 0);
});

// ---------- enrichment ----------
t('enrich: canonical address, BBL, and watch-area match adds score', async () => {
  const r = parseListingEmail(streeteasy);
  const before = r[0].score;
  const geocode = async (q) => q.startsWith('140 Prospect Place')
    ? {address: '140 Prospect Place', bbl: '3011450034', bin: '3056781'}
    : null;
  await enrich(r, geocode, {'wa-brooklyn': new Set(['1145'])});
  assert.equal(r[0].bbl, '3011450034');
  assert.equal(r[0].watch_area_id, 'wa-brooklyn');
  assert.equal(r[0].score, before + 20);
  assert.equal(r[1].bbl, undefined, 'unmatched address stays unenriched');
});

setTimeout(() => {
  console.log(`\n${pass} passed, ${fail} failed`);
  process.exit(fail ? 1 : 0);
}, 100);
