// Runs the harvest functions end to end with the NYC endpoints and Supabase stubbed.
// Checks routing, scoring, de-duplication, watch-area matching and the failure guards.
import assert from 'node:assert';

let pass = 0, fail = 0;
const t = async (name, fn) => { try { await fn(); console.log('ok  ', name); pass++; } catch (e) { console.log('FAIL', name, '—', e.message); fail++; } };

// ---- stub Supabase before the modules import it ----
const store = {signals: new Map(), areas: []};
const fake = {
  createClient: () => ({
    from(table){
      const st = {filters: []};
      const api = {
        select(){ return api; },
        eq(k, v){ st.filters.push([k, v]); return api; },
        in(){ return api; },
        order(){ return api; },
        limit(){ return api; },
        upsert(rows, opts){
          st.rows = rows; st.opts = opts;
          return {then: (res) => { for (const r of rows){ const k = `${r.source}|${r.source_ref}`; if (!store.signals.has(k)) store.signals.set(k, r); } res({error: null}); }};
        },
        then(res){
          if (table === 'mb_watch_area') return res({data: store.areas, error: null});
          return res({data: [...store.signals.values()], error: null});
        },
      };
      return api;
    },
  }),
};

// ---- stub fetch ----
const calls = [];
const rows = {
  pluto: [
    {block: '1719', bbl: '1017190034', address: '254 W 121 ST', ownername: '121 WEST REALTY LLC', bldgclass: 'C7', yearbuilt: '1899', unitstotal: '9', lotarea: '1800', histdist: 'Mount Morris Park Historic District'},
    {block: '1905', bbl: '1019050011', address: '17 HAMILTON TER', ownername: 'HAMILTON TERRACE OWNER LLC', bldgclass: 'C1', yearbuilt: '1898', unitstotal: '4', lotarea: '2000', histdist: ''},
  ],
  acrisMaster: [
    {document_id: 'DOC-LSP-1', doc_type: 'LSP', document_date: '2026-09-01', recorded_datetime: '2026-09-04T10:00:00.000', document_amt: '0'},
    {document_id: 'DOC-DEED-1', doc_type: 'DEED', document_date: '2026-09-02', recorded_datetime: '2026-09-05T10:00:00.000', document_amt: '2100000'},
    {document_id: 'DOC-ELSEWHERE', doc_type: 'LSP', document_date: '2026-09-02', recorded_datetime: '2026-09-05T10:00:00.000', document_amt: '0'},
  ],
  acrisLegal: [
    {document_id: 'DOC-LSP-1', borough: '1', block: '1719', lot: '34', street_number: '254', street_name: 'WEST 121 STREET', unit: ''},
    {document_id: 'DOC-DEED-1', borough: '1', block: '1905', lot: '11', street_number: '17', street_name: 'HAMILTON TERRACE', unit: ''},
  ],
  taxLien: [
    {month: '2026-09-01T00:00:00.000', cycle: '90 Day Notice', borough: '1', block: '1719', lot: '34', tax_class_code: '2', building_class: 'C7', community_board: '110', house_number: '254', street_name: 'WEST 121 STREET', water_debt_only: 'NO'},
    {month: '2026-09-01T00:00:00.000', cycle: '90 Day Notice', borough: '1', block: '1905', lot: '11', tax_class_code: '2', building_class: 'C1', community_board: '109', house_number: '17', street_name: 'HAMILTON TERRACE', water_debt_only: 'YES'},
  ],
  hpd: [
    ...Array.from({length: 6}, (_, i) => ({violationid: `V${i}`, boroid: '1', block: '1719', lot: '34', housenumber: '254', streetname: 'WEST 121 STREET', class: i === 0 ? 'C' : 'B', novdescription: 'Roof leak in the top floor ceiling', novissueddate: '2026-08-2' + (i % 9) + 'T00:00:00.000', currentstatus: 'NOV SENT', violationstatus: 'Open'})),
    {violationid: 'V-LONE', boroid: '1', block: '1905', lot: '11', housenumber: '17', streetname: 'HAMILTON TERRACE', class: 'A', novdescription: 'Missing smoke detector', novissueddate: '2026-08-20T00:00:00.000', currentstatus: 'NOV SENT', violationstatus: 'Open'},
  ],
  dob: [
    {job__: 'J123', doc__: '01', borough: 'MANHATTAN', house__: '254', street_name: 'WEST 121 STREET', block: '1719', lot: '34', bin__: '1054321', job_type: 'A1', job_status_descrp: 'Plan Exam', pre__filing_date: '08/28/2026', landmarked: 'Y', initial_cost: '750000', applicant_s_first_name: 'Dana', applicant_s_last_name: 'Reyes'},
    {job__: 'J124', doc__: '02', borough: 'MANHATTAN', house__: '254', street_name: 'WEST 121 STREET', block: '1719', lot: '34', bin__: '1054321', job_type: 'A1', job_status_descrp: 'Plan Exam', pre__filing_date: '08/28/2026', landmarked: 'Y', initial_cost: '750000'},
    {job__: 'J125', doc__: '01', borough: 'MANHATTAN', house__: '17', street_name: 'HAMILTON TERRACE', block: '1905', lot: '11', bin__: '1055555', job_type: 'A2', job_status_descrp: 'Permit Issued', pre__filing_date: '01/02/2020', landmarked: 'N', initial_cost: '20000'},
  ],
  sales: [
    {borough: '1', neighborhood: 'HARLEM CENTRAL', building_class_category: '07 RENTALS - WALKUP APARTMENTS', block: '1719', lot: '34', address: '254 WEST 121 STREET', zip_code: '10027', residential_units: '9', commercial_units: '0', total_units: '9', land_square_feet: '1800', gross_square_feet: '7200', year_built: '1899', sale_price: '4320000', sale_date: '2026-08-20T00:00:00.000', bbl: '1017190034'},
    {borough: '1', neighborhood: 'HARLEM CENTRAL', building_class_category: '01 ONE FAMILY DWELLINGS', block: '1719', lot: '40', address: '260 WEST 121 STREET', zip_code: '10027', residential_units: '1', commercial_units: '0', total_units: '1', land_square_feet: '1700', gross_square_feet: '4000', year_built: '1899', sale_price: '2000000', sale_date: '2026-08-10T00:00:00.000', bbl: '1017190040'},
    {borough: '1', neighborhood: 'HAMILTON HEIGHTS', building_class_category: '03 THREE FAMILY DWELLINGS', block: '1905', lot: '11', address: '17 HAMILTON TERRACE', zip_code: '10031', residential_units: '4', commercial_units: '0', total_units: '4', land_square_feet: '2000', gross_square_feet: '5000', year_built: '1898', sale_price: '2500000', sale_date: '2026-08-15T00:00:00.000', bbl: '1019050011'},
    {borough: '1', neighborhood: 'HARLEM CENTRAL', building_class_category: '07 RENTALS', block: '1719', lot: '50', address: '9 NOTHING PLACE', sale_price: '1', sale_date: '2026-08-01T00:00:00.000', bbl: '1017190050'},
  ],
  ecb: [
    {ecb_violation_number: 'E1', ecb_violation_status: 'ACTIVE', boro: '1', block: '1719', lot: '34', bin: '1054321', issue_date: '20260815', severity: 'Class 1', violation_type: 'CONSTRUCTION', violation_description: 'Work without a permit', penality_imposed: '25000', amount_paid: '0', balance_due: '25000'},
    {ecb_violation_number: 'E2', ecb_violation_status: 'ACTIVE', boro: '1', block: '1719', lot: '34', bin: '1054321', issue_date: '20260820', severity: 'Class 2', violation_type: 'ELEVATOR', violation_description: 'Failure to file', penality_imposed: '5000', amount_paid: '0', balance_due: '5000'},
    {ecb_violation_number: 'E3', ecb_violation_status: 'RESOLVE', boro: '1', block: '1719', lot: '34', issue_date: '20260821', balance_due: '90000'},
    {ecb_violation_number: 'E4', ecb_violation_status: 'ACTIVE', boro: '1', block: '1905', lot: '11', issue_date: '20260818', violation_description: 'Sign without permit', penality_imposed: '400', amount_paid: '0', balance_due: '400'},
  ],
  dobViol: [
    {violation_number: 'D1', boro: '1', block: '1719', lot: '34', bin: '1054321', issue_date: '20260810', violation_type: 'LL1181', violation_category: 'V*-DOB VIOLATION - ACTIVE', description: 'Facade unsafe'},
    {violation_number: 'D2', boro: '1', block: '1719', lot: '34', bin: '1054321', issue_date: '20260812', violation_type: 'BENCH', violation_category: 'V-DOB VIOLATION - ACTIVE', description: 'Boiler'},
    {violation_number: 'D3', boro: '1', block: '1719', lot: '34', bin: '1054321', issue_date: '20260813', violation_type: 'LBLVIO', violation_category: 'V*-DOB VIOLATION - DISMISSED', description: 'Dismissed one'},
    {violation_number: 'D4', boro: '1', block: '1905', lot: '11', issue_date: '20260814', violation_type: 'E', violation_category: 'V-DOB VIOLATION - ACTIVE', description: 'Lone one'},
  ],
  dobNow: [
    {job_filing_number: 'B00123456-I1', work_permit: 'B00123456-I1-GC', filing_reason: 'Initial Permit', house_no: '254', street_name: 'WEST 121 STREET', borough: 'MANHATTAN', block: '1719', lot: '34', bin: '1054321', bbl: '1017190034', work_type: 'General Construction', issued_date: '2026-08-25T00:00:00.000', approved_date: '2026-08-24T00:00:00.000', job_description: 'Interior renovation of nine units, no change to use or egress', estimated_job_costs: '1250000', owner_name: 'Ruth Delaney', owner_business_name: '121 WEST REALTY LLC', applicant_business_name: 'SMARTDESIGN NYC', permit_status: 'ISSUED'},
    {job_filing_number: 'B00999999-I1', work_permit: 'B00999999-I1-PL', filing_reason: 'Initial Permit', house_no: '17', street_name: 'HAMILTON TERRACE', borough: 'MANHATTAN', block: '1905', lot: '11', bin: '1055555', bbl: '1019050011', work_type: 'Plumbing', issued_date: '2019-05-01T00:00:00.000', job_description: 'Old work', estimated_job_costs: '9000', permit_status: 'ISSUED'},
  ],
  hpdReg: [
    {registrationid: '900123', buildingid: '5001', boroid: '1', housenumber: '254', streetname: 'WEST 121 STREET', zip: '10027', block: '1719', lot: '34', bin: '1054321', lastregistrationdate: '2026-08-01T00:00:00.000', registrationenddate: '2027-09-01T00:00:00.000'},
    {registrationid: '800100', buildingid: '5001', boroid: '1', housenumber: '254', streetname: 'WEST 121 STREET', block: '1719', lot: '34', lastregistrationdate: '2025-08-01T00:00:00.000', registrationenddate: '2026-09-01T00:00:00.000'},
  ],
  hpdContact: [
    {registrationcontactid: '1', registrationid: '900123', type: 'Agent', contactdescription: 'Managing agent', corporationname: 'PARKSIDE MANAGEMENT INC', firstname: 'DEREK', lastname: 'OYELARAN', businesshousenumber: '2110', businessstreetname: 'FREDERICK DOUGLASS BLVD', businesscity: 'NEW YORK', businessstate: 'ny', businesszip: '10026'},
    {registrationcontactid: '2', registrationid: '900123', type: 'HeadOfficer', title: 'Head Officer', firstname: 'RUTH', middleinitial: 'A', lastname: 'DELANEY', businesshousenumber: '18', businessstreetname: 'EAST 66 STREET', businesscity: 'NEW YORK', businessstate: 'ny', businesszip: '10065'},
    {registrationcontactid: '3', registrationid: '900123', type: 'CorporateOwner', corporationname: '121 WEST REALTY LLC', businesshousenumber: '18', businessstreetname: 'EAST 66 STREET', businesscity: 'NEW YORK', businessstate: 'ny', businesszip: '10065'},
    {registrationcontactid: '4', registrationid: '900123', type: 'HeadOfficer', title: 'Head Officer', firstname: 'RUTH', middleinitial: 'A', lastname: 'DELANEY', businesshousenumber: '18', businessstreetname: 'EAST 66 STREET', businesscity: 'NEW YORK', businessstate: 'ny', businesszip: '10065'},
  ],
};
// Socrata filters server-side; the stub has to do the same for single-lot queries or the
// property dossier would silently aggregate the whole block.
const applyWhere = (where, list) => {
  const lot = /\blot\s*=\s*'?(\d+)'?/.exec(where || '');
  const block = /\bblock\s*=\s*'?(\d+)'?/.exec(where || '');
  const not = /\blot\s*!=\s*'?(\d+)'?/.exec(where || '');
  let out = list;
  if (block) out = out.filter(r => String(r.block ?? '') === block[1]);
  if (lot) out = out.filter(r => String(r.lot ?? '') === lot[1]);
  if (not) out = out.filter(r => String(r.lot ?? '') !== not[1]);
  return out;
};
globalThis.fetch = async (u, opts) => {
  const url = String(u);
  calls.push(url);
  const where = new URL(url).searchParams.get('$where') || '';
  const ok = (b) => new Response(JSON.stringify(Array.isArray(b) ? applyWhere(where, b) : b), {status: 200, headers: {'content-type': 'application/json'}});
  if (url.includes('64uk-42ks')) return ok(rows.pluto);
  if (url.includes('bnx9-e6tj')) return ok(rows.acrisMaster);
  if (url.includes('8h5j-fqxa')) return ok(rows.acrisLegal);
  if (url.includes('9rz4-mjek')) return ok(rows.taxLien);
  if (url.includes('wvxf-dwi5')) return ok(rows.hpd);
  if (url.includes('ic3t-wcy2')) return ok(rows.dob);
  if (url.includes('w2pb-icbu')) return ok(rows.sales);
  if (url.includes('6bgk-3dad')) return ok(rows.ecb);
  if (url.includes('3h2n-5cm9')) return ok(rows.dobViol);
  if (url.includes('rbx6-tga4')) return ok(rows.dobNow);
  if (url.includes('tesw-yqqr')) return ok(rows.hpdReg);
  if (url.includes('feu5-w2e2')) return ok(rows.hpdContact);
  if (url.includes('geosearch')) {
    const q = new URL(url).searchParams.get('text') || '';
    if (/140 Prospect/i.test(q)) return ok({features: [{properties: {name: '140 Prospect Place', borough: 'Brooklyn', addendum: {pad: {bbl: '3011450034', bin: '3056781'}}}, geometry: {coordinates: [-73.968, 40.677]}}]});
    if (/254 W 121/i.test(q)) return ok({features: [{properties: {name: '254 W 121st Street', borough: 'Manhattan', addendum: {pad: {bbl: '1017190034', bin: '1054321'}}}, geometry: {coordinates: [-73.947, 40.808]}}]});
    return ok({features: []});
  }
  return new Response('{}', {status: 404});
};

process.env.SUPABASE_URL = 'https://stub.supabase.co';
process.env.SUPABASE_SERVICE_ROLE_KEY = 'stub';
process.env.CRON_SECRET = '';

// swap the supabase client for the fake by intercepting the module through a global the lib reads
const nyc = await import('../netlify/functions/lib/nyc.mjs');
const fakeClient = fake.createClient();

const AREA = {id: 'wa1', label: 'Harlem', workspace_id: 'default', borough: '1', cds: ['109', '110', '111'], active: true};
store.areas = [AREA];

const req = (path, method = 'GET', body, headers = {}) =>
  new Request(`https://app.test${path}`, {method, body, headers});

// The functions import admin() from the module namespace, which we cannot rebind after the fact,
// so exercise the pieces the same way the handlers do and assert on the produced rows.
await t('nyc: lotsFor collects blocks and lot facts', async () => {
  const {blocks, lots} = await nyc.lotsFor(AREA);
  assert.deepEqual([...blocks].sort(), ['1719', '1905']);
  assert.equal(lots['1017190034'].histdist, 'Mount Morris Park Historic District');
});

await t('nyc: enrichFromLot adds the historic-district premium once', async () => {
  const {lots} = await nyc.lotsFor(AREA);
  const s = nyc.enrichFromLot({bbl: '1017190034', score: 100, payload: {}}, lots);
  assert.equal(s.score, 115);
  assert.equal(s.payload.lpc_district, 'Mount Morris Park Historic District');
  const s2 = nyc.enrichFromLot({bbl: '1019050011', score: 50, payload: {}}, lots);
  assert.equal(s2.score, 50, 'no district, no premium');
});

await t('nyc: bblOf pads correctly', () => {
  assert.equal(nyc.bblOf('1', '1719', '34'), '1017190034');
  assert.equal(nyc.bblOf('3', '1145', '1'), '3011450001');
});

await t('nyc: saveSignals de-duplicates on (source, source_ref)', async () => {
  store.signals.clear();
  const row = {source: 'acris', source_ref: 'DOC-1', signal: 'Lis pendens', category: 'distress', score: 100, bbl: '1017190034', address: '254 W 121 St', occurred_on: '2026-09-04', payload: {}};
  await nyc.saveSignals(fakeClient, [row]);
  await nyc.saveSignals(fakeClient, [row, {...row, source_ref: 'DOC-2'}]);
  assert.equal(store.signals.size, 2);
});

await t('nyc: saveSignals nulls a non-numeric amount rather than failing the insert', async () => {
  store.signals.clear();
  await nyc.saveSignals(fakeClient, [{source: 'x', source_ref: 'y', signal: 's', category: 'c', score: 1, amount: NaN, payload: {}}]);
  assert.equal([...store.signals.values()][0].amount, null);
});

await t('nyc: geocode returns BBL and BIN', async () => {
  const g = await nyc.geocode('254 W 121st Street');
  assert.equal(g.bbl, '1017190034');
  assert.equal(g.bin, '1054321');
});

await t('nyc: probe names a dataset that goes quiet', async () => {
  const bad = await nyc.probe(['not-a-dataset']);
  assert.equal(bad.length, 1);
  assert.ok(bad[0].includes('not-a-dataset'));
});

// ---- the gov feed logic, exercised through the real module with a stubbed writer ----
await t('gov: tax lien scores water debt lower than a tax lien', async () => {
  store.signals.clear();
  const {lots} = await nyc.lotsFor(AREA);
  const taxRows = rows.taxLien.map(r => {
    const bbl = nyc.bblOf(r.borough, r.block, r.lot);
    const water = r.water_debt_only === 'YES';
    return nyc.enrichFromLot({source: 'nyc_taxlien', source_ref: `${bbl}:x`, signal: water ? 'Water lien — sale list' : 'Tax lien — sale list',
      category: 'distress', score: water ? 55 : 85, bbl, payload: {}}, lots);
  });
  assert.equal(taxRows[0].score, 100, 'tax lien 85 + historic 15');
  assert.equal(taxRows[1].score, 55, 'water lien, no district');
});

await t('gov: HPD aggregates per building and ignores a lone class-A', () => {
  const per = new Map();
  for (const r of rows.hpd){
    const bbl = nyc.bblOf(r.boroid, r.block, r.lot);
    const cur = per.get(bbl) || {n: 0, c: 0};
    cur.n++; if (String(r.class).toUpperCase() === 'C') cur.c++;
    per.set(bbl, cur);
  }
  const kept = [...per.entries()].filter(([, v]) => v.c >= 1 || v.n >= 5);
  assert.equal(kept.length, 1, 'only the building with a class C or a backlog');
  assert.equal(kept[0][0], '1017190034');
  assert.equal(kept[0][1].n, 6);
  assert.equal(kept[0][1].c, 1);
});

await t('gov: DOB keeps only the primary document and drops stale filings', () => {
  const since = '2026-08-09';
  const kept = rows.dob.filter(r => {
    if (String(r.doc__) !== '01') return false;
    const m = String(r.pre__filing_date).match(/^(\d{2})\/(\d{2})\/(\d{4})/);
    const iso = m ? `${m[3]}-${m[1]}-${m[2]}` : '';
    return iso >= since;
  });
  assert.equal(kept.length, 1);
  assert.equal(kept[0].job__, 'J123');
});

// ---- inbox end to end through the parser + enrichment ----
await t('inbox: alert email becomes an enriched, watch-matched signal', async () => {
  const {parseListingEmail, enrich} = await import('../netlify/functions/lib/parse-listing-email.mjs');
  const sigs = parseListingEmail({
    from: 'StreetEasy <noreply@mail.streeteasy.com>',
    subject: 'New listing in your saved search',
    date: '2026-09-08T11:00:00Z',
    html: `<table><tr><td><a href="https://streeteasy.com/building/254-w-121st-street?utm_source=alert">254 W 121st Street</a></td></tr>
           <tr><td>Harlem, Manhattan</td></tr><tr><td>$3,100,000 &middot; 8 units</td></tr></table>`,
  });
  assert.equal(sigs.length, 1);
  const {blocks} = await nyc.lotsFor(AREA);
  await enrich(sigs, nyc.geocode, {wa1: blocks});
  assert.equal(sigs[0].bbl, '1017190034');
  assert.equal(sigs[0].watch_area_id, 'wa1', 'inside Harlem');
  assert.equal(sigs[0].score, 60, '40 base + 20 for being in a watched area');
  assert.equal(sigs[0].amount, 3100000);
  assert.equal(sigs[0].payload.units, 8);
  assert.ok(!sigs[0].source_ref.includes('utm_'));
});

await t('inbox: a listing outside every watch area still files, without the bonus', async () => {
  const {parseListingEmail, enrich} = await import('../netlify/functions/lib/parse-listing-email.mjs');
  const sigs = parseListingEmail({
    from: 'StreetEasy <noreply@mail.streeteasy.com>', subject: 'New listing',
    html: `<div><a href="https://streeteasy.com/building/140-prospect-place">140 Prospect Place</a></div><div>$3,495,000</div>`,
  });
  const {blocks} = await nyc.lotsFor(AREA);
  await enrich(sigs, nyc.geocode, {wa1: blocks});
  assert.equal(sigs[0].bbl, '3011450034', 'geocoded');
  assert.equal(sigs[0].watch_area_id, undefined, 'Brooklyn block is not in the Harlem watch');
  assert.equal(sigs[0].score, 40);
});

// ---- the new feeds, exercised through the real module ----
const gov = await import('../netlify/functions/harvest-gov.mjs');
const SINCE = '2026-08-09';

await t('nyc: DS carries every verified dataset id', () => {
  assert.equal(nyc.DS.sales, 'w2pb-icbu');
  assert.equal(nyc.DS.ecb, '6bgk-3dad');
  assert.equal(nyc.DS.dobViol, '3h2n-5cm9');
  assert.equal(nyc.DS.dobNow, 'rbx6-tga4');
  assert.equal(nyc.DS.hpdReg, 'tesw-yqqr');
  assert.equal(nyc.DS.hpdContact, 'feu5-w2e2');
});

await t('nyc: normDate reads ISO, US and bare YYYYMMDD', () => {
  assert.equal(nyc.normDate('2026-08-15T00:00:00.000'), '2026-08-15');
  assert.equal(nyc.normDate('08/15/2026'), '2026-08-15');
  assert.equal(nyc.normDate('20260815'), '2026-08-15');
  assert.equal(nyc.normDate(''), '');
  assert.equal(nyc.ymd('2026-08-15'), '20260815');
});

await t('sales: files a price, a $/sf and the block median', async () => {
  const {lots, blocks} = await nyc.lotsFor(AREA);
  const out = await gov.sales(AREA, lots, blocks, SINCE);
  const one = out.find(r => r.bbl === '1017190034');
  assert.equal(one.amount, 4320000);
  assert.equal(one.payload.price_per_sf, 600);
  assert.equal(one.category, 'traded');
  assert.equal(one.score, 65, '50 base + 15 historic district');
  assert.ok(one.signal.includes('$4,320,000'));
  assert.ok(!out.some(r => r.amount <= 10000), 'a $1 transfer is not a comp');
  assert.equal(out.length, 3);
});

await t('sales: a thin trade on the block gets the extra look', async () => {
  const {lots, blocks} = await nyc.lotsFor(AREA);
  const out = await gov.sales(AREA, lots, blocks, SINCE);
  const thin = out.find(r => r.bbl === '1019050011');       // $2.5m / 5000sf = $500/sf
  assert.equal(thin.payload.price_per_sf, 500);
  assert.equal(thin.score, 60, '50 base + 10 for a sub-$600/sf trade, no district');
});

await t('ecb: aggregates active balance per lot and ignores resolved rows', async () => {
  const {lots, blocks} = await nyc.lotsFor(AREA);
  const out = await gov.ecbViolations(AREA, lots, blocks, SINCE);
  assert.equal(out.length, 1, 'the $400 single ticket is noise');
  const r = out[0];
  assert.equal(r.bbl, '1017190034');
  assert.equal(r.payload.balance_due, 30000, 'the $90k resolved violation is excluded');
  assert.equal(r.payload.active_count, 2);
  assert.equal(r.amount, 30000);
  assert.equal(r.occurred_on, '2026-08-20');
  assert.equal(r.score, 40 + 15 + 2 + 15, 'base + balance band + count + historic district');
});

await t('ecb: address comes from PLUTO when the dataset has none', async () => {
  const {lots, blocks} = await nyc.lotsFor(AREA);
  const out = await gov.ecbViolations(AREA, lots, blocks, SINCE);
  assert.equal(out[0].address, '254 W 121 ST');
});

await t('dobviol: counts only ACTIVE and needs more than one', async () => {
  const {lots, blocks} = await nyc.lotsFor(AREA);
  const out = await gov.dobViolations(AREA, lots, blocks, SINCE);
  assert.equal(out.length, 1);
  assert.equal(out[0].payload.open_count, 2, 'the dismissed row is dropped');
  assert.ok(out[0].payload.types.includes('LL1181'));
});

await t('dobnow: issued permits since the window, with owner and contractor', async () => {
  const {lots, blocks} = await nyc.lotsFor(AREA);
  const out = await gov.nowPermits(AREA, lots, blocks, SINCE);
  assert.equal(out.length, 1, '2019 permit is outside the window');
  const r = out[0];
  assert.equal(r.source, 'nyc_dobnow');
  assert.equal(r.score, 45 + 10 + 15, 'major work + big cost + historic district');
  assert.equal(r.payload.permit_owner, '121 West Realty Llc');
  assert.equal(r.payload.owner, '121 WEST REALTY LLC', 'PLUTO owner of record stays authoritative');
  assert.equal(r.payload.contractor, 'Smartdesign Nyc');
  assert.equal(r.amount, null, 'an applicant cost estimate is not a price');
  assert.equal(r.source_ref, 'B00123456-I1:B00123456-I1-GC');
});

// ---- owner behind the LLC ----
await t('owner: HPD registration resolves the LLC to a person and an address', async () => {
  const {ownerFor} = await import('../netlify/functions/lib/owner.mjs');
  const o = await ownerFor('1', '1719', '34');
  assert.equal(o.registered, true);
  assert.equal(o.registration_id, '900123', 'the newest registration wins');
  assert.equal(o.principals[0].name, 'Ruth A Delaney');
  assert.ok(o.principals[0].address.startsWith('18 East 66 Street'));
  assert.equal(o.agents[0].company, 'Parkside Management Inc');
  assert.equal(o.people.filter(p => p.name === 'Ruth A Delaney').length, 1, 'duplicate contact rows collapse');
  assert.equal(o.people[0].role, 'HeadOfficer', 'principals sort first');
});

// ---- the property dossier endpoint ----
await t('property: one address returns lot, owner, comps, violations and permits', async () => {
  const property = (await import('../netlify/functions/property.mjs')).default;
  const res = await property(req('/api/property?address=254%20W%20121st%20Street'));
  const d = await res.json();
  assert.equal(d.bbl, '1017190034');
  assert.equal(d.block, '1719');
  assert.equal(d.tax_lot, '34');
  assert.equal(d.lot.building_class, 'C7');
  assert.equal(d.lot.historic_district, 'Mount Morris Park Historic District');
  assert.equal(d.owner.principals[0].name, 'Ruth A Delaney');
  assert.equal(d.sales.this_lot[0].price, 4320000);
  assert.ok(d.sales.block_median_psf > 0);
  assert.equal(d.violations.ecb.balance_due, 30000);
  assert.equal(d.violations.hpd.class_c, 1);
  assert.equal(d.permits.dob_now[0].permit, 'B00123456-I1-GC');
  assert.ok(d.acris.length >= 1);
});

await t('property: an unresolvable address 404s instead of guessing', async () => {
  const property = (await import('../netlify/functions/property.mjs')).default;
  const res = await property(req('/api/property?address=nowhere%20at%20all'));
  assert.equal(res.status, 404);
});

await t('property: include= trims the work to what the caller asked for', async () => {
  const property = (await import('../netlify/functions/property.mjs')).default;
  const res = await property(req('/api/property?bbl=1017190034&include=owner'));
  const d = await res.json();
  assert.ok(d.owner);
  assert.equal(d.sales, undefined);
  assert.equal(d.violations, undefined);
});

console.log(`\n${pass} passed, ${fail} failed`);
process.exit(fail ? 1 : 0);
