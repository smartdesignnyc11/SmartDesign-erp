import asyncio, json, os
from playwright.async_api import async_playwright
OUT='/mnt/user-data/outputs/screens/'
# Stub the outside services the screen talks to: ArcGIS (SHPO/HUD), DCP tracts, GeoSearch, PLUTO, Leaflet CDN.
def poly(cx, cy, r=0.01):
    return {"type":"Polygon","coordinates":[[[cx-r,cy-r],[cx+r,cy-r],[cx+r,cy+r],[cx-r,cy+r],[cx-r,cy-r]]]}
HARLEM=(-73.947, 40.808)
def feats(props, cx=HARLEM[0], cy=HARLEM[1], r=0.02, geom=None):
    return {"type":"FeatureCollection","features":[{"type":"Feature","properties":props,"geometry":geom or poly(cx,cy,r)}]}
async def route(r):
    u = r.request.url
    if 'leaflet.min.js' in u:
        return await r.fulfill(status=200, content_type='application/javascript', body=open('/tmp/leaflet.js').read())
    if 'tile.openstreetmap' in u:
        return await r.fulfill(status=200, content_type='image/png', body=b'')
    if 'leaflet.min.css' in u:
        return await r.fulfill(status=200, content_type='text/css', body=open('/tmp/leaflet.css').read())
    if '?f=json' in u:
        # layer directory: names deliberately out of order so index fallback would be wrong
        if 'National_Register' in u: L=[{"id":13,"name":"National Register Building Listings"}]
        elif 'District_USN' in u: L=[{"id":4,"name":"Building District USN Polygons"}]
        elif 'Qualifying_Census' in u: L=[{"id":7,"name":"State Commercial Program Qualifying Tracts"},{"id":9,"name":"State Homeowner Program Qualifying Tracts"}]
        elif 'Opportunity_Zones' in u: L=[{"id":13,"name":"Opportunity Zones"}]
        else: L=[{"id":2,"name":"Building USN Points"}]
        return await r.fulfill(status=200, content_type='application/json', body=json.dumps({"layers":L}))
    if '/query' in u:
        if 'National_Register' in u:
            body = feats({"ResourceName":"Mount Morris Park Historic District","DateNR":"1971-03-16"})
        elif 'District_USN' in u:
            body = feats({"ResourceName":"Hamilton Heights / Sugar Hill NW","Eligibility_Status":"Eligible for the National Register"}, -73.951, 40.822, 0.006)
        elif 'Qualifying_Census' in u:
            com = '/7/' in u
            # the real service ships every tract with a sentence status; two qualify, two do not
            fc = {"type":"FeatureCollection","features":[
              {"type":"Feature","properties":{"Tract_Name":"New York County Census Tract 226.01","Tract_Number":"226.01","Tract_Qualifying_Status_EXT_Leg":("Qualifies for state commercial program" if com else "Qualifies for state homeowner program")},"geometry":poly(-73.947,40.808,0.02)},
              {"type":"Feature","properties":{"Tract_Name":"New York County Census Tract 999","Tract_Number":"999","Tract_Qualifying_Status_EXT_Leg":("Does not qualify for state commercial program" if com else "Does not qualify for state homeowner program")},"geometry":poly(-73.99,40.75,0.02)}]}
            body = fc
        elif 'Opportunity_Zones' in u:
            body = feats({"GEOID10":"36061022601"})
        else:
            body = feats({"ResourceName":"254 W 121st Street","Eligibility_Status":"Eligible for the National Register"}, -73.9475, 40.8085, 0, geom={"type":"Point","coordinates":[-73.9475,40.8085]})
        return await r.fulfill(status=200, content_type='application/json', body=json.dumps(body))
    if 'weqx-t5xr' in u:
        # DCP clipped tracts: same keys so the shoreline join matches
        fc={"type":"FeatureCollection","features":[
            {"type":"Feature","properties":{"borocode":"1","ct2020":"022601"},"geometry":poly(-73.947,40.808,0.019)},
            {"type":"Feature","properties":{"borocode":"1","ct2020":"099900"},"geometry":poly(-73.99,40.75,0.019)},
            {"type":"Feature","properties":{"borocode":"1","ct2020":"099800"},"geometry":poly(-73.99,40.75,0.019)}]}
        return await r.fulfill(status=200, content_type='application/json', body=json.dumps(fc))
    if 'geosearch' in u:
        f={"type":"Feature","properties":{"name":"254 W 121ST STREET","label":"254 W 121st Street, Manhattan, NY, USA","borough":"Manhattan","postalcode":"10027","addendum":{"pad":{"bbl":"1017190034","bin":"1054321"}}},"geometry":{"type":"Point","coordinates":[-73.9475,40.8085]}}
        return await r.fulfill(status=200, content_type='application/json', body=json.dumps({"features":[f]}))
    if '64uk-42ks' in u:
        row=[{"bbl":"1017190034","address":"254 WEST 121 STREET","bldgclass":"C7","ownername":"121 WEST REALTY LLC","yearbuilt":"1899","numfloors":"4","numbldgs":"1","unitsres":"8","unitstotal":"9","lotarea":"1800","bldgarea":"6400","zonedist1":"R7-2","builtfar":"3.56","residfar":"3.44","commfar":"0","facilfar":"6.5","landmark":"","histdist":"Mount Morris Park Historic District"}]
        return await r.fulfill(status=200, content_type='application/json', body=json.dumps(row))
    return await r.continue_()
async def main():
    async with async_playwright() as p:
        b = await p.chromium.launch()
        for name, vp in [('d',{'width':1400,'height':960}), ('m',{'width':390,'height':844})]:
            ctx = await b.new_context(viewport=vp, is_mobile=(name=='m'))
            await ctx.route('**/*', route)
            pg = await ctx.new_page(); errs=[]
            pg.on('pageerror', lambda e: errs.append(str(e)))
            pg.on('console', lambda m: errs.append('console:'+m.text) if m.type=='error' and 'ERR_' not in m.text else None)
            await pg.goto('file:///home/claude/erp/smartdesigns_projects.html'); await pg.wait_for_timeout(800)
            await pg.click('#signin button:has-text("Alan")'); await pg.wait_for_timeout(600)
            await pg.evaluate("setWorkspace('mb'); view='mbscreen'; render()"); await pg.wait_for_timeout(3000)
            print(name, 'nav button', await pg.locator('#nav-mb [data-v="mbscreen"]').count(), 'map', await pg.locator('#mbs-map .leaflet-container, #mbs-map.leaflet-container').count(), 'layer counts', await pg.evaluate("MBS_KEYS.map(k=>k+':'+(MBS.store[k]||[]).length).join(' ')"))
            print(name, 'resolved by name', await pg.evaluate("MBS_KEYS.map(k=>k+'='+MBS_L[k].how).join(' ')"), 'diag', await pg.evaluate("JSON.stringify(MBS.diag)"), 'failed', await pg.evaluate("JSON.stringify(MBS.failed)"))
            print(name, 'tract filter kept only qualifying', await pg.evaluate("MBS.store.com.length===1 && MBS.store.home.length===1"), 'clip note', await pg.evaluate("document.querySelector('#mbs-c-com').closest('.mbs-lyr').querySelector('.sb').textContent"))
            await pg.fill('#mbs-q', '254 W 121'); await pg.wait_for_timeout(400)
            print(name, 'autocomplete rows', await pg.locator('#mbs-ac div[data-i]').count())
            await pg.locator('#mbs-ac div[data-i]').first.click(); await pg.wait_for_timeout(1200)
            print(name, 'chips', (await pg.inner_text('#mbs-chips')).replace('\n',' · '))
            for t in ['reg','com','home','oz']:
                print(name, ' ', t, '→', (await pg.inner_text('#mbs-t-'+t)).replace('\n',' | ')[:150])
            await pg.screenshot(path=f'{OUT}mbs_screen_{name}.png')
            await pg.evaluate("mbsTab('lot')"); await pg.wait_for_timeout(600)
            lot = await pg.inner_text('#mbs-lot')
            print(name, 'lot has FAR headroom', 'unused floor area' in lot or 'Built out at or above' in lot, '| LPC line', 'Mount Morris' in lot, '| warns LPC≠Register', 'City Landmarks Commission' in lot)
            await pg.screenshot(path=f'{OUT}mbs_lot_{name}.png')
            await pg.evaluate("mbsTab('screen')"); await pg.click('#mbs-save'); await pg.wait_for_timeout(600)
            print(name, 'saved', await pg.evaluate("DB.mbinc.screens.length"), 'state', await pg.evaluate("JSON.stringify((s=>({reg:s.regState,com:s.com,home:s.home,oz:s.oz,bbl:s.bbl,deal:!!s.dealId,verified:!!s.verifiedBy}))(DB.mbinc.screens[0]))"))
            await pg.screenshot(path=f'{OUT}mbs_saved_{name}.png')
            # watchlist signals
            await pg.evaluate("view='mbwatch'; render()"); await pg.wait_for_timeout(700)
            print(name, 'signals card', await pg.locator('#mb-signals').count(), 'rows', await pg.locator('#mb-signals .mbs-saved').count(), 'watch badge', await pg.evaluate("$('#n-mbwatch').textContent"))
            await pg.screenshot(path=f'{OUT}mbs_signals_{name}.png', full_page=True)
            await pg.locator('#mb-signals [data-mbsig-dismiss]').first.click(); await pg.wait_for_timeout(400)
            print(name, 'after dismiss', await pg.evaluate("DB.mbinc.signals.filter(s=>s.status==='dismissed').length"), 'rows', await pg.locator('#mb-signals .mbs-saved').count())
            # promote a signal to a deal
            n0 = await pg.evaluate("DB.deals.length")
            await pg.locator('#mb-signals [data-mbsig-promote]').first.click(); await pg.wait_for_timeout(500)
            print(name, 'promote opened capture modal', await pg.locator('#mbm').count(), 'prefill', (await pg.evaluate("$('#mbm textarea, #mbm input')?.value")or'')[:60])
            await pg.click('#mbm-cancel'); await pg.wait_for_timeout(300)
            # deal → Incentives
            await pg.evaluate("mbOpen(DB.deals[0].id, 'inc')"); await pg.wait_for_timeout(700)
            print(name, 'inc tab in side nav', await pg.locator('#mb-deal [data-mbtab="inc"]').count(), 'body', (await pg.inner_text('#mb-deal .mb-main')).replace('\n',' | ')[:170])
            await pg.click('#mbs-inc-edit'); await pg.wait_for_timeout(300)
            await pg.fill('#mbm [data-f="qre"]', '2400000'); await pg.fill('#mbm [data-f="basis"]', '1800000')
            await pg.select_option('#mbm [data-f="route"]', 'transfer'); await pg.fill('#mbm [data-f="pricing"]', '0.88')
            await pg.fill('#mbm [data-f="part1"]', '2026-10-01'); await pg.click('#mbm-ok'); await pg.wait_for_timeout(700)
            txt = await pg.inner_text('#mb-deal .mb-main')
            print(name, 'credit math:', ' | '.join([l for l in txt.split('\n') if any(k in l for k in ['Substantial','Federal credit','State commercial credit','Indicative','Route'])])[:230])
            await pg.screenshot(path=f'{OUT}mbs_deal_inc_{name}.png', full_page=True)
            # attach the saved screen to this deal and verify it
            await pg.evaluate("(()=>{const d=DB.deals.find(x=>x.id===mbDealId); DB.mbinc.screens[0].dealId=d.id; save(); render();})()"); await pg.wait_for_timeout(600)
            print(name, 'screen shows as proposal', 'proposal' in (await pg.inner_text('#mb-deal .mb-main')).lower())
            await pg.locator('[data-mbsverify]').first.click(); await pg.wait_for_timeout(300)
            await pg.fill('#mbm [data-f="note"]', 'CRIS shows contributing; tract 226.01 on the 2026 list'); await pg.click('#mbm-ok'); await pg.wait_for_timeout(700)
            txt2 = (await pg.inner_text('#mb-deal .mb-main')).lower()
            print(name, 'verified by', await pg.evaluate("DB.mbinc.screens[0].verifiedBy"), '| shows verified', 'verified' in txt2 and 'not verified' not in txt2, '| state credit note cleared', 'does not qualify on the current screen' not in txt2)
            # field role must not see any of it
            await pg.evaluate("signIn('u_angel')"); await pg.wait_for_timeout(700)
            print(name, 'foreman sees mb workspace', await pg.evaluate("mbAccess()"), 'screen in role views', await pg.evaluate("ROLE_VIEWS.foreman.includes('mbscreen')"))
            print(name, 'ERRORS', errs[:4])
            await ctx.close()
        await b.close()
asyncio.run(main())
