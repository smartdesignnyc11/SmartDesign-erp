import asyncio, json, subprocess, time, os
from playwright.async_api import async_playwright
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
MOCK = open(os.path.join(ROOT, 'test', 'mock_supabase.js')).read()
CFG = "window.SDP_CONFIG = {appName:'SmartDesigns Projects', supabaseUrl:'https://mock.supabase.co', supabaseAnonKey:'anon', workspace:'default', aiUrl:'/api/ai'};"
async def main():
    srv = subprocess.Popen(['python3','-m','http.server','8099','-d',os.path.join(ROOT,'public')], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL); time.sleep(0.8)
    try:
        async with async_playwright() as p:
            b = await p.chromium.launch()
            # ---- 1. local mode (no keys): boots as before, name picker, service worker registers ----
            pg = await b.new_page(viewport={'width':390,'height':844}, is_mobile=True); errs=[]; pg.on('pageerror', lambda e: errs.append(str(e)))
            await pg.goto('http://localhost:8099/'); await pg.wait_for_timeout(1500)
            print('local: signin buttons', await pg.locator('#signin [data-signin]').count(), 'sw', await pg.evaluate("navigator.serviceWorker.getRegistration().then(r=>!!r)"), 'manifest', await pg.evaluate("!!document.querySelector('link[rel=manifest]')"), 'cloudOn', await pg.evaluate("cloudOn()"), 'errors', errs)
            await pg.close()
            # ---- 2. cloud mode with the mock server ----
            async def mk(name, mobile=True):
                ctx = await b.new_context(viewport={'width':390,'height':844} if mobile else {'width':1400,'height':960}, is_mobile=mobile, service_workers='block')
                await ctx.route('**/supabase.js', lambda r: r.fulfill(status=200, content_type='application/javascript', body=MOCK))
                await ctx.route('**/config.js*', lambda r: r.fulfill(status=200, content_type='application/javascript', body=CFG))
                page = await ctx.new_page(); e=[]; page.on('pageerror', lambda x: e.append(str(x))); page.on('console', lambda m: e.append('console:'+m.text) if m.type=='error' and 'favicon' not in m.text else None); page._errs = e
                return ctx, page
            ctx, pg = await mk('angel')
            await pg.goto('http://localhost:8099/'); await pg.wait_for_timeout(1200)
            print('cloud: signin form', await pg.locator('#cl-form').count(), 'waiting', await pg.evaluate("window.__cloudWait===true"))
            await pg.fill('#cl-email', 'angel@smartdesign.nyc'); await pg.fill('#cl-pass', 'wrong'); await pg.click('#cl-form button'); await pg.wait_for_timeout(300)
            print('cloud: wrong pass →', await pg.inner_text('#cl-status'))
            await pg.fill('#cl-pass', 'test1234'); await pg.click('#cl-form button'); await pg.wait_for_timeout(2500)
            print('cloud: booted', await pg.evaluate("document.body.dataset.booted"), 'role', await pg.evaluate("role()"), 'me', await pg.evaluate("DB.me"), 'view', await pg.evaluate("view"), 'signin hidden', not await pg.evaluate("$('#signin').classList.contains('on')"))
            # first device seeded the demo and pushed it
            await pg.wait_for_timeout(2500)
            rows = await pg.evaluate("Object.keys(window.__mock.rows)")
            print('cloud: rows pushed', len(rows), [r for r in rows if 'project' in r][:4], 'status', await pg.evaluate("$('#save-status').textContent"))
            # foreman (field role) should not see money in what it pulled: reload → pull through the view
            await pg.reload(); await pg.wait_for_timeout(3000)
            print('cloud: after reload role', await pg.evaluate("role()"), 'employees have rate?', await pg.evaluate("DB.employees.some(e=>'rate' in e)"), 'bills present?', await pg.evaluate("!!DB.bills && DB.bills.length>0"), 'projects', await pg.evaluate("DB.projects.length"), 'foreman today rows', await pg.locator('#ftoday-body .f-row').count(), 'errs', pg._errs[:3])
            # make a change → pushed
            await pg.evaluate("DB.field.punch.push({id:'fpX', projectId:S.id, room:'Hall', item:'From phone', status:'open', by:'Angel', at:'2026-09-03T10:00:00', photos:[]}); save()"); await pg.wait_for_timeout(2500)
            print('cloud: field row version', await pg.evaluate("window.__mock.rows['default|field'].version"), 'has punch', await pg.evaluate("window.__mock.rows['default|field'].data.punch.some(x=>x.id==='fpX')"))
            # field role edits a project → server restores the money keys it never saw
            b0 = await pg.evaluate("JSON.stringify(window.__mock.rows['default|project:p121'].data.budget||{}).length")
            await pg.evaluate("task('demo').status='done'; task('demo').actualEnd=today(); save()"); await pg.wait_for_timeout(2500)
            print('cloud: project pushed by foreman — budget kept', await pg.evaluate("JSON.stringify(window.__mock.rows['default|project:p121'].data.budget||{}).length")==b0 and b0>2, 'task done on server', await pg.evaluate("window.__mock.rows['default|project:p121'].data.tasks.find(t=>t.id==='demo').status"), 'materials cost kept', await pg.evaluate("window.__mock.rows['default|project:p121'].data.materials.some(m=>'cost' in m)"))
            # another device (Alan) answers → realtime applies on Angel's phone
            await pg.evaluate("(()=>{ const f = JSON.parse(JSON.stringify(window.__mock.rows['default|field'].data)); f.raises[0].status='answered'; f.raises[0].answer='Two inch. Sheet coming.'; f.raises[0].answeredBy='Alan'; window.__otherDevice('field', f); })()"); await pg.wait_for_timeout(800)
            print('cloud: realtime applied', await pg.evaluate("DB.field.raises[0].status"), 'for-you rows', await pg.locator('#ftoday-body .f-you .f-row').count(), 'status', await pg.evaluate("$('#save-status').textContent"))
            # photo → storage
            await pg.evaluate("putBlob('fTest', 'data:image/png;base64,iVBORw0KGgo=')"); await pg.wait_for_timeout(500)
            print('cloud: file uploaded', await pg.evaluate("Object.keys(window.__mock.files)"))
            await pg.screenshot(path='/mnt/user-data/outputs/screens/cloud_signin_foreman.png')
            # sign out (Switch user) → Alan on the same device/context so the mock store is shared
            await pg.evaluate("showSignIn()"); await pg.wait_for_timeout(1500)
            print('cloud: after sign-out form shown', await pg.locator('#cl-form').count())
            pg2 = await ctx.new_page(); await pg2.set_viewport_size({'width':1400,'height':960}); pg2._errs = []; pg2.on('pageerror', lambda x: pg2._errs.append(str(x)))
            await pg2.goto('http://localhost:8099/'); await pg2.wait_for_timeout(1000)
            await pg2.fill('#cl-email', 'alan@mercerandbond.com'); await pg2.fill('#cl-pass', 'test1234'); await pg2.click('#cl-form button'); await pg2.wait_for_timeout(3000)
            print('alan: role', await pg2.evaluate("role()"), 'me', await pg2.evaluate("DB.me"), 'rates visible', await pg2.evaluate("DB.employees.some(e=>'rate' in e)"), 'bills', await pg2.evaluate("DB.bills.length"), 'punch from phone', await pg2.evaluate("DB.field.punch.some(x=>x.id==='fpX')"))
            await pg2.evaluate("setWorkspace('sd'); setView('proj')"); await pg2.wait_for_timeout(800)
            print('alan: team card', await pg2.locator('#cl-team').count(), 'profiles listed', await pg2.locator('#cl-team .urow').count())
            await pg2.select_option('#cl-team [data-clmap="uid-angel"]', 'u_angel'); await pg2.wait_for_timeout(300)
            print('alan: mapped angel →', await pg2.evaluate("window.__mock.profiles['uid-angel'].app_user_id"))
            await pg2.screenshot(path='/mnt/user-data/outputs/screens/cloud_team_accounts.png', full_page=True)
            print('alan: errs', pg2._errs[:3])
            await ctx.close(); await b.close()
    finally:
        srv.terminate()
asyncio.run(main())
