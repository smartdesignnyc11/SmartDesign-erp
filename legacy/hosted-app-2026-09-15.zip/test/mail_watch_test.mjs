import assert from 'node:assert/strict';
import { simpleParser } from 'mailparser';
import { mailToComm, htmlToText } from '../netlify/functions/lib/mail-to-comm.mjs';
const raw = `From: Janet Sidford <jpsidford@gmail.com>
To: Alan Mishali <alan@smartdesign.nyc>, sarah@smartdesign.nyc
Subject: Fwd: 55 E 65th alteration agreements
Date: Fri, 11 Sep 2026 16:11:52 -0400
Message-ID: <abc123@mail.gmail.com>
MIME-Version: 1.0
Content-Type: multipart/mixed; boundary="b1"

--b1
Content-Type: text/plain; charset=utf-8

Good afternoon Alan and Sarah,

There are three different alteration agreements attached. They also need a COI for the contractor.

Janet
--b1
Content-Type: application/pdf; name="Light Work Agreement.pdf"
Content-Disposition: attachment; filename="Light Work Agreement.pdf"
Content-Transfer-Encoding: base64

JVBERi0xLjQKJcOkw7zDtsOfCg==
--b1--
`;
const p = await simpleParser(raw); const c = mailToComm(p, 'alan@smartdesign.nyc');
assert.equal(c.from.email, 'jpsidford@gmail.com'); assert.equal(c.from.name, 'Janet Sidford');
assert.equal(c.subject, 'Fwd: 55 E 65th alteration agreements'); assert.equal(c.channel, 'email'); assert.equal(c.noise, false);
assert.equal(c.to.length, 2); assert.match(c.text, /three different alteration agreements/);
assert.equal(c.attachments.length, 1); assert.equal(c.attachments[0].name, 'Light Work Agreement.pdf'); assert.match(c.attachments[0].data, /^data:application\/pdf;base64,/);
assert.equal(c.msgId, '<abc123@mail.gmail.com>');
const call = await simpleParser(`From: noreply@posh.com\nSubject: Posh Assist from Aliya Lee Kong\nDate: Wed, 9 Sep 2026 12:34:00 -0400\n\nEXISTING CLIENT: Caller's Full Name : Aliya Lee Kong Phone Number: +13472052491 Regarding: permits for 374 Washington.`);
const cc = mailToComm(call, 'alan@smartdesign.nyc'); assert.equal(cc.channel, 'call'); assert.equal(cc.noise, false);
const junk = await simpleParser(`From: uber@uber.com\nSubject: One last shot at up to 60% off\nDate: Sat, 12 Sep 2026 16:14:00 -0400\n\n<html><body><p>Deals &amp; fewer fees.</p></body></html>`);
const cj = mailToComm(junk, 'alan@smartdesign.nyc'); assert.equal(cj.noise, true); assert.match(cj.text, /Deals & fewer fees/);
assert.equal(htmlToText('<div>Hi<br>there</div><p>ok</p>'), 'Hi\nthere\nok');
console.log('ok   mail-to-comm: headers, body, attachments as data URLs, calls kept, newsletters flagged as noise');

// Notes by Gemini: the Doc link survives, and the message is flagged as a meeting
{
  const g = await simpleParser(`From: Gemini <gemini-notes@google.com>\r\nTo: alan@smartdesign.nyc\r\nSubject: Notes: “121 State St - Schedule Review” Aug 17, 2026\r\nDate: Mon, 17 Aug 2026 15:29:21 +0000\r\nMessage-ID: <g1@google.com>\r\nContent-Type: text/html; charset=utf-8\r\n\r\n<div>Notes from “121 State St” <a href="https://docs.google.com/document/d/abc123_-XYZ/edit?usp=meet_tnfm_email">Open meeting notes</a><div>Summary</div><p>Aligned on the sequence.</p><div>Suggested next steps</div><table><tr><td><span>[Chen Biron] Send Light Photo: Capture an image.</span></td></tr></table></div>`);
  const gm = mailToComm(g, 'alan@smartdesign.nyc');
  assert.equal(gm.meeting, true); assert.equal(gm.noise, false);
  assert.deepEqual(gm.links, ['https://docs.google.com/document/d/abc123_-XYZ/edit?usp=meet_tnfm_email']);
  assert.ok(/Suggested next steps/.test(gm.text) && /\[Chen Biron\] Send Light Photo/.test(gm.text));
  console.log('ok   Gemini notes: meeting flag, Doc link and next steps survive');
}

// v89 — the scheduled calendar sync derives the same keys the app pushes, from the collections rows
{
  const { derive } = await import('../netlify/functions/calendar-sync.mjs');
  const check = (m, c, d) => { assert.ok(c, m + (d ? ' — ' + d : '')); console.log('ok   ' + m); };
  const rows = [
    {name:'project:p1', data:{id:'p1', project:{name:'121 State Street', target:'2026-11-04', out:'2026-11-13'}, actions:[{id:'a1', title:'Meeting: Site walk', due:'2026-09-10', time:'10:00', meeting:true}, {id:'a2', title:'Permit', waitsOn:'John', escalateOn:'2026-09-12'}, {id:'a3', title:'Done thing', status:'done', escalateOn:'2026-09-12', waitsOn:'X'}], decisions:[{id:'d1', name:'Tile', status:'open', due:'2026-09-15'}, {id:'d2', name:'No date', status:'open'}], inspections:[{id:'i1', name:'Plumbing rough', agency:'DOB', date:'2026-09-20', status:'scheduled'}]}},
    {name:'pos', data:[{id:'po1', status:'issued', vendor:'Nemo', number:'PO-1', expected:'2026-09-18', deliveryWindow:'8–3'}]},
    {name:'obligations', data:[{id:'o1', name:'GL policy', status:'active', expires:'2026-10-01', renewLead:30}]},
    {name:'vendors', data:[{id:'v1', name:'Window Works', insuranceExp:'2026-09-30'}]}
  ];
  const E = derive(rows, '2026-09-01', '2026-12-31'); const keys = E.map(e => e.key);
  check('scheduled sync derives meetings, escalations, dated decisions, inspections, deliveries, expiries, renewals, milestones', ['meet|a1','esc|a2','dec|d1','insp|i1','po|po1','obx|o1','obr|o1','vins|v1','target|p1','out|p1'].every(k => keys.includes(k)) && !keys.includes('esc|a3') && !keys.includes('dec|d2'), keys.join(','));
  check('titles carry the kind once', E.find(e => e.key === 'esc|a2').title === 'Escalate: John — Permit' && E.find(e => e.key === 'dec|d1').title === 'Decision due: Tile' && E.find(e => e.key === 'obr|o1').title === 'Renew GL policy' && E.find(e => e.key === 'meet|a1').time === '10:00');
}

// v90 — the hourly job plans renewal tasks and follow-ups past escalation from the collections rows; the QuickBooks pull lands lines once
{
  const check = (m, c, d) => { assert.ok(c, m + (d ? ' — ' + d : '')); console.log('ok   ' + m); };
  const { plan } = await import('../netlify/functions/brain-sync.mjs');
  const rows = [
    {name:'company', data:{name:'SmartDesign', plugins:{'gmail-send':{approval:{'Send a follow-up past its escalation without asking':'auto'}}}}},
    {name:'obligations', data:[{id:'o1', kind:'insurance', name:'GL policy', status:'active', expires:'2026-09-25', renewLead:30, owner:'Office', covers:['p1']}, {id:'o2', kind:'filing', name:'Far off', status:'active', expires:'2027-06-01', renewLead:30, covers:['p1']}]},
    {name:'outbox', data:[]},
    {name:'project:p1', data:{id:'p1', project:{name:'121 State Street', contacts:'John, john@plumbing.com, Plumber'}, actions:[{id:'a1', title:'Plumbing permit', assignee:'Chen Biron', status:'todo', waitsOn:'John', escalateOn:'2026-09-01', createdAt:'2026-08-20'}, {id:'a2', title:'Meter', status:'todo', waitsOn:'Mayor', escalateOn:'2026-09-01'}, {id:'a3', title:'Chased', status:'todo', waitsOn:'John', escalateOn:'2026-09-01', lastChased:'2026-09-10'}], log:[]}}
  ];
  const P = plan(rows, '2026-09-11');
  check('a renewal inside its lead gets a task on the covering project; one far off does not', P.renewals.length === 1 && /Renew GL policy/.test(P.renewals[0]) && rows[3].data.actions.some(a => /^Renew GL policy/.test(a.title) && a.due === '2026-08-26') && rows[1].data[0].taskId && !rows[1].data[1].taskId);
  check('past escalation, with a contact address and the action On Its Own, a follow-up is planned; no address or chased this week, none', P.chases.length === 1 && P.chases[0].a.id === 'a1' && P.chases[0].to.email === 'john@plumbing.com' && /holding for 1[56] working days/.test(P.chases[0].body));
  const P2 = plan([rows[0].data.plugins['gmail-send'].approval['Send a follow-up past its escalation without asking'] = 'ask', rows[0]].slice(1).concat(rows.slice(1)), '2026-09-11');
  check('set to Ask, the job plans no sends', P2.chases.length === 0);
  const { applyTxns } = await import('../netlify/functions/qbo-sync.mjs');
  const txns = []; const j = {purchases:[{id:'101', date:'2026-09-10', amount:77.59, vendor:'Home Depot', account:'Chase Business Checking', desc:'Home Depot · caulk'}], deposits:[{id:'55', date:'2026-09-09', amount:5000, desc:'Klein'}], invoices:[]};
  const n1 = applyTxns(txns, [{id:'ac1', name:'Chase Business Checking'}], j); const n2 = applyTxns(txns, [{id:'ac1', name:'Chase Business Checking'}], j);
  check('QuickBooks lines land once, keyed by id, signed the ledger\'s way', n1 === 2 && n2 === 0 && txns[0].id === 'qbo:101' && txns[0].amt === -77.59 && txns[0].acct === 'ac1' && txns[1].amt === 5000 && txns[0].source === 'quickbooks');
}
