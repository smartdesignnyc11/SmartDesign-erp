// The spec-sheet reader, offline. Real PDF bytes, built here, then read back.
import assert from 'node:assert';
import zlib from 'node:zlib';
import { pdfText, findSku } from '../netlify/functions/lib/pdftext.mjs';

let pass = 0, fail = 0;
const t = (name, fn) => { try { fn(); console.log('ok  ', name); pass++; } catch (e){ console.log('FAIL', name, '—', e.message); fail++; } };

/* Build a minimal but genuine PDF: catalog, pages, one page per content stream, xref-free
   (readers tolerate it and our extractor never looks at the xref). Streams are Flate-compressed,
   which is what real spec sheets use. */
function makePdf(pageStreams, {compress = true} = {}){
  const objs = [];
  const add = s => { objs.push(s); return objs.length; };
  const kidIds = [];
  const contentIds = [];
  for (const body of pageStreams){
    const raw = Buffer.from(body, 'latin1');
    const data = compress ? zlib.deflateSync(raw) : raw;
    const dict = `<< /Length ${data.length}${compress ? ' /Filter /FlateDecode' : ''} >>`;
    contentIds.push(add({dict, data}));
  }
  const fontId = add('<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica >>');
  const pagesId = objs.length + pageStreams.length + 1;
  for (let i = 0; i < pageStreams.length; i++){
    kidIds.push(add(`<< /Type /Page /Parent ${pagesId} 0 R /MediaBox [0 0 612 792] /Resources << /Font << /F1 ${fontId} 0 R >> >> /Contents ${contentIds[i]} 0 R >>`));
  }
  const pid = add(`<< /Type /Pages /Kids [${kidIds.map(k => `${k} 0 R`).join(' ')}] /Count ${kidIds.length} >>`);
  const cat = add(`<< /Type /Catalog /Pages ${pid} 0 R >>`);

  const parts = [Buffer.from('%PDF-1.4\n', 'latin1')];
  objs.forEach((o, i) => {
    const n = i + 1;
    if (typeof o === 'string'){
      parts.push(Buffer.from(`${n} 0 obj\n${o}\nendobj\n`, 'latin1'));
    } else {
      parts.push(Buffer.from(`${n} 0 obj\n${o.dict}\nstream\n`, 'latin1'), o.data, Buffer.from('\nendstream\nendobj\n', 'latin1'));
    }
  });
  parts.push(Buffer.from(`trailer\n<< /Root ${cat} 0 R /Size ${objs.length + 1} >>\n%%EOF\n`, 'latin1'));
  return Buffer.concat(parts);
}
const page = lines => `BT /F1 11 Tf 72 720 Td\n${lines.map(l => `(${l.replace(/([()\\])/g, '\\$1')}) Tj T*`).join('\n')}\nET`;

/* ---------- reading ---------- */
t('reads text out of a Flate-compressed stream', () => {
  const pdf = makePdf([page(['Waterworks Regulator Wall Mount Lavatory Faucet', 'Model RGLS02-UB  Unlacquered Brass'])]);
  const d = pdfText(pdf);
  assert.ok(d.text.includes('Waterframe') === false);
  assert.ok(d.text.includes('RGLS02-UB'), d.text);
  assert.equal(d.pageCount, 1);
});

t('reads an uncompressed stream too', () => {
  const pdf = makePdf([page(['Shaws Original RC3018-WH fireclay sink'])], {compress: false});
  assert.ok(pdfText(pdf).text.includes('RC3018-WH'));
});

t('counts pages and keeps them separate', () => {
  const pdf = makePdf([page(['Page one HSHS12-UB']), page(['Page two rough-in valve R-2801']), page(['Page three'])]);
  const d = pdfText(pdf);
  assert.equal(d.pageCount, 3);
  assert.ok(d.pages[1].includes('R-2801'));
});

t('TJ arrays are read, and a wide kern becomes a space', () => {
  const stream = 'BT /F1 11 Tf 72 700 Td [(RGLS02)-40(-UB)] TJ [(Finish)-400(Unlacquered Brass)] TJ ET';
  const d = pdfText(makePdf([stream]));
  assert.ok(d.text.includes('RGLS02-UB'), 'a tight kern does not split the SKU: ' + d.text);
  assert.ok(/Finish\s+Unlacquered/.test(d.text), 'a wide kern separates the words: ' + d.text);
});

t('hex strings are decoded', () => {
  const d = pdfText(makePdf(['BT /F1 11 Tf 72 700 Td <52474C5330322D5542> Tj ET']));
  assert.ok(d.text.includes('RGLS02-UB'), d.text);
});

t('escaped parentheses inside a string survive', () => {
  const d = pdfText(makePdf([page(['Trim only (valve sold separately) RGLS02-UB'])]));
  assert.ok(d.text.includes('(valve sold separately)'), d.text);
});

t('an image-only page yields no text rather than garbage', () => {
  const pdf = makePdf(['q 100 0 0 100 0 0 cm /Im1 Do Q']);
  const d = pdfText(pdf);
  assert.equal(d.text, '');
  assert.equal(d.pageCount, 0);
});

t('a corrupt stream does not lose the good pages', () => {
  const good = makePdf([page(['Good page RGLS02-UB'])]);
  const broken = Buffer.concat([Buffer.from('1 0 obj\n<< /Length 20 /Filter /FlateDecode >>\nstream\n', 'latin1'), Buffer.from('not deflate data!!!!', 'latin1'), Buffer.from('\nendstream\nendobj\n', 'latin1')]);
  const d = pdfText(Buffer.concat([broken, good]));
  assert.ok(d.text.includes('RGLS02-UB'));
});

/* ---------- the question that matters ---------- */
const SHEET_FAMILY = pdfText(makePdf([page([
  'WATERWORKS REGULATOR WALL MOUNT LAVATORY FAUCET',
  'Available finishes:',
  'RGLS02-CH  Chrome',
  'RGLS02-NK  Nickel',
  'RGLS02-BN  Burnished Nickel',
  'Rough-in valve R-2801 sold separately. Centerline 8 in from finished wall.',
  'Spout height 6-1/4 in above finished counter.',
])])).text;

t('an exact SKU is confirmed', () => {
  const r = findSku(SHEET_FAMILY, 'RGLS02-CH');
  assert.equal(r.found, true);
  assert.equal(r.exact, true);
});

t('hyphens, spaces and case are noise', () => {
  assert.equal(findSku(SHEET_FAMILY, 'rgls02 ch').found, true);
  assert.equal(findSku(SHEET_FAMILY, 'RGLS02CH').found, true);
});

t('the -UB / -CH failure is caught, not waved through', () => {
  const r = findSku(SHEET_FAMILY, 'RGLS02-UB');
  assert.equal(r.found, false, 'the sheet does not carry the brass variant');
  assert.equal(r.family, 'RGLS02');
  assert.ok(r.variants.includes('RGLS02-CH'), r.variants);
  assert.ok(r.variants.includes('RGLS02-NK'));
  assert.ok(!r.variants.includes('RGLS02-UB'));
  assert.ok(/variant/.test(r.reason), r.reason);
});

t('an entirely unrelated sheet is reported as unrelated, not as a family', () => {
  const r = findSku(SHEET_FAMILY, 'MAS366DFMXV');
  assert.equal(r.found, false);
  assert.equal(r.family, undefined);
  assert.ok(/does not appear/.test(r.reason));
});

t('a short stem does not produce a false family match', () => {
  const r = findSku('Model AB-1 and AB-2 shown', 'AB-9');
  assert.equal(r.found, false);
  assert.equal(r.family, undefined, 'two characters is not a stem');
});

t('no SKU to check is said plainly rather than passing', () => {
  const r = findSku(SHEET_FAMILY, '');
  assert.equal(r.found, false);
  assert.ok(/no SKU/.test(r.reason));
});

t('the rough-in facts the field needs are in the text', () => {
  assert.ok(/Centerline 8 in from finished wall/.test(SHEET_FAMILY));
  assert.ok(/valve R-2801 sold separately/.test(SHEET_FAMILY));
});

console.log(`\n${pass} passed, ${fail} failed`);
process.exit(fail ? 1 : 0);
