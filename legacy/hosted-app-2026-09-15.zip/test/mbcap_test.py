import asyncio, json, importlib.util, sys
from playwright.async_api import async_playwright
src = open('/home/claude/erp/mbinc_test.py').read().split('async def main')[0]
ns = {}; exec(compile(src,'stub','exec'), ns)
base_route = ns['route']
CALLS = []
async def route(r):
    u = r.request.url
    if 'geosearch' in u:
        CALLS.append(u)
        import urllib.parse as up
        q = up.parse_qs(up.urlparse(u).query).get('text',[''])[0]
        feats=[]
        if '121' in q or 'carlton' in q.lower():
            feats=[{"type":"Feature","properties":{"name":"254 W 121ST STREET","label":"254 W 121st Street, Manhattan, NY, USA","borough":"Manhattan","neighbourhood":"Harlem","postalcode":"10027","addendum":{"pad":{"bbl":"1017190034","bin":"1054321"}}},"geometry":{"type":"Point","coordinates":[-73.9475,40.8085]}},
                   {"type":"Feature","properties":{"name":"254 W 121ST STREET REAR","label":"254 W 121st Street Rear","borough":"Manhattan","postalcode":"10027","addendum":{"pad":{"bbl":"1017190035","bin":"1054322"}}},"geometry":{"type":"Point","coordinates":[-73.9476,40.8086]}}]
        return await r.fulfill(status=200, content_type='application/json', body=json.dumps({"features":feats}))
    return await base_route(r)
async def main():
    async with async_playwright() as p:
        b=await p.chromium.launch()
        for name, vp in [('d',{'width':1400,'height':960}),('m',{'width':390,'height':844})]:
            ctx=await b.new_context(viewport=vp, is_mobile=(name=='m')); await ctx.route('**/*', route)
            pg=await ctx.new_page(); errs=[]; pg.on('pageerror', lambda e: errs.append(str(e)))
            await pg.goto('file:///home/claude/erp/smartdesigns_projects.html'); await pg.wait_for_timeout(800)
            await pg.click('#signin button:has-text("Alan")'); await pg.wait_for_timeout(500)
            await pg.evaluate("setWorkspace('mb'); view='mbdeals'; render()"); await pg.wait_for_timeout(500)
            await pg.evaluate("mbCaptureModal()"); await pg.wait_for_timeout(300)
            print(name,'modal', await pg.locator('#mb-cap').count(), 'wrapped', await pg.locator('.mb-acwrap #mb-cap').count())
            # types as you go
            await pg.type('#mb-cap', '254 W 121', delay=25); await pg.wait_for_timeout(500)
            print(name,'suggestions', await pg.locator('.mb-acwrap .mbs-ac div[data-i]').count(), '| geosearch calls', len(CALLS))
            await pg.screenshot(path=f'/mnt/user-data/outputs/screens/mbcap_ac_{name}.png')
            # keyboard: down then enter picks, does not submit the modal
            await pg.keyboard.press('ArrowDown'); await pg.keyboard.press('Enter'); await pg.wait_for_timeout(300)
            print(name,'value', await pg.input_value('#mb-cap'), '| modal still open', await pg.locator('#mbm').count(), '| hint', (await pg.inner_text('#mb-cap-pad'))[:90])
            print(name,'pad', await pg.evaluate("JSON.stringify(window.__mbPad)"))
            # a note after the address survives the pick
            await pg.fill('#mb-cap',''); await pg.type('#mb-cap','254 W 121 — broker called, asking 4.2', delay=8); await pg.wait_for_timeout(500)
            n = await pg.locator('.mb-acwrap .mbs-ac div[data-i]').count()
            if n: await pg.locator('.mb-acwrap .mbs-ac div[data-i]').first.click(); await pg.wait_for_timeout(250)
            print(name,'with note →', await pg.input_value('#mb-cap'))
            n0 = await pg.evaluate("DB.deals.length")
            await pg.click('#mbm-ok'); await pg.wait_for_timeout(700)
            print(name,'deal created', await pg.evaluate("DB.deals.length")-n0, '| property', await pg.evaluate("JSON.stringify((p=>({addr:p.address,bbl:p.bbl,bin:p.bin,boro:p.borough,nb:p.neighborhood,geo:!!p.geo,needs:!!p.needsAddress}))(mbProp(DB.deals[DB.deals.length-1])))"))
            # a plain note (no address) must not break anything and must not fire lookups
            c0=len(CALLS)
            await pg.evaluate("view='mbdeals'; render()"); await pg.wait_for_timeout(300); await pg.evaluate("mbCaptureModal()"); await pg.wait_for_timeout(300)
            await pg.type('#mb-cap','https://streeteasy.com/building/xyz', delay=5); await pg.wait_for_timeout(500)
            print(name,'url typed → lookups fired', len(CALLS)-c0, '| dropdown', await pg.locator('.mb-acwrap .mbs-ac.on').count())
            await pg.click('#mbm-cancel'); await pg.wait_for_timeout(200)
            print(name,'ERRORS', errs[:3])
            await ctx.close()
        await b.close()
asyncio.run(main())
