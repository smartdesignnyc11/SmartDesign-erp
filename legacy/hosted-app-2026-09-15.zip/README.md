# SmartDesigns Projects

Design-build ERP for SmartDesign NYC / Mercer & Bond: projects, field (foreman), studio, purchasing, billing, accounting, dashboards, Mercer & Bond deals — one app, phone and desktop.

- `NETLIFY.md` — how to host it (Supabase + Netlify), 30 minutes. Start here.
- `python3 build.py` — rebuild `public/` from the prototype sources (`../erp`).
- `python3 -m http.server 8080 -d public` — run locally (local mode: no sign-in, data stays on the device).
- `npm test` — inbox parser and harvest logic, offline.
- `python3 test/cloud_test.py` — sign-in, sync, realtime and field-role money stripping against a mock server.

## Layout

```
public/              the app (built from src/ by build.py) + cloud.js, config.js, sw.js, manifest, icons
netlify/functions/   ai proxy, signals API, and the three harvest jobs
  lib/parse-listing-email.mjs   the inbox parser — pure, dependency-free, unit-tested
  lib/nyc.mjs                   Socrata, PLUTO, GeoSearch, Supabase helpers
supabase/            schema.sql (app) + mb_incentives.sql (screening and sourcing)
test/                offline tests
```
