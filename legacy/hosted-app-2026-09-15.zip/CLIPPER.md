# The clipper

## What it is

A Chrome extension. Maya is on a vendor's product page; she clicks the toolbar button; the item lands on
the selections board for the right project and room with its SKU, finish, dimensions, price, images and
spec sheet already filled in. Then the board argues with it — see *Verification* below, which is the part
Houzz Pro does not have.

## Why an extension and not just a link box

Ferguson, Wayfair, Build.com and most of the rest will serve a page to a browser and refuse the identical
request from a server. That is not a bug to be worked around; it is their terms. The extension reads the
page the designer already has open, once, because she asked it to. No crawling, no background collection,
one page at a time.

There is a paste-a-link fallback in the board (**Selections → Clip an item**) and a server fetch behind
`GET /api/clip?url=`. It works on the sites that allow it and says so plainly when it does not, rather
than filing a half-empty record that looks complete.

## How it reads a page

Not with AI, mostly. A product page already declares what it is, three or four times over:

| Layer | What it is | Why it is trusted first |
|---|---|---|
| JSON-LD | `<script type="application/ld+json">` | It is what Google reads, so vendors keep it accurate |
| Microdata | `itemprop` attributes | Same reason, older convention |
| OpenGraph | `og:` meta tags | Kept accurate for social previews |
| Spec table | The visible `<table>` / `<dl>` | Where SKU, finish and dimensions usually live |
| The page | `<h1>`, the price element | Last resort |

Each field records which layer produced it, and later layers only fill gaps — JSON-LD is never overwritten
by a guess. Whatever could not be read is **named** on the record (`missing: ["dims"]`) instead of left
quietly blank, because a blank field gets flagged downstream and a wrongly-confident one does not.

The AI step is deliberately small: tidy what was read, and only when a field is still empty. It is
instructed never to supply a value the page did not carry. An invented SKU is worse than no SKU.

Lead time is read from the page too — "6–8 weeks" becomes 56 days, quoting the far end of the range,
because the near end is a sales number.

## Verification — the part that matters

Chen's list of what goes wrong, from the 8 September walkthrough: the link goes to chrome instead of
brass; the link goes to the 18" instead of the 20"; the shower set is priced without the rough-in valve.
Each of those is a check that runs on every item.

**Tier one runs offline.** The clip is kept on the record, so the board can compare what someone typed
against what was actually captured. A designer typing "brass" over a chrome clip is caught with no
network at all.

| Check | Severity | What it catches |
|---|---|---|
| SKU on the record ≠ SKU on the page | Red | The item is not the item |
| Finish mismatch | Red | Brass ordered, chrome arrives |
| Dimension mismatch | Red | A 20" sink in an 18" opening |
| Vendor says discontinued / out of stock | Red | Re-select before it holds the schedule |
| Price moved | Amber / note | The budget line misses unless it is re-approved |
| Companion part likely missing | Amber | Rough-in valve, carrier, drain, nosings, setting materials |
| Spec sheet does not name this SKU | Amber | Multi-item sheets and −X/−Y variants |
| Order-by date has passed | Amber | Buy it today or move the date |
| No SKU, no link, no spec sheet | Amber / note | The record cannot be verified at all |

**An item with an unresolved red check cannot go on a purchase order.** It can be overridden — a person
writes why, and their name and reason are recorded against the order.

Lateness is never red. A late item is a reason to buy it today, not a reason for the system to refuse.

**Tier two re-reads the vendor page** (**Verify** on the item, or **Verify all**). That is what catches a
price change or a discontinuation after the clip was taken.

## Confirming the spec sheet — the document is opened and read

`GET /api/specsheet?url=<pdf>&sku=RGLS02-UB` downloads the document, extracts its text and looks for the
SKU. It does not ask a model whether the SKU is probably in there; a model that has not read the PDF says
yes, and a confident yes is the failure itself.

The reader is about 150 lines and has no dependency. A PDF's text lives in content streams as four
operators — `Tj`, `TJ`, `'` and `"` — usually Flate-compressed. Inflate, pull the strings out, and you
have the words. Hex strings, escaped and nested parentheses, and kerned `TJ` arrays are all handled; a
tight kern does not split `RGLS02` from `-UB`, and a wide one becomes a space.

Matching is loose in one direction and strict in the other. Hyphens, spaces and case are noise:
`rgls02 ch`, `RGLS02CH` and `RGLS02-CH` are the same thing. A missing suffix is **not** noise:

```json
{ "skuVerified": false, "family": "RGLS02",
  "variantsInDocument": ["RGLS02-CH", "RGLS02-NK", "RGLS02-BN"],
  "why": "the sheet covers RGLS02 but not this variant" }
```

That is Alan's −X/−Y case at 00:48:28, and it raises a **red** check on the item, because a sheet for the
chrome version looks identical on the record and sends the field roughing the wrong valve.

A scanned, image-only sheet reports `readable: false` and says a person has to look at it — it never
guesses. Lines mentioning rough-in, centreline, clearance, cut-out or blocking are pulled out and written
onto the item, because that is what the field actually needs before the wall closes.

## Installing it

Development, until it is on the Chrome Web Store:

1. `chrome://extensions` → turn on **Developer mode** → **Load unpacked** → choose the `extension` folder.
2. Pin it to the toolbar.
3. Right-click the icon → **Options** → set the board address (`https://your-site.netlify.app/api/clip`)
   and paste the token.

Then: open a vendor page → click the icon → check the room and FM group → **Send to the board**.
Right-click → *Clip to SmartDesigns* works too.

### Getting a token

**Procurement → Clipper access.** Pick the person, press Issue, copy the token — it is shown once and
then only its SHA-256 hash is kept. A token anyone can look up later is a token that leaks, so the board
lists who holds one and when they last used it, and can revoke it, but cannot show it again.

Each token is bound to a person, so a clip arrives with a name on it: a bad capture traces to someone
rather than to "the clipper". A revoked token is refused with the date it was revoked.

Until the first token is issued the endpoint accepts anonymous clips, because a fresh install where
nobody can clip is a worse failure than an open one on an unpublished address. Set `CLIP_REQUIRE_TOKEN=1`
in Netlify to close that door from the start.

Clips land in a server-side inbox rather than in the board directly, so a clip made on a showroom floor is
waiting when the board is next opened, and two people opening the board never both create the same item —
whoever reads it first claims it.

## The endpoints

| Route | Does |
|---|---|
| `POST /api/clip` | Takes a capture from the extension, tidies it, files it in the inbox |
| `GET /api/clip?url=…` | Server-side fetch fallback; returns `blocked: true` when the vendor refuses |
| `GET /api/clips` | The board pulls new clips as the signed-in user |
| `POST /api/clips` | Claims clips as taken |
| `GET /api/specsheet?url=&sku=` | Opens the PDF and reports whether the SKU is really in it |

`sel_clip` is unique on `(workspace, project, url)`, so clipping the same page twice updates the capture
instead of filling the inbox.

## What it is not

It does not crawl, monitor prices in the background, or collect anything from pages nobody asked about.
It reads one page when a person clicks a button. That is the whole design, and it is why it is allowed to
work on sites a server cannot reach.

## Tests

```bash
npm test        # 21 clipper checks + 15 spec-sheet checks, all offline
```

The clipper tests cover the shapes real vendor pages come in: a graph-wrapped JSON-LD block, a broken block next to a
good one, an offers array with a zero-price decoy, a paragraph masquerading as a spec label, a lead-time
range, a duplicate document link, and a page with nothing machine-readable at all.

The spec-sheet tests build real PDF bytes — catalog, pages, Flate-compressed content streams — and read
them back: a `TJ` array with a tight kern, a hex string, escaped parentheses, an image-only page, a
corrupt stream sitting next to a good one, and the −UB/−CH family case.

No test ever fetches a page or a document.
