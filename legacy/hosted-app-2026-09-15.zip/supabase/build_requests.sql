-- Build requests the ERP sends to the coder (v89)
create table if not exists public.build_requests (
  workspace_id text not null default 'default',
  id text not null,
  title text not null,
  brief text not null,
  status text not null default 'requested',   -- requested | in-session | shipped
  requested_at timestamptz default now(),
  shipped_at timestamptz,
  version text,
  primary key (workspace_id, id)
);
alter table public.build_requests enable row level security;
create policy "office reads build requests" on public.build_requests for select using (workspace_id = public.my_workspace() and public.my_role() in ('owner','pm','coord','design_mgr','controller'));
