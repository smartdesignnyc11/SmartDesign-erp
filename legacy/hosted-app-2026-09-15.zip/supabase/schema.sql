-- SmartDesigns Projects — database schema (run once in Supabase → SQL editor)
-- One row per collection per workspace. Field roles read through a view that strips money keys.

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  email text,
  name text,
  role text not null default 'crew',          -- owner | pm | coord | foreman | crew | driver | client | designer | design_mgr | mb_admin | mb_user | mb_analyst | mb_readonly
  app_user_id text,                            -- the person in the app (DB.users[].id), set by the owner/PM in Settings → Team accounts
  phone text,
  workspace_id text not null default 'default',
  created_at timestamptz default now()
);

create table if not exists public.collections (
  workspace_id text not null default 'default',
  name text not null,                          -- company | clients | pos | time | field | studio | … | project:<id>
  data jsonb not null,
  version integer not null default 1,
  updated_by uuid,
  updated_at timestamptz default now(),
  primary key (workspace_id, name)
);

-- new sign-ups get a profile automatically (role crew until the office changes it)
create or replace function public.handle_new_user() returns trigger language plpgsql security definer set search_path = public as $$
begin
  insert into public.profiles (id, email, name, role) values (new.id, new.email, coalesce(new.raw_user_meta_data->>'name', split_part(new.email,'@',1)), coalesce(new.raw_user_meta_data->>'role','crew'))
  on conflict (id) do nothing;
  return new;
end $$;
drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created after insert on auth.users for each row execute procedure public.handle_new_user();

create or replace function public.my_role() returns text language sql stable security definer set search_path = public as $$
  select coalesce((select role from public.profiles where id = auth.uid()), 'none');
$$;
create or replace function public.my_workspace() returns text language sql stable security definer set search_path = public as $$
  select coalesce((select workspace_id from public.profiles where id = auth.uid()), 'default');
$$;
create or replace function public.is_office() returns boolean language sql stable as $$
  select public.my_role() in ('owner','pm','coord','designer','design_mgr','mb_admin','mb_user','mb_analyst','mb_readonly');
$$;

-- strip money from JSON for field roles: any key in the list, at any depth, in arrays too
create or replace function public.strip_money(j jsonb) returns jsonb language plpgsql immutable as $$
declare k text; v jsonb; out jsonb; keys text[] := array['rate','burden','billRate','price','cost','total','amount','amt','contract','retainer','budget','margin','minMargin','gross','taxes','fee','deposit','paid','balance','bank','routing','account','ein','salary','pay','payroll','bills','invoices','payments','changeOrders','estimates','costVar','ap','txns','accounts','byCode','sov','lines_price'];
begin
  if j is null then return null; end if;
  if jsonb_typeof(j) = 'object' then
    out := '{}'::jsonb;
    for k, v in select * from jsonb_each(j) loop
      if k = any(keys) then continue; end if;
      out := out || jsonb_build_object(k, public.strip_money(v));
    end loop;
    return out;
  elsif jsonb_typeof(j) = 'array' then
    select coalesce(jsonb_agg(public.strip_money(e)), '[]'::jsonb) into out from jsonb_array_elements(j) e;
    return out;
  else
    return j;
  end if;
end $$;

-- what each role may read: office roles everything; field/design/client roles the working collections, money stripped
create or replace view public.collections_view with (security_invoker = false) as
  select c.workspace_id, c.name, c.version, c.updated_by, c.updated_at,
         case when public.is_office() then c.data else public.strip_money(c.data) end as data
  from public.collections c
  where c.workspace_id = public.my_workspace()
    and (public.is_office()
         or c.name not in ('bills','payroll','accounts','txns','rules','vendorStats','audit','lib','catalog','deals','properties','mb'));
grant select on public.collections_view to authenticated;

alter table public.profiles enable row level security;
alter table public.collections enable row level security;

drop policy if exists "profiles: read own or office" on public.profiles;
create policy "profiles: read own or office" on public.profiles for select to authenticated using (id = auth.uid() or public.my_role() in ('owner','pm'));
drop policy if exists "profiles: office edits" on public.profiles;
create policy "profiles: office edits" on public.profiles for update to authenticated using (public.my_role() in ('owner','pm')) with check (public.my_role() in ('owner','pm'));

-- reads go through the view (which runs as owner); direct table reads only for office roles
drop policy if exists "collections: office read" on public.collections;
create policy "collections: office read" on public.collections for select to authenticated using (workspace_id = public.my_workspace() and public.is_office());
-- writes: any signed-in member of the workspace, except money collections which only office roles may write
drop policy if exists "collections: write" on public.collections;
create policy "collections: write" on public.collections for insert to authenticated
  with check (workspace_id = public.my_workspace() and (public.is_office() or name not in ('bills','payroll','accounts','txns','rules','vendorStats','audit','lib','catalog','deals','properties','mb','company','clients')));
drop policy if exists "collections: update" on public.collections;
create policy "collections: update" on public.collections for update to authenticated
  using (workspace_id = public.my_workspace())
  with check (workspace_id = public.my_workspace() and (public.is_office() or name not in ('bills','payroll','accounts','txns','rules','vendorStats','audit','lib','catalog','deals','properties','mb','company','clients')));
drop policy if exists "collections: office delete" on public.collections;
create policy "collections: office delete" on public.collections for delete to authenticated using (workspace_id = public.my_workspace() and public.is_office());

-- realtime on collections (the app refetches through the view, so payload contents never reach field roles unstripped: enable "broadcast changes" without payload if you prefer)
alter publication supabase_realtime add table public.collections;

-- files bucket (photos, documents): create bucket "files" (private) in Storage, then:
insert into storage.buckets (id, name, public) values ('files','files',false) on conflict (id) do nothing;
drop policy if exists "files: members read" on storage.objects;
create policy "files: members read" on storage.objects for select to authenticated using (bucket_id = 'files' and split_part(name,'/',1) = public.my_workspace());
drop policy if exists "files: members write" on storage.objects;
create policy "files: members write" on storage.objects for insert to authenticated with check (bucket_id = 'files' and split_part(name,'/',1) = public.my_workspace());
drop policy if exists "files: members update" on storage.objects;
create policy "files: members update" on storage.objects for update to authenticated using (bucket_id = 'files' and split_part(name,'/',1) = public.my_workspace());

-- ---------- saving ----------
-- Field roles get money-stripped JSON; when they save a collection back, the money keys the server
-- stripped are restored from the stored row (matched by id inside arrays), so nothing is lost.
create or replace function public.restore_money(old jsonb, nw jsonb) returns jsonb language plpgsql immutable as $$
declare k text; v jsonb; out jsonb; e jsonb; o jsonb; i int; keys text[] := array['rate','burden','billRate','price','cost','total','amount','amt','contract','retainer','budget','margin','minMargin','gross','taxes','fee','deposit','paid','balance','bank','routing','account','ein','salary','pay','payroll','bills','invoices','payments','changeOrders','estimates','costVar','ap','txns','accounts','byCode','sov','lines_price'];
begin
  if nw is null then return old; end if;
  if old is null then return nw; end if;
  if jsonb_typeof(nw) = 'object' and jsonb_typeof(old) = 'object' then
    out := '{}'::jsonb;
    for k, v in select * from jsonb_each(nw) loop
      out := out || jsonb_build_object(k, public.restore_money(old->k, v));
    end loop;
    for k, v in select * from jsonb_each(old) loop
      if k = any(keys) and not (nw ? k) then out := out || jsonb_build_object(k, v); end if;
    end loop;
    return out;
  elsif jsonb_typeof(nw) = 'array' and jsonb_typeof(old) = 'array' then
    out := '[]'::jsonb; i := 0;
    for e in select * from jsonb_array_elements(nw) loop
      o := null;
      if jsonb_typeof(e) = 'object' and e ? 'id' then
        select x into o from jsonb_array_elements(old) x where jsonb_typeof(x) = 'object' and x->>'id' = e->>'id' limit 1;
      elsif jsonb_array_length(old) > i then
        o := old->i;
      end if;
      out := out || jsonb_build_array(public.restore_money(o, e)); i := i + 1;
    end loop;
    return out;
  else
    return nw;
  end if;
end $$;

-- save many collections in one call: [{name, data, version}] → [{name, version}]
create or replace function public.save_collections(p_items jsonb) returns jsonb language plpgsql security definer set search_path = public as $$
declare it jsonb; nm text; cur record; newv int; result jsonb := '[]'::jsonb; office boolean := public.is_office(); wsid text := public.my_workspace();
  hidden text[] := array['__meta','bills','payroll','accounts','txns','rules','vendorStats','audit','lib','catalog','deals','properties','mb','company','clients'];
begin
  if auth.uid() is null then raise exception 'not signed in'; end if;
  for it in select * from jsonb_array_elements(p_items) loop
    nm := it->>'name';
    if not office and nm = any(hidden) then continue; end if;
    select * into cur from public.collections c where c.workspace_id = wsid and c.name = nm;
    if found then
      newv := cur.version + 1;
      update public.collections set data = case when office then it->'data' else public.restore_money(cur.data, it->'data') end, version = newv, updated_by = auth.uid(), updated_at = now()
        where workspace_id = wsid and name = nm;
    else
      newv := 1;
      insert into public.collections (workspace_id, name, data, version, updated_by) values (wsid, nm, it->'data', 1, auth.uid());
    end if;
    result := result || jsonb_build_array(jsonb_build_object('name', nm, 'version', newv));
  end loop;
  return result;
end $$;
grant execute on function public.save_collections(jsonb) to authenticated;

create or replace function public.delete_collections(p_names text[]) returns void language plpgsql security definer set search_path = public as $$
begin
  if not public.is_office() then raise exception 'office roles only'; end if;
  delete from public.collections where workspace_id = public.my_workspace() and name = any(p_names);
end $$;
grant execute on function public.delete_collections(text[]) to authenticated;
