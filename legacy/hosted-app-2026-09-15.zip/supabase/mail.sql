-- Mail watch: the firm's mailbox lands here (one row per message), the app reads it into Messages.
-- Run once in Supabase → SQL editor, after schema.sql.

create table if not exists public.mail_inbox (
  workspace_id text not null default 'default',
  msg_id text not null,                         -- RFC Message-ID (or a hash of headers when absent)
  mailbox text not null,                        -- the address watched
  uid integer,                                  -- IMAP UID in that mailbox
  payload jsonb not null,                       -- the shape cmImport() takes (from, to, subject, text, attachments…)
  noise boolean not null default false,         -- newsletters, receipts for rides, social — kept, not shown
  imported boolean not null default false,      -- the app has read it into DB.comms
  imported_at timestamptz,
  created_at timestamptz default now(),
  primary key (workspace_id, msg_id)
);
create index if not exists mail_inbox_pending on public.mail_inbox (workspace_id, imported, created_at);

create table if not exists public.mail_cursor (
  workspace_id text not null default 'default',
  mailbox text not null,
  last_uid integer not null default 0,
  uidvalidity bigint,
  updated_at timestamptz default now(),
  primary key (workspace_id, mailbox)
);

alter table public.mail_inbox enable row level security;
alter table public.mail_cursor enable row level security;
-- office roles read and mark; nobody in the field sees the firm's mail; only the watcher (service role) inserts
drop policy if exists mail_inbox_office_read on public.mail_inbox;
create policy mail_inbox_office_read on public.mail_inbox for select using (
  workspace_id = public.my_workspace() and public.my_role() in ('owner','pm','coord','designer','design_mgr','billing','controller'));
drop policy if exists mail_inbox_office_mark on public.mail_inbox;
create policy mail_inbox_office_mark on public.mail_inbox for update using (
  workspace_id = public.my_workspace() and public.my_role() in ('owner','pm','coord','designer','design_mgr','billing','controller'))
  with check (workspace_id = public.my_workspace());
