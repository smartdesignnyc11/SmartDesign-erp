-- Mercer & Bond · incentive screening and deal sourcing (run after schema.sql)
-- Boundaries live here so the client queries your database, not four third-party services on every page load.
create extension if not exists postgis;

create table if not exists public.mb_boundary (
  id bigserial primary key,
  layer text not null,                 -- register_listing | inventoried_district | tract_commercial | tract_homeowner | opportunity_zone
  source text not null,                -- oprhp | hud
  source_ref text,
  name text,
  status_text text,                    -- verbatim source determination, never paraphrased
  qualifies boolean,
  effective_from date, effective_to date,
  attrs jsonb,
  geom geometry(MultiPolygon, 4326) not null,
  ingested_at timestamptz not null default now()
);
create index if not exists mb_boundary_gix on public.mb_boundary using gist (geom);
create index if not exists mb_boundary_layer on public.mb_boundary (layer);

create table if not exists public.mb_inventory_point (
  id bigserial primary key,
  usn text, name text, status_text text, eligible boolean,
  geom geometry(Point, 4326) not null
);
create index if not exists mb_inv_gix on public.mb_inventory_point using gist (geom);

create table if not exists public.mb_watch_area (
  id uuid primary key default gen_random_uuid(),
  workspace_id text not null default 'default',
  label text not null,
  kind text not null default 'neighborhood',   -- neighborhood | blocks | streets | polygon
  borough text, cds text[], blocks text[],
  geom geometry(MultiPolygon, 4326),
  filters jsonb, active boolean default true,
  created_by uuid, created_at timestamptz default now()
);

create table if not exists public.mb_signal (
  id uuid primary key default gen_random_uuid(),
  workspace_id text not null default 'default',
  watch_area_id uuid references public.mb_watch_area(id),
  source text not null,               -- acris | nyc_taxlien | nyc_hpd | nyc_ecb | nyc_dobviol | nyc_dob | nyc_dobnow | nyc_sales | courts_ny | courts_kings | inbox | rls
  source_ref text not null,
  signal text not null, category text not null, score int,
  bbl text, address text, occurred_on date, amount numeric,
  payload jsonb,
  status text default 'new',          -- new | reviewed | dismissed | promoted
  created_at timestamptz default now(),
  unique (source, source_ref)
);
create index if not exists mb_signal_ws on public.mb_signal (workspace_id, status, occurred_on desc);

-- one point → all four determinations, in the database rather than ray-casting in the browser
create or replace function public.mb_screen_point(p_lon double precision, p_lat double precision)
returns jsonb language sql stable security definer set search_path = public as $$
  with pt as (select st_setsrid(st_makepoint(p_lon, p_lat), 4326) g)
  select jsonb_build_object(
    'register', (select jsonb_agg(jsonb_build_object('name', b.name, 'status', b.status_text))
                 from mb_boundary b, pt where b.layer='register_listing' and st_contains(b.geom, pt.g)),
    'district', (select jsonb_agg(jsonb_build_object('name', b.name, 'status', b.status_text))
                 from mb_boundary b, pt where b.layer='inventoried_district' and st_contains(b.geom, pt.g)),
    'tract_commercial', (select jsonb_agg(jsonb_build_object('name', b.name, 'status', b.status_text, 'from', b.effective_from, 'to', b.effective_to))
                 from mb_boundary b, pt where b.layer='tract_commercial' and b.qualifies and st_contains(b.geom, pt.g)),
    'tract_homeowner', (select jsonb_agg(jsonb_build_object('name', b.name, 'status', b.status_text))
                 from mb_boundary b, pt where b.layer='tract_homeowner' and b.qualifies and st_contains(b.geom, pt.g)),
    'opportunity_zone', (select jsonb_agg(jsonb_build_object('name', b.name, 'from', b.effective_from, 'to', b.effective_to))
                 from mb_boundary b, pt where b.layer='opportunity_zone' and st_contains(b.geom, pt.g)),
    'nearest_inventory', (select jsonb_build_object('name', i.name, 'status', i.status_text, 'eligible', i.eligible,
                            'metres', round(st_distance(i.geom::geography, pt.g::geography)::numeric))
                 from mb_inventory_point i, pt order by i.geom <-> pt.g limit 1)
  );
$$;
grant execute on function public.mb_screen_point(double precision, double precision) to authenticated;

alter table public.mb_boundary enable row level security;
alter table public.mb_inventory_point enable row level security;
alter table public.mb_watch_area enable row level security;
alter table public.mb_signal enable row level security;
-- M&B stays isolated from SmartDesign: only owner and mb_* roles see any of it
create or replace function public.mb_member() returns boolean language sql stable as $$
  select public.my_role() in ('owner','mb_admin','mb_user','mb_analyst','mb_readonly');
$$;
drop policy if exists "boundaries: mb read" on public.mb_boundary;
create policy "boundaries: mb read" on public.mb_boundary for select to authenticated using (public.mb_member());
drop policy if exists "inventory: mb read" on public.mb_inventory_point;
create policy "inventory: mb read" on public.mb_inventory_point for select to authenticated using (public.mb_member());
drop policy if exists "watch: mb all" on public.mb_watch_area;
create policy "watch: mb all" on public.mb_watch_area for all to authenticated using (public.mb_member() and workspace_id = public.my_workspace()) with check (public.mb_member() and workspace_id = public.my_workspace());
drop policy if exists "signals: mb read" on public.mb_signal;
create policy "signals: mb read" on public.mb_signal for select to authenticated using (public.mb_member() and workspace_id = public.my_workspace());
drop policy if exists "signals: mb write" on public.mb_signal;
create policy "signals: mb write" on public.mb_signal for update to authenticated using (public.mb_member() and workspace_id = public.my_workspace()) with check (public.mb_member() and workspace_id = public.my_workspace());

-- ---------- sourcing: extra columns the harvest jobs write ----------
alter table public.mb_signal add column if not exists reviewed_by uuid;
alter table public.mb_signal add column if not exists reviewed_at timestamptz;
alter table public.mb_signal add column if not exists deal_id uuid;
create index if not exists mb_signal_bbl on public.mb_signal (bbl);
create index if not exists mb_signal_source on public.mb_signal (source, occurred_on desc);

-- Watch areas ship with Harlem active so the first harvest has something to do.
insert into public.mb_watch_area (workspace_id, label, kind, borough, cds, active)
select 'default', 'Harlem', 'neighborhood', '1', array['109','110','111'], true
where not exists (select 1 from public.mb_watch_area where label = 'Harlem');

-- The jobs write with the service-role key, which bypasses RLS. Reads stay restricted to M&B roles
-- by the policies above. This view is what the app lists.
create or replace view public.mb_signal_feed with (security_invoker = true) as
  select s.*,
         (s.payload->>'url')            as url,
         (s.payload->>'portal')         as portal,
         (s.payload->>'lpc_district')   as lpc_district,
         (s.payload->>'owner')          as owner_of_record
  from public.mb_signal s;
grant select on public.mb_signal_feed to authenticated;

-- ---------------------------------------------------------------------------
-- Clipper inbox. The browser extension writes here with the service key; the
-- board reads as the signed-in user and claims what it turns into items.
-- One row per (workspace, project, url) so clipping the same page twice
-- updates the capture instead of filling the inbox with duplicates.
-- ---------------------------------------------------------------------------
create table if not exists public.sel_clip (
  id uuid primary key default gen_random_uuid(),
  workspace_id text not null default 'default',
  project_id text not null default '',
  room text default '', fm text default '',
  qty numeric default 1,
  need_on_site date,
  url text not null,
  vendor text default '',
  clip jsonb not null default '{}'::jsonb,
  status text not null default 'new',        -- new | taken | discarded
  created_by text default '',
  created_at timestamptz not null default now(),
  taken_at timestamptz,
  unique (workspace_id, project_id, url)
);
create index if not exists sel_clip_open on public.sel_clip (workspace_id, status, created_at desc);
alter table public.sel_clip enable row level security;
create policy "clips: read" on public.sel_clip for select to authenticated using (workspace_id = public.my_workspace());
create policy "clips: claim" on public.sel_clip for update to authenticated using (workspace_id = public.my_workspace()) with check (workspace_id = public.my_workspace());

-- ---------------------------------------------------------------------------
-- Clipper tokens. Issued from the board, shown once, stored as a SHA-256 hash
-- so a stolen row is not a working credential. Each is bound to a person, so a
-- clip arrives with a name on it.
-- ---------------------------------------------------------------------------
create table if not exists public.sel_token (
  id text primary key,
  workspace_id text not null default 'default',
  name text not null,
  hash text not null unique,
  hint text default '',
  issued_by text default '',
  created_at timestamptz not null default now(),
  used_at timestamptz,
  revoked_at timestamptz
);
create index if not exists sel_token_live on public.sel_token (workspace_id, hash) where revoked_at is null;
alter table public.sel_token enable row level security;
create policy "tokens: read" on public.sel_token for select to authenticated using (workspace_id = public.my_workspace());
create policy "tokens: write" on public.sel_token for all to authenticated using (workspace_id = public.my_workspace()) with check (workspace_id = public.my_workspace());

-- ---------------------------------------------------------------------------
-- What the 6am job found. One row per finding, keyed by what it is about, so a
-- job that runs every morning does not file the same thing thirty times — and
-- a finding that stops being true is deleted rather than left shouting.
-- ---------------------------------------------------------------------------
create table if not exists public.sel_alert (
  id uuid primary key default gen_random_uuid(),
  workspace_id text not null default 'default',
  kind text not null,                          -- credit-match | credit-orphan | return-expired | return-closing | credit-stale
  alert_key text not null,
  title text not null,
  detail text default '',
  amount numeric,
  severity text default 'warn',                -- info | warn | bad
  ref jsonb not null default '{}'::jsonb,
  first_seen date not null default current_date,
  updated_at timestamptz not null default now(),
  unique (workspace_id, alert_key)
);
create index if not exists sel_alert_live on public.sel_alert (workspace_id, severity, updated_at desc);
alter table public.sel_alert enable row level security;
create policy "alerts: read" on public.sel_alert for select to authenticated using (workspace_id = public.my_workspace());
