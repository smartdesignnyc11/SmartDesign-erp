-- QuickBooks refresh token, rotated by Intuit on every refresh (v90). Server-only: no policies, the admin client reads it.
create table if not exists public.qbo_token (
  workspace_id text primary key default 'default',
  refresh_token text not null,
  updated_at timestamptz default now()
);
alter table public.qbo_token enable row level security;
