// Not configured yet → the app runs locally on this device (no sign-in, no sharing). See config.example.js.
window.SDP_CONFIG = { appName: 'SmartDesigns Projects', aiUrl: '/api/ai' };
