/* SmartDesigns Projects — cloud layer
   One shared database for the whole team (Supabase: Postgres + auth + storage + realtime).
   The app keeps its in-memory DB object; this layer stores it as one row per collection
   (company, clients, pos, time, field, … and one row per project) and merges changes from
   other devices as they happen. Field roles read through a view that strips money keys server-side.
   When no config is present the app runs exactly as before: local, single device. */
window.Cloud = (() => {
  const cfg = window.SDP_CONFIG || {};
  let sb = null, session = null, profile = null, channel = null, onChange = null, dbRef = () => window.DB;
  const last = {};      // name -> JSON string last synced (either direction)
  const versions = {};  // name -> version we hold
  const state = {online: navigator.onLine, syncing:false, pending:false, err:''};
  const on = () => !!(cfg.supabaseUrl && cfg.supabaseAnonKey && window.supabase);
  const ws = () => cfg.workspace || 'default';
  const hash = s => { let h = 0; for (let i=0;i<s.length;i++){ h = (h*31 + s.charCodeAt(i))|0; } return h + ':' + s.length; };

  async function init(){ if (!on()) return false; sb = window.supabase.createClient(cfg.supabaseUrl, cfg.supabaseAnonKey, {auth:{persistSession:true, autoRefreshToken:true}}); const {data} = await sb.auth.getSession(); session = data.session || null; sb.auth.onAuthStateChange((_e, s) => { session = s; }); window.addEventListener('online', () => { state.online = true; if (state.pending) push(dbRef()); }); window.addEventListener('offline', () => { state.online = false; }); return true; }
  const user = () => session?.user || null;
  async function signIn(email, password){ const {data, error} = await sb.auth.signInWithPassword({email, password}); if (error) throw error; session = data.session; profile = null; return session; }
  async function magicLink(email){ const {error} = await sb.auth.signInWithOtp({email, options:{emailRedirectTo: location.origin + location.pathname}}); if (error) throw error; }
  async function resetPassword(email){ const {error} = await sb.auth.resetPasswordForEmail(email, {redirectTo: location.origin + location.pathname}); if (error) throw error; }
  async function signOut(){ try { await sb.auth.signOut(); } catch(e){} session = null; profile = null; }
  async function getProfile(){ if (profile) return profile; if (!user()) return null; const {data, error} = await sb.from('profiles').select('*').eq('id', user().id).maybeSingle(); if (error) throw error; profile = data || null; return profile; }

  // ---- collections ----
  const CORE = ['company','clients','pos','vendors','bills','payroll','time','employees','users','field','studio','accounts','txns','rules','vendorStats','entities','audit','inventory','storeRuns','properties','deals','mb','lib','catalog','codes','dashboards','unrouted','currentId','workspace','notify','role','me','lastMail','deviceUser'];
  function shards(DB){ const out = {}; const meta = {}; for (const k of Object.keys(DB)){ if (k==='projects') continue; if (k.startsWith('__')){ meta[k] = DB[k]; continue; } out[k] = DB[k]; } out.__meta = meta; (DB.projects||[]).forEach(p => { out['project:'+p.id] = p; }); return out; }
  function assemble(rows){ if (!rows.length) return null; const DB = {projects:[]}; for (const r of rows){ if (r.name.startsWith('project:')) DB.projects.push(r.data); else if (r.name==='__meta') Object.assign(DB, r.data||{}); else DB[r.name] = r.data; last[r.name] = hash(JSON.stringify(r.data)); versions[r.name] = r.version; } return DB; }
  async function pullAll(){ const {data, error} = await sb.from('collections_view').select('name,data,version').eq('workspace_id', ws()); if (error) throw error; return assemble(data||[]); }
  async function pullOne(name){ const {data, error} = await sb.from('collections_view').select('name,data,version').eq('workspace_id', ws()).eq('name', name).maybeSingle(); if (error) throw error; return data; }
  // push only the shards that changed; per-collection last-write-wins, versions bump so other devices know
  const HIDDEN = ['__meta','bills','payroll','accounts','txns','rules','vendorStats','audit','lib','catalog','deals','properties','mb','company','clients'];
  const OFFICE = ['owner','pm','coord','designer','design_mgr','mb_admin','mb_user','mb_analyst','mb_readonly'];
  const isOffice = () => OFFICE.includes(profile?.role);
  // push only the shards that changed, through save_collections (the server restores money keys for field roles)
  async function push(DB){ if (!on() || !user()) return {ok:false, msg:'not signed in'}; if (!state.online){ state.pending = true; return {ok:false, msg:'offline — will sync when back'}; } if (state.syncing){ state.pending = true; return {ok:true, msg:'queued'}; }
    state.syncing = true; state.pending = false; const s = shards(DB); const items = []; const names = new Set(Object.keys(s));
    for (const [name, data] of Object.entries(s)){ if (!isOffice() && HIDDEN.includes(name)) continue; const h = hash(JSON.stringify(data)); if (last[name] === h) continue; items.push({name, data, version:(versions[name]||0)+1}); }
    try {
      if (items.length){ const {data:res, error} = await sb.rpc('save_collections', {p_items: items}); if (error) throw error; items.forEach(u => { last[u.name] = hash(JSON.stringify(u.data)); }); (res||[]).forEach(r => { versions[r.name] = r.version; }); }
      if (isOffice()){ const gone = Object.keys(last).filter(n => n.startsWith('project:') && !names.has(n)); if (gone.length){ const {error} = await sb.rpc('delete_collections', {p_names: gone}); if (error) throw error; gone.forEach(n => { delete last[n]; delete versions[n]; }); } }
      state.err = ''; state.syncing = false; if (state.pending) setTimeout(() => push(dbRef()), 300); return {ok:true, n:items.length};
    } catch(e){ state.syncing = false; state.err = e.message||String(e); state.pending = true; setTimeout(() => push(dbRef()), 15000); return {ok:false, msg:state.err}; }
  }
  // realtime: another device changed a row → refetch it through the view (so field roles never see money) and hand it to the app
  function subscribe(cb){ onChange = cb; if (channel) return; channel = sb.channel('collections:'+ws()).on('postgres_changes', {event:'*', schema:'public', table:'collections', filter:`workspace_id=eq.${ws()}`}, async payload => { const name = payload.new?.name || payload.old?.name; if (!name) return; if (payload.eventType==='DELETE'){ delete last[name]; delete versions[name]; onChange && onChange(name, null); return; } const v = payload.new.version; if (versions[name] && v <= versions[name]) return; // our own write or older
      try { const row = await pullOne(name); if (!row) return; last[name] = hash(JSON.stringify(row.data)); versions[name] = row.version; onChange && onChange(name, row.data, payload.new.updated_by); } catch(e){ console.warn('realtime refetch failed', e); } }).subscribe(); }

  // ---- files (photos, documents) ----
  const dataUrlToBlob = d => { const [meta, b64] = d.split(','); const mime = (meta.match(/data:(.*?);/)||[])[1] || 'application/octet-stream'; const bin = atob(b64); const arr = new Uint8Array(bin.length); for (let i=0;i<bin.length;i++) arr[i] = bin.charCodeAt(i); return new Blob([arr], {type:mime}); };
  const blobToDataUrl = b => new Promise((res, rej) => { const r = new FileReader(); r.onload = () => res(r.result); r.onerror = rej; r.readAsDataURL(b); });
  async function putBlob(id, dataUrl){ if (!on() || !user()) return false; const {error} = await sb.storage.from('files').upload(`${ws()}/${id}`, dataUrlToBlob(dataUrl), {upsert:true, contentType: dataUrlToBlob(dataUrl).type}); if (error){ console.warn('upload failed', error); return false; } return true; }
  async function getBlob(id){ if (!on() || !user()) return null; const {data, error} = await sb.storage.from('files').download(`${ws()}/${id}`); if (error || !data) return null; return await blobToDataUrl(data); }

  // ---- admin helpers (owner/pm only; enforced by RLS) ----
  async function listProfiles(){ const {data, error} = await sb.from('profiles').select('*').order('name'); if (error) throw error; return data; }
  // Mercer & Bond sourcing: harvested signals (RLS keeps this to owner / mb_* roles)
  // Clipper inbox: the extension writes clips server-side; the board claims them as it turns them into items.
  async function listClips(projectId){ let q = sb.from('sel_clip').select('*').eq('workspace_id', ws()).eq('status','new').order('created_at',{ascending:true}).limit(100); if (projectId) q = q.eq('project_id', projectId); const {data, error} = await q; if (error) throw error; return data||[]; }
  async function claimClips(ids, status='taken'){ if (!ids || !ids.length) return 0; const {error} = await sb.from('sel_clip').update({status, taken_at:new Date().toISOString()}).in('id', ids); if (error) throw error; return ids.length; }
  async function saveClipToken(t){ const {error} = await sb.from('sel_token').upsert({id:t.id, workspace_id:ws(), name:t.name, hash:t.hash, hint:t.hint||'', issued_by:t.by||'', revoked_at:t.revoked?new Date(t.revoked).toISOString():null}); if (error) throw error; return true; }
  async function listSignals(status='new,reviewed'){ const {data, error} = await sb.from('mb_signal').select('*').eq('workspace_id', ws()).in('status', String(status).split(',')).order('score', {ascending:false}).limit(200); if (error) throw error; return data||[]; }
  async function setSignalStatus(id, status){ const {error} = await sb.from('mb_signal').update({status}).eq('id', id); if (error) throw error; return true; }
  async function screenPoint(lon, lat){ const {data, error} = await sb.rpc('mb_screen_point', {p_lon:lon, p_lat:lat}); if (error) throw error; return data; }
  async function updateProfile(id, patch){ const {error} = await sb.from('profiles').update(patch).eq('id', id); if (error) throw error; return true; }

  return {on, init, isOffice, token:() => session && session.access_token || '', setDbRef:f => { dbRef = f; }, user, profile:getProfile, signIn, magicLink, resetPassword, signOut, pullAll, pullOne, push, subscribe, putBlob, getBlob, listProfiles, updateProfile, listSignals, setSignalStatus, listClips, claimClips, saveClipToken, screenPoint, state, shards, cfg};
})();
