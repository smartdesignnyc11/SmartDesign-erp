// Copy to config.js and fill in. These are the PUBLIC (anon) values — safe to ship in the page.
window.SDP_CONFIG = {
  appName: 'SmartDesigns Projects',
  supabaseUrl: 'https://YOUR-PROJECT.supabase.co',
  supabaseAnonKey: 'YOUR-ANON-KEY',
  workspace: 'default',
  aiUrl: '/api/ai'   // the Vercel function in api/ai.js; the Anthropic key lives there, never here
};
