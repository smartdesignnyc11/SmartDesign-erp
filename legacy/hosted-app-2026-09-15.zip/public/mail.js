/* SmartDesigns Projects — the mailbox arrives in Messages.
   Every two minutes (and whenever the tab comes back), rows the mail watcher stored are read into
   DB.comms through cmImport(), routed and proposed like anything else, then marked imported so no
   device reads them twice. Newsletters and the like are kept in the table but not shown. */
(() => {
  const C = window.Cloud; if (!C) return;
  let busy = false, timer = null;
  async function tick(){
    if (busy || !C.on() || !C.user() || !C.isOffice() || typeof cmImport !== 'function' || !window.DB) return;
    busy = true;
    try {
      const rows = await C.listMail(60); if (!rows.length) return;
      const keep = rows.filter(r => !r.noise).map(r => r.payload);
      const n = keep.length ? cmImport(keep) : 0;
      await C.markMail(rows.map(r => r.msg_id));
      if (n){ if (typeof render === 'function') render(); if (typeof toast === 'function') toast(`${n} new message${n === 1 ? '' : 's'} read into Messages`); }
    } catch(e){ console.warn('mail', e); }
    finally { busy = false; }
  }
  function start(){ if (timer) return; timer = setInterval(tick, 120000); setTimeout(tick, 4000); document.addEventListener('visibilitychange', () => { if (!document.hidden) tick(); }); }
  window.addEventListener('load', start);
  window.SDP_MAIL = {tick};
})();
