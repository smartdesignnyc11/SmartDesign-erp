// Sends a follow-up a person approved in the ERP, from the firm's own Gmail account (gmail.send scope on
// the same Google connection as Drive and Calendar). Plain text only; the app keeps the record.
import { guardApp, json } from './lib/nyc.mjs';
import { accessToken, g } from './lib/google.mjs';
export default async (req) => {
  const denied = await guardApp(req, ['owner','pm','coord','design_mgr','controller','billing']); if (denied) return denied;
  if (req.method !== 'POST') return json({error: 'POST {to, subject, body}'}, 405);
  const tok = await accessToken(); if (!tok) return json({error: 'Google is not connected on the server (needs the gmail.send scope)'}, 501);
  let p = {}; try { p = await req.json(); } catch(e){ return json({error: 'bad json'}, 400); }
  const to = String(p.to || '').trim(), subject = String(p.subject || '').slice(0, 300), body = String(p.body || '').slice(0, 20000);
  if (!/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(to)) return json({error: 'a valid recipient address is required'}, 400);
  const from = process.env.MAIL_FROM || process.env.MAIL_IMAP_USER || 'me';
  const raw = [`To: ${to}`, from !== 'me' ? `From: ${from}` : '', `Subject: =?UTF-8?B?${Buffer.from(subject).toString('base64')}?=`, 'MIME-Version: 1.0', 'Content-Type: text/plain; charset=UTF-8', 'Content-Transfer-Encoding: base64', '', Buffer.from(body).toString('base64')].filter(l => l !== '').join('\r\n');
  const r = await g(tok, 'POST', 'https://gmail.googleapis.com/gmail/v1/users/me/messages/send', {raw: Buffer.from(raw).toString('base64').replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '')});
  if (!r.ok) return json({error: `Gmail said ${r.status}${r.j && r.j.error ? ' — ' + r.j.error.message : ''}`}, 502);
  return json({id: r.j.id, threadId: r.j.threadId});
};
export const config = {path: '/api/mail-send'};
