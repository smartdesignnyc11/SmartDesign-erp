// The app's AI calls come here; the Anthropic key stays on the server.
export default async (req) => {
  if (req.method !== 'POST') return new Response(JSON.stringify({error: 'POST only'}), {status: 405, headers: {'content-type': 'application/json'}});
  const key = process.env.ANTHROPIC_API_KEY;
  if (!key) return new Response(JSON.stringify({error: 'ANTHROPIC_API_KEY is not set on the server'}), {status: 500, headers: {'content-type': 'application/json'}});
  let body; try { body = await req.json(); } catch { return new Response(JSON.stringify({error: 'bad JSON'}), {status: 400, headers: {'content-type': 'application/json'}}); }
  if (!body || !body.messages) return new Response(JSON.stringify({error: 'messages required'}), {status: 400, headers: {'content-type': 'application/json'}});
  body.model = body.model || 'claude-sonnet-4-6';
  body.max_tokens = Math.min(body.max_tokens || 1000, 4000);
  const headers = {'content-type': 'application/json', 'x-api-key': key, 'anthropic-version': '2023-06-01'};
  if (body.mcp_servers) headers['anthropic-beta'] = 'mcp-client-2025-04-04';
  try {
    const r = await fetch('https://api.anthropic.com/v1/messages', {method: 'POST', headers, body: JSON.stringify(body)});
    return new Response(await r.text(), {status: r.status, headers: {'content-type': 'application/json'}});
  } catch (e){
    return new Response(JSON.stringify({error: 'upstream: ' + (e.message || e)}), {status: 502, headers: {'content-type': 'application/json'}});
  }
};
export const config = {path: '/api/ai'};
