// One address in, a property dossier out. This is the deal-profile lookup.
//
//   GET /api/property?address=140+Prospect+Place+Brooklyn
//   GET /api/property?bbl=3011290034
//
// Everything here is a public record. Nothing is scraped. The point is that a deal profile in the
// M&B workspace should answer, in one call: what is the lot, who really owns it, what did it and
// its neighbours trade for, what is open against it, and what work has been permitted.
import { DS, soda, json, geocode, titleCase, q, money, normDate } from './lib/nyc.mjs';
import { ownerFor } from './lib/owner.mjs';

const parts = bbl => {
  const s = String(bbl || '').replace(/\D/g, '');
  return s.length === 10 ? {boro: s.slice(0, 1), block: String(Number(s.slice(1, 6))), lot: String(Number(s.slice(6))), bbl: s} : null;
};

async function lot(p){
  const rows = await soda(DS.pluto, {
    $select: 'bbl,address,zipcode,ownername,bldgclass,landuse,yearbuilt,yearalter1,numfloors,unitsres,unitstotal,' +
             'lotarea,bldgarea,comarea,resarea,lotfront,lotdepth,bldgfront,bldgdepth,zonedist1,overlay1,spdist1,' +
             'builtfar,residfar,commfar,facilfar,assessland,assesstot,exempttot,histdist,landmark,cd,council,' +
             'latitude,longitude',
    $where: `bbl=${Number(p.bbl)}`, $limit: '1',
  });
  const r = rows[0];
  if (!r) return null;
  const unused = Math.max(0, (money(r.residfar) || 0) - (money(r.builtfar) || 0));
  return {
    bbl: p.bbl, address: titleCase(r.address || ''), zip: r.zipcode || '',
    owner_of_record: titleCase(r.ownername || ''),
    building_class: r.bldgclass || '', land_use: r.landuse || '',
    year_built: r.yearbuilt || '', last_altered: r.yearalter1 || '',
    floors: r.numfloors || '', units_total: r.unitstotal || '', units_residential: r.unitsres || '',
    lot_area_sf: money(r.lotarea) || null, building_area_sf: money(r.bldgarea) || null,
    commercial_sf: money(r.comarea) || null, residential_sf: money(r.resarea) || null,
    lot_dimensions: r.lotfront && r.lotdepth ? `${r.lotfront} × ${r.lotdepth}` : '',
    building_dimensions: r.bldgfront && r.bldgdepth ? `${r.bldgfront} × ${r.bldgdepth}` : '',
    zoning: r.zonedist1 || '', overlay: r.overlay1 || '', special_district: r.spdist1 || '',
    far: {built: money(r.builtfar) || 0, residential_max: money(r.residfar) || 0,
          commercial_max: money(r.commfar) || 0, community_facility_max: money(r.facilfar) || 0,
          unused_residential: Math.round(unused * 100) / 100,
          unused_sf: Math.round(unused * (money(r.lotarea) || 0))},
    assessment: {land: money(r.assessland) || 0, total: money(r.assesstot) || 0, exempt: money(r.exempttot) || 0},
    historic_district: r.histdist || '', individual_landmark: r.landmark || '',
    community_district: r.cd || '', council_district: r.council || '',
    lat: r.latitude ? Number(r.latitude) : null, lon: r.longitude ? Number(r.longitude) : null,
  };
}

// This lot's own sale history, then the block's, so a price has something to sit against.
async function salesHistory(p){
  const mine = await soda(DS.sales, {
    $select: 'address,sale_price,sale_date,gross_square_feet,land_square_feet,total_units,building_class_category',
    $where: `borough=${q(p.boro)} AND block=${q(p.block)} AND lot=${q(p.lot)} AND sale_price > 10000`,
    $order: 'sale_date DESC', $limit: '25',
  }).catch(() => []);
  const block = await soda(DS.sales, {
    $select: 'address,sale_price,sale_date,gross_square_feet,total_units,building_class_category,lot',
    $where: `borough=${q(p.boro)} AND block=${q(p.block)} AND lot!=${q(p.lot)} AND sale_price > 10000`,
    $order: 'sale_date DESC', $limit: '40',
  }).catch(() => []);
  const shape = r => {
    const price = money(r.sale_price), gsf = money(r.gross_square_feet);
    return {address: titleCase(r.address || ''), date: normDate(r.sale_date), price,
            gross_sf: gsf || null, price_per_sf: gsf ? Math.round(price / gsf) : null,
            units: r.total_units || '', category: titleCase(r.building_class_category || '')};
  };
  const comps = block.map(shape);
  const psf = comps.map(c => c.price_per_sf).filter(Boolean).sort((a, b) => a - b);
  return {
    this_lot: mine.map(shape),
    block_comps: comps.slice(0, 20),
    block_median_psf: psf.length ? psf[Math.floor(psf.length / 2)] : null,
    block_sales_counted: psf.length,
  };
}

async function openViolations(p){
  const [hpd, dob, ecb] = await Promise.all([
    soda(DS.hpdViol, {$select: 'violationid,class,novissueddate,novdescription',
                      $where: `boroid=${q(p.boro)} AND block=${q(p.block)} AND lot=${q(p.lot)} AND violationstatus='Open'`,
                      $limit: '2000'}).catch(() => []),
    soda(DS.dobViol, {$select: 'violation_number,issue_date,violation_type,violation_category,description',
                      $where: `boro=${q(p.boro)} AND block=${q(p.block)} AND lot=${q(p.lot)}`,
                      $limit: '2000'}).catch(() => []),
    soda(DS.ecb, {$select: 'ecb_violation_number,issue_date,ecb_violation_status,severity,violation_type,violation_description,penality_imposed,balance_due',
                  $where: `boro=${q(p.boro)} AND block=${q(p.block)} AND lot=${q(p.lot)}`,
                  $limit: '2000'}).catch(() => []),
  ]);
  const dobOpen = dob.filter(r => String(r.violation_category || '').toUpperCase().includes('ACTIVE'));
  const ecbOpen = ecb.filter(r => String(r.ecb_violation_status || '').toUpperCase() === 'ACTIVE');
  const balance = ecbOpen.reduce((n, r) => n + money(r.balance_due), 0);
  const byClass = c => hpd.filter(r => String(r.class || '').toUpperCase() === c).length;
  return {
    hpd: {open: hpd.length, class_a: byClass('A'), class_b: byClass('B'), class_c: byClass('C'),
          latest: hpd.map(r => ({date: normDate(r.novissueddate), class: r.class,
                                 description: String(r.novdescription || '').slice(0, 180)}))
                     .sort((a, b) => (b.date || '').localeCompare(a.date || '')).slice(0, 8)},
    dob: {open: dobOpen.length,
          latest: dobOpen.map(r => ({date: normDate(r.issue_date), type: r.violation_type || '',
                                     description: String(r.description || '').slice(0, 180)}))
                         .sort((a, b) => (b.date || '').localeCompare(a.date || '')).slice(0, 8)},
    ecb: {open: ecbOpen.length, balance_due: Math.round(balance),
          latest: ecbOpen.map(r => ({date: normDate(r.issue_date), severity: r.severity || '',
                                     balance: money(r.balance_due) || 0,
                                     description: String(r.violation_description || r.violation_type || '').slice(0, 180)}))
                         .sort((a, b) => (b.date || '').localeCompare(a.date || '')).slice(0, 8)},
  };
}

async function permits(p){
  const [now, legacy] = await Promise.all([
    soda(DS.dobNow, {$select: 'job_filing_number,work_permit,work_type,filing_reason,issued_date,job_description,estimated_job_costs,owner_name,owner_business_name,applicant_business_name,permit_status',
                     $where: `bbl=${q(p.bbl)}`, $order: 'issued_date DESC', $limit: '60'}).catch(() => []),
    soda(DS.dobJobs, {$select: 'job__,job_type,job_status_descrp,pre__filing_date,initial_cost,owner_s_business_name,landmarked',
                      $where: `block=${q(p.block)} AND lot=${q(p.lot)}`, $order: 'pre__filing_date DESC', $limit: '40'}).catch(() => []),
  ]);
  return {
    dob_now: now.map(r => ({date: normDate(r.issued_date), permit: r.work_permit || '', filing: r.job_filing_number || '',
                            work_type: titleCase(r.work_type || ''), reason: titleCase(r.filing_reason || ''),
                            status: titleCase(r.permit_status || ''), estimated_cost: money(r.estimated_job_costs) || null,
                            scope: String(r.job_description || '').slice(0, 240),
                            owner: titleCase(r.owner_business_name || r.owner_name || ''),
                            contractor: titleCase(r.applicant_business_name || '')})).slice(0, 25),
    legacy_bis: legacy.map(r => ({date: normDate(r.pre__filing_date), job: r.job__ || '', type: r.job_type || '',
                                  status: r.job_status_descrp || '', estimated_cost: money(r.initial_cost) || null,
                                  owner: titleCase(r.owner_s_business_name || ''),
                                  landmarked: String(r.landmarked || '').toUpperCase() === 'Y'})).slice(0, 20),
  };
}

async function acrisDocs(p){
  const legals = await soda(DS.acrisLegal, {
    $select: 'document_id,street_number,street_name,unit',
    $where: `borough=${q(p.boro)} AND block=${q(p.block)} AND lot=${q(p.lot)}`, $limit: '400',
  }).catch(() => []);
  if (!legals.length) return [];
  const ids = [...new Set(legals.map(l => l.document_id))].slice(0, 200);
  const master = await soda(DS.acrisMaster, {
    $select: 'document_id,doc_type,document_date,recorded_datetime,document_amt,crfn',
    $where: `document_id IN (${ids.map(q).join(',')})`, $limit: '400',
  }).catch(() => []);
  return master
    .map(m => ({date: normDate(m.recorded_datetime), doc_type: m.doc_type || '',
                amount: money(m.document_amt) || null, crfn: m.crfn || '',
                url: `https://a836-acris.nyc.gov/DS/DocumentSearch/DocumentImageView?doc_id=${m.document_id}`}))
    .sort((a, b) => (b.date || '').localeCompare(a.date || ''))
    .slice(0, 40);
}

export default async (req) => {
  const url = new URL(req.url);
  const want = (url.searchParams.get('include') || 'lot,owner,sales,violations,permits,acris').split(',').map(s => s.trim());
  let p = parts(url.searchParams.get('bbl'));
  let geo = null;

  if (!p){
    const text = url.searchParams.get('address') || '';
    if (!text) return json({error: 'pass ?bbl= or ?address='}, 400);
    geo = await geocode(text);
    p = parts(geo?.bbl);
    if (!p) return json({error: 'could not resolve that address to a tax lot', geocoded: geo}, 404);
  }

  const jobs = {
    lot: () => lot(p),
    owner: () => ownerFor(p.boro, p.block, p.lot),
    sales: () => salesHistory(p),
    violations: () => openViolations(p),
    permits: () => permits(p),
    acris: () => acrisDocs(p),
  };
  const keys = Object.keys(jobs).filter(k => want.includes(k));
  const settled = await Promise.all(keys.map(k => jobs[k]().catch(e => ({error: e.message}))));

  // note: `lot` below is the PLUTO dossier section, so the identity field is `tax_lot`
  const out = {bbl: p.bbl, borough: p.boro, block: p.block, tax_lot: p.lot, geocoded: geo || undefined};
  keys.forEach((k, i) => { out[k] = settled[i]; });

  return new Response(JSON.stringify(out, null, 2), {
    status: 200,
    headers: {'content-type': 'application/json', 'cache-control': 'public, max-age=900'},
  });
};

export const config = {path: '/api/property'};
