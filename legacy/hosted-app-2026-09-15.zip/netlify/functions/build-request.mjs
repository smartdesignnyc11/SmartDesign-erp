// A build request from the ERP: an approved change that needs code, written as a brief and sent to
// the coder's inbox — the firm's own mailbox, which the coder's next session reads — and kept in
// public.build_requests so the app can show Requested / Shipped.
import { admin, guardApp, json } from './lib/nyc.mjs';
import { accessToken, g } from './lib/google.mjs';
const WS = () => process.env.WORKSPACE_ID || 'default';
export default async (req) => {
  const denied = await guardApp(req, ['owner','pm']); if (denied) return denied;
  if (req.method !== 'POST') return json({error: 'POST {id, title, brief}'}, 405);
  let p = {}; try { p = await req.json(); } catch(e){ return json({error: 'bad json'}, 400); }
  const id = String(p.id || '').slice(0, 60), title = String(p.title || '').slice(0, 200), brief = String(p.brief || '').slice(0, 20000);
  if (!id || !title || !brief) return json({error: 'id, title and brief are required'}, 400);
  let stored = false; try { const sb = admin(); const {error} = await sb.from('build_requests').upsert({workspace_id: WS(), id, title, brief, status: 'requested', requested_at: new Date().toISOString()}, {onConflict: 'workspace_id,id'}); stored = !error; } catch(e){ stored = false; }
  const to = process.env.BUILD_REQUEST_TO || process.env.MAIL_IMAP_USER || ''; let mailed = '';
  if (to){ const tok = await accessToken(); if (tok){ const subject = `Build Request: ${title} [${id}]`; const raw = [`To: ${to}`, `Subject: =?UTF-8?B?${Buffer.from(subject).toString('base64')}?=`, 'MIME-Version: 1.0', 'Content-Type: text/plain; charset=UTF-8', 'Content-Transfer-Encoding: base64', '', Buffer.from(brief).toString('base64')].join('\r\n'); const r = await g(tok, 'POST', 'https://gmail.googleapis.com/gmail/v1/users/me/messages/send', {raw: Buffer.from(raw).toString('base64').replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '')}); if (r.ok) mailed = r.j.id || 'sent'; } }
  if (!stored && !mailed) return json({error: 'Nowhere to send it: neither Supabase (SUPABASE_URL / SERVICE_ROLE_KEY) nor Gmail (the Google connection with gmail.send) is configured'}, 501);
  return json({id: mailed || id, via: mailed ? 'mail' : 'database', stored, mailed: !!mailed});
};
export const config = {path: '/api/build-request'};
