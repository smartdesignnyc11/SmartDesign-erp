// Google Calendar, both ways — the endpoint the app's Sync button calls. The logic lives in lib/gcal.mjs
// and runs on a schedule too (calendar-sync.mjs), so Google's changes arrive without a button.
import { guardApp, json } from './lib/nyc.mjs';
import { sync } from './lib/gcal.mjs';
export default async (req) => {
  const denied = await guardApp(req, ['owner','pm','coord','design_mgr','controller','billing']); if (denied) return denied;
  if (req.method !== 'POST') return json({error: 'POST a sync body'}, 405);
  let payload = {}; try { payload = await req.json(); } catch(e){ return json({error: 'bad json'}, 400); }
  if (!payload.from || !payload.to) return json({error: 'from and to required'}, 400);
  const r = await sync(payload); if (r.error) return json({error: r.error}, r.status || 502);
  return json(r);
};
export const config = {path: '/api/calendar'};
