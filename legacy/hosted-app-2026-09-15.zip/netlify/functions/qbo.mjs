// QuickBooks Online for the app: ?what=ping (is it connected, which company) and ?what=pull&since=YYYY-MM-DD
// (purchases, deposits, invoices since the date, in the ledger's shape). Read-only; the app decides what lands.
import { guardApp, json } from './lib/nyc.mjs';
import { accessToken, companyInfo, pull } from './lib/qbo.mjs';
export default async (req) => {
  const denied = await guardApp(req, ['owner','controller','billing','pm']); if (denied) return denied;
  const url = new URL(req.url); const what = url.searchParams.get('what') || 'ping';
  const tok = await accessToken(); if (!tok) return json({ok: false, error: 'QuickBooks is not connected on the server (QBO_CLIENT_ID / QBO_CLIENT_SECRET / QBO_REFRESH_TOKEN / QBO_REALM_ID)'}, 501);
  try {
    if (what === 'ping') return json({ok: true, company: await companyInfo(tok)});
    if (what === 'pull') return json(await pull(tok, url.searchParams.get('since') || ''));
    return json({error: 'what=ping|pull'}, 400);
  } catch(e){ return json({error: e.message}, 502); }
};
export const config = {path: '/api/qbo'};
