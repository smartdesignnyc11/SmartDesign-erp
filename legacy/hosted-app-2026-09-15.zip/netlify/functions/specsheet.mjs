// Does this spec sheet actually cover the thing we bought?
//
//   GET /api/specsheet?url=<pdf>&sku=RGLS02-UB
//
// Alan, 00:48:28: "sometimes you'll have a spec sheet that has multiple items on it, or sometimes
// there's a −X that's different than the −Y item that we purchased, and then you have the wrong spec
// sheet." Then the field roughs the wrong valve.
//
// So this opens the document and looks. It does not ask a model whether the SKU is probably in there.
// A model that has not read the PDF will say yes, and being confidently wrong is the failure itself.
import { pdfText, findSku } from './lib/pdftext.mjs';
import { json } from './lib/nyc.mjs';

const MAX = 25 * 1024 * 1024;
const UA = 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Safari/537.36';

// The lines around a hit are what the field actually wants: the rough-in dimension, the valve, the CC.
const ROUGH = /(rough[- ]?in|centerline|c\/l|finished wall|from (?:the )?floor|a\.?f\.?f\.?|valve|carrier|blocking|supply|drain|clearance|cut ?out|opening|template)/i;

function context(text, sku){
  const words = String(text).split(/\s+/);
  const norm = s => s.toUpperCase().replace(/[^A-Z0-9]/g, '');
  const want = norm(sku);
  const i = words.findIndex(w => norm(w).includes(want));
  if (i < 0) return '';
  return words.slice(Math.max(0, i - 18), i + 22).join(' ');
}

function roughNotes(text){
  return String(text).split(/(?<=[.;])\s+|\n/)
    .map(s => s.trim())
    .filter(s => s.length > 18 && s.length < 220 && ROUGH.test(s))
    .slice(0, 6);
}

export default async (req) => {
  const u = new URL(req.url);
  const target = u.searchParams.get('url');
  const sku = u.searchParams.get('sku') || '';
  if (!target) return json({error: 'pass ?url= of the PDF, and ?sku= to check it against'}, 400);

  let buf;
  try {
    const r = await fetch(target, {headers: {'User-Agent': UA, Accept: 'application/pdf,*/*'}, redirect: 'follow'});
    if (!r.ok) return json({error: `The document could not be fetched (HTTP ${r.status}).`, url: target}, 502);
    const type = (r.headers.get('content-type') || '').toLowerCase();
    const ab = await r.arrayBuffer();
    if (ab.byteLength > MAX) return json({error: 'The document is too large to read here.'}, 413);
    buf = Buffer.from(ab);
    if (!type.includes('pdf') && buf.subarray(0, 5).toString('latin1') !== '%PDF-')
      return json({error: 'That link is not a PDF.', contentType: type}, 415);
  } catch (e){
    return json({error: `The document could not be fetched: ${e.message}`, url: target}, 502);
  }

  let doc;
  try { doc = pdfText(buf); }
  catch (e){ return json({error: `The document could not be read: ${e.message}`}, 422); }

  if (!doc.text || doc.text.length < 40)
    return json({
      ok: true, url: target, sku, readable: false,
      note: 'The document holds no extractable text — it is a scan or an image-only sheet. Nothing here can confirm the SKU; a person has to look at it.',
      pageCount: doc.pageCount,
    });

  const hit = findSku(doc.text, sku);
  return json({
    ok: true, url: target, sku, readable: true,
    pageCount: doc.pageCount,
    skuVerified: hit.found,
    family: hit.family || null,
    variantsInDocument: hit.variants || [],
    why: hit.found ? `${sku} appears in the document.` : hit.reason,
    context: hit.found ? context(doc.text, sku) : '',
    roughIn: roughNotes(doc.text),
    characters: doc.text.length,
  });
};

export const config = {path: '/api/specsheet'};
