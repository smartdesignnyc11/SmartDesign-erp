// Government feeds — public records only, no keys, no terms-of-use barrier.
//   Tax Lien Sale Lists  → the pre-foreclosure list, published before the sale. Earliest signal we get.
//   HPD violations       → distress and leverage; only a meaningful open load counts as a signal.
//   DOB / ECB violations → the same in money: an unpaid ECB balance is a number you can negotiate against.
//   DOB filings + DOB NOW permits → who else is buying and renovating on the block.
//   DOF sales            → what things actually trade for. The comp layer.
// Scheduled daily. Idempotent — unique (source, source_ref) drops repeats.
import { DS, soda, admin, guard, json, watchAreas, lotsFor, boroAbbr, boroName, bblOf, enrichFromLot,
         saveSignals, probe, normDate, ymd, titleCase, chunk, q, money } from './lib/nyc.mjs';

const title = titleCase;

// ---------- tax liens ----------
async function taxLiens(area, lots, since){
  const cds = (area.cds || []).map(q).join(',');
  if (!cds) return [];
  const rows = await soda(DS.taxLien, {
    $select: 'month,cycle,borough,block,lot,building_class,community_board,house_number,street_name,water_debt_only',
    $where: `borough=${q(area.borough || '1')} AND community_board IN (${cds}) AND month > '${since}T00:00:00'`,
    $order: 'month DESC',
    $limit: '5000',
  });
  return rows.map(r => {
    const bbl = bblOf(r.borough, r.block, r.lot);
    const water = String(r.water_debt_only || '').toUpperCase() === 'YES';
    const sig = {
      source: 'nyc_taxlien',
      source_ref: `${bbl}:${String(r.month).slice(0, 10)}:${r.cycle || ''}`,
      signal: water ? 'Water lien — sale list' : 'Tax lien — sale list',
      category: 'distress',
      score: water ? 55 : 85,                       // a tax lien bites harder than a water lien
      bbl,
      address: title(`${r.house_number || ''} ${r.street_name || ''}`),
      occurred_on: String(r.month).slice(0, 10),
      amount: null,
      watch_area_id: area.id,
      workspace_id: area.workspace_id,
      payload: {cycle: r.cycle || '', building_class: r.building_class || '',
                community_board: r.community_board || '', water_debt_only: water,
                url: 'https://www.nyc.gov/site/finance/property/property-lien-sales.page'},
    };
    return enrichFromLot(sig, lots);
  });
}

// ---------- HPD violations ----------
// One signal per building per sweep, not per violation — otherwise a bad building floods the feed.
async function hpdViolations(area, lots, blocks, since){
  const out = new Map();
  for (const part of chunk([...blocks], 250)){
    const rows = await soda(DS.hpdViol, {
      $select: 'violationid,boroid,block,lot,housenumber,streetname,class,novdescription,novissueddate,currentstatus,violationstatus',
      $where: `boroid=${q(area.borough || '1')} AND block IN (${part.map(q).join(',')}) ` +
              `AND novissueddate > '${since}T00:00:00' AND violationstatus='Open'`,
      $limit: '50000',
    });
    for (const r of rows){
      const bbl = bblOf(r.boroid, r.block, r.lot);
      const cur = out.get(bbl) || {bbl, n: 0, c: 0, b: 0, latest: '', addr: '', worst: ''};
      cur.n++;
      const cls = String(r.class || '').toUpperCase();
      if (cls === 'C') cur.c++; else if (cls === 'B') cur.b++;
      const d = String(r.novissueddate || '').slice(0, 10);
      if (d > cur.latest){ cur.latest = d; cur.worst = String(r.novdescription || '').slice(0, 200); }
      if (!cur.addr) cur.addr = title(`${r.housenumber || ''} ${r.streetname || ''}`);
      out.set(bbl, cur);
    }
  }
  return [...out.values()]
    .filter(v => v.c >= 1 || v.n >= 5)               // a class C, or a real backlog — not one loose B
    .map(v => enrichFromLot({
      source: 'nyc_hpd',
      source_ref: `${v.bbl}:${v.latest}`,
      signal: v.c ? `${v.c} class-C violation${v.c > 1 ? 's' : ''} open` : `${v.n} open HPD violations`,
      category: 'distress',
      score: Math.min(95, 35 + v.c * 12 + Math.min(v.n, 20)),
      bbl: v.bbl,
      address: v.addr,
      occurred_on: v.latest,
      amount: null,
      watch_area_id: area.id,
      workspace_id: area.workspace_id,
      payload: {open_total: v.n, class_c: v.c, class_b: v.b, latest_violation: v.worst,
                url: `https://hpdonline.nyc.gov/hpdonline/building/search?block=${Number(String(v.bbl).slice(1, 6))}`},
    }, lots));
}

// ---------- DOB job filings ----------
async function dobJobs(area, lots, blocks, since){
  const out = [];
  const sinceUS = `${since.slice(5, 7)}/${since.slice(8, 10)}/${since.slice(0, 4)}`;  // this dataset stores dates as text
  for (const part of chunk([...blocks], 250)){
    const rows = await soda(DS.dobJobs, {
      $select: 'job__,doc__,borough,house__,street_name,block,lot,bin__,job_type,job_status_descrp,pre__filing_date,landmarked,initial_cost,applicant_s_first_name,applicant_s_last_name,existing_zoning_sqft,proposed_zoning_sqft',
      $where: `borough=${q(boroName(area))} AND block IN (${part.map(q).join(',')}) ` +
              `AND date_trunc_ymd(pre__filing_date) > '${since}T00:00:00'`,
      $limit: '20000',
    }).catch(async () => soda(DS.dobJobs, {                       // some mirrors store the date as text
      $select: 'job__,doc__,borough,house__,street_name,block,lot,bin__,job_type,job_status_descrp,pre__filing_date,landmarked,initial_cost',
      $where: `borough=${q(boroName(area))} AND block IN (${part.map(q).join(',')})`,
      $order: 'pre__filing_date DESC', $limit: '2000',
    }));
    for (const r of rows){
      const filed = normDate(r.pre__filing_date);
      if (!filed || filed < since) continue;
      if (String(r.doc__ || '01') !== '01') continue;             // only the primary document of a job
      const type = ({A1: 'Alteration 1', A2: 'Alteration 2', A3: 'Alteration 3', NB: 'New building', DM: 'Demolition'})[r.job_type] || r.job_type || 'Filing';
      const big = Number(String(r.initial_cost || '0').replace(/[^0-9.]/g, '')) || 0;
      out.push(enrichFromLot({
        source: 'nyc_dob',
        source_ref: `${r.job__}:${r.doc__ || '01'}`,
        signal: `${type} filed`,
        category: 'activity',
        score: (r.job_type === 'NB' || r.job_type === 'A1' ? 45 : 30) + (String(r.landmarked || '').toUpperCase() === 'Y' ? 10 : 0) + (big > 500000 ? 10 : 0),
        bbl: bblOf('1234'.includes(String(area.borough)) ? area.borough : '1', r.block, r.lot),
        address: title(`${r.house__ || ''} ${r.street_name || ''}`),
        occurred_on: filed,
        amount: null,                                             // filing cost is the applicant's estimate, not a price
        watch_area_id: area.id,
        workspace_id: area.workspace_id,
        payload: {job: r.job__, job_type: r.job_type, status: r.job_status_descrp || '',
                  landmarked: String(r.landmarked || '').toUpperCase() === 'Y',
                  applicant: [r.applicant_s_first_name, r.applicant_s_last_name].filter(Boolean).join(' '),
                  bin: r.bin__ || '',
                  url: r.bin__ ? `https://a810-bisweb.nyc.gov/bisweb/PropertyProfileOverviewServlet?bin=${r.bin__}` : 'https://a810-bisweb.nyc.gov/bisweb/bsqpm01.jsp'},
      }, lots));
    }
  }
  return out;
}

// ---------- DOF sales — the comp layer ----------
// ACRIS tells you a deed was recorded. This tells you the price, the unit count and the square
// footage, which is what turns "someone bought it" into "here is what the block trades at".
export async function sales(area, lots, blocks, since){
  const out = [];
  for (const part of chunk([...blocks], 250)){
    const rows = await soda(DS.sales, {
      $select: 'borough,neighborhood,building_class_category,block,lot,address,zip_code,residential_units,' +
               'commercial_units,total_units,land_square_feet,gross_square_feet,year_built,sale_price,sale_date,bbl',
      $where: `borough=${q(String(area.borough || '1'))} AND block IN (${part.map(q).join(',')}) ` +
              `AND sale_date > '${since}T00:00:00' AND sale_price > 10000`,
      $order: 'sale_date DESC',
      $limit: '20000',
    });
    for (const r of rows){
      const bbl = String(r.bbl || bblOf(area.borough || '1', r.block, r.lot)).split('.')[0];
      const price = money(r.sale_price);
      if (price <= 10000) continue;                   // $1 and $10 transfers are family paper, not comps
      const gsf = money(r.gross_square_feet);
      const psf = gsf ? Math.round(price / gsf) : 0;
      out.push(enrichFromLot({
        source: 'nyc_sales',
        source_ref: `${bbl}:${normDate(r.sale_date)}:${Math.round(price)}`,
        signal: psf ? `Sold — $${price.toLocaleString()} ($${psf}/sf)` : `Sold — $${price.toLocaleString()}`,
        category: 'traded',
        score: 50 + (psf && psf < 600 ? 10 : 0),        // a thin trade on your block is worth a look
        bbl,
        address: title(r.address || ''),
        occurred_on: normDate(r.sale_date),
        amount: price,
        watch_area_id: area.id,
        workspace_id: area.workspace_id,
        payload: {price_per_sf: psf || null, gross_sf: gsf || null, land_sf: money(r.land_square_feet) || null,
                  units: r.total_units || '', residential_units: r.residential_units || '',
                  neighborhood: title(r.neighborhood || ''), class_category: title(r.building_class_category || ''),
                  url: 'https://www.nyc.gov/site/finance/property/property-annualized-sales-update.page'},
      }, lots));
    }
  }
  return out;
}

// ---------- ECB violations — distress with a dollar figure ----------
// Aggregated per lot: one signal carrying the open balance, not fifty rows of infraction codes.
export async function ecbViolations(area, lots, blocks, since){
  const out = new Map();
  const sinceY = ymd(since);
  for (const part of chunk([...blocks], 250)){
    const rows = await soda(DS.ecb, {
      $select: 'ecb_violation_number,ecb_violation_status,boro,block,lot,bin,issue_date,severity,violation_type,' +
               'violation_description,penality_imposed,amount_paid,balance_due,hearing_status',
      $where: `boro=${q(String(area.borough || '1'))} AND block IN (${part.map(q).join(',')}) ` +
              `AND issue_date > ${q(sinceY)}`,
      $limit: '50000',
    });
    for (const r of rows){
      if (String(r.ecb_violation_status || '').toUpperCase() !== 'ACTIVE') continue;
      const bbl = bblOf(area.borough || '1', r.block, r.lot);
      const cur = out.get(bbl) || {bbl, n: 0, due: 0, latest: '', worst: ''};
      cur.n++;
      cur.due += money(r.balance_due);
      const d = normDate(r.issue_date);
      if (d > cur.latest){ cur.latest = d; cur.worst = String(r.violation_description || r.violation_type || '').slice(0, 200); }
      out.set(bbl, cur);
    }
  }
  return [...out.values()]
    .filter(v => v.due >= 1000 || v.n >= 3)          // a single small ticket is noise
    .map(v => enrichFromLot({
      source: 'nyc_ecb',
      source_ref: `${v.bbl}:${v.latest}:${v.n}`,
      signal: v.due ? `$${Math.round(v.due).toLocaleString()} ECB balance open (${v.n})` : `${v.n} active ECB violations`,
      category: 'distress',
      score: Math.min(90, 40 + Math.min(35, Math.floor(v.due / 10000) * 5) + Math.min(10, v.n)),
      bbl: v.bbl,
      address: '',                                    // enrichFromLot fills it from PLUTO
      occurred_on: v.latest,
      amount: Math.round(v.due) || null,
      watch_area_id: area.id,
      workspace_id: area.workspace_id,
      payload: {active_count: v.n, balance_due: Math.round(v.due), latest_violation: v.worst,
                url: 'https://a810-bisweb.nyc.gov/bisweb/ECBQueryByLocationServlet'},
    }, lots));
}

// ---------- DOB violations (BIS) — conditions, not money ----------
export async function dobViolations(area, lots, blocks, since){
  const out = new Map();
  const sinceY = ymd(since);
  for (const part of chunk([...blocks], 250)){
    const rows = await soda(DS.dobViol, {
      $select: 'violation_number,boro,block,lot,bin,issue_date,violation_type,violation_category,description,disposition_date',
      $where: `boro=${q(String(area.borough || '1'))} AND block IN (${part.map(q).join(',')}) ` +
              `AND issue_date > ${q(sinceY)}`,
      $limit: '50000',
    });
    for (const r of rows){
      const cat = String(r.violation_category || '').toUpperCase();
      if (!cat.includes('ACTIVE')) continue;          // dismissed and resolved rows carry no signal
      const bbl = bblOf(area.borough || '1', r.block, r.lot);
      const cur = out.get(bbl) || {bbl, n: 0, latest: '', worst: '', types: new Set()};
      cur.n++;
      cur.types.add(String(r.violation_type || '').slice(0, 40));
      const d = normDate(r.issue_date);
      if (d > cur.latest){ cur.latest = d; cur.worst = String(r.description || '').slice(0, 200); }
      out.set(bbl, cur);
    }
  }
  return [...out.values()]
    .filter(v => v.n >= 2)
    .map(v => enrichFromLot({
      source: 'nyc_dobviol',
      source_ref: `${v.bbl}:${v.latest}:${v.n}`,
      signal: `${v.n} open DOB violations`,
      category: 'distress',
      score: Math.min(80, 35 + v.n * 4),
      bbl: v.bbl,
      address: '',
      occurred_on: v.latest,
      amount: null,
      watch_area_id: area.id,
      workspace_id: area.workspace_id,
      payload: {open_count: v.n, types: [...v.types].filter(Boolean).slice(0, 6), latest_violation: v.worst,
                url: 'https://a810-bisweb.nyc.gov/bisweb/ActionsByLocationServlet'},
    }, lots));
}

// ---------- DOB NOW permits — everything filed since 2021 ----------
// The legacy BIS job-filings table stopped taking new work. Without this feed we under-report
// current activity on the block by years.
const NOW_MAJOR = /NEW BUILDING|GENERAL CONSTRUCTION|STRUCTURAL|FOUNDATION|CURB CUT|EARTHWORK/i;
export async function nowPermits(area, lots, blocks, since){
  const out = [];
  for (const part of chunk([...blocks], 250)){
    const rows = await soda(DS.dobNow, {
      $select: 'job_filing_number,work_permit,filing_reason,house_no,street_name,borough,block,lot,bin,bbl,' +
               'work_type,issued_date,approved_date,expired_date,job_description,estimated_job_costs,' +
               'owner_name,owner_business_name,applicant_business_name,permit_status',
      $where: `borough=${q(boroName(area))} AND block IN (${part.map(q).join(',')}) ` +
              `AND issued_date > '${since}T00:00:00'`,
      $order: 'issued_date DESC',
      $limit: '20000',
    });
    for (const r of rows){
      const issued = normDate(r.issued_date);
      if (!issued || issued < since) continue;
      const bbl = String(r.bbl || bblOf(area.borough || '1', r.block, r.lot)).split('.')[0];
      const cost = money(r.estimated_job_costs);
      const major = NOW_MAJOR.test(String(r.work_type || ''));
      out.push(enrichFromLot({
        source: 'nyc_dobnow',
        source_ref: `${r.job_filing_number || ''}:${r.work_permit || ''}`,
        signal: `${title(r.work_type || 'Permit')} permit issued`,
        category: 'activity',
        score: (major ? 45 : 30) + (cost > 500000 ? 10 : 0),
        bbl,
        address: title(`${r.house_no || ''} ${r.street_name || ''}`),
        occurred_on: issued,
        amount: null,                                 // the applicant's cost estimate is not a price
        watch_area_id: area.id,
        workspace_id: area.workspace_id,
        payload: {filing: r.job_filing_number || '', permit: r.work_permit || '',
                  work_type: title(r.work_type || ''), reason: title(r.filing_reason || ''),
                  status: title(r.permit_status || ''), estimated_cost: cost || null,
                  scope: String(r.job_description || '').slice(0, 240),
                  permit_owner: title(r.owner_business_name || r.owner_name || ''),
                  contractor: title(r.applicant_business_name || ''),
                  bin: r.bin || '',
                  url: 'https://a810-dobnow.nyc.gov/publish/Index.html#!/'},
      }, lots));
    }
  }
  return out;
}

export default async (req) => {
  const bad = guard(req); if (bad) return bad;
  const url = new URL(req.url);
  const days = Number(url.searchParams.get('days') || 30);
  const since = new Date(Date.now() - days * 86400000).toISOString().slice(0, 10);
  const only = (url.searchParams.get('feeds') || 'taxlien,hpd,ecb,dobviol,dob,dobnow,sales').split(',').map(s => s.trim());

  if (url.searchParams.get('probe'))
    return json({probe: await probe([DS.taxLien, DS.hpdViol, DS.dobJobs, DS.dobNow, DS.dobViol, DS.ecb, DS.sales, DS.pluto])});

  let sb; try { sb = admin(); } catch (e){ return json({error: e.message}, 500); }
  const report = [];
  let areas = [];
  try { areas = await watchAreas(sb); } catch (e){ return json({error: `watch areas: ${e.message}`}, 500); }
  if (!areas.length) return json({ok: true, note: 'no active watch areas', days});

  for (const area of areas){
    const row = {area: area.label, taxlien: 0, hpd: 0, ecb: 0, dobviol: 0, dob: 0, dobnow: 0, sales: 0, errors: []};
    let lots = {}, blocks = new Set();
    try { ({lots, blocks} = await lotsFor(area)); }
    catch (e){ row.errors.push(`pluto: ${e.message}`); report.push(row); continue; }
    row.blocks = blocks.size;

    for (const [name, fn] of [['taxlien',  () => taxLiens(area, lots, since)],
                              ['hpd',      () => hpdViolations(area, lots, blocks, since)],
                              ['ecb',      () => ecbViolations(area, lots, blocks, since)],
                              ['dobviol',  () => dobViolations(area, lots, blocks, since)],
                              ['dob',      () => dobJobs(area, lots, blocks, since)],
                              ['dobnow',   () => nowPermits(area, lots, blocks, since)],
                              ['sales',    () => sales(area, lots, blocks, since)]]){
      if (!only.includes(name)) continue;
      try { const rows = await fn(); row[name] = await saveSignals(sb, rows); }
      catch (e){ row.errors.push(`${name}: ${e.message}`); }
    }
    report.push(row);
  }
  return json({ok: true, days, since, areas: report});
};

export const config = {path: '/api/harvest-gov'};
