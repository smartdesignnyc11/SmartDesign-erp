// Inbox parser — the legitimate route to portal coverage.
//
// The firm holds saved searches on StreetEasy, LoopNet, Crexi, Auction.com and Ten-X, pointed at a
// dedicated mailbox. This job reads that mailbox — mail the firm is entitled to receive — and turns
// each alert into a signal. It never fetches, crawls or scrapes a portal.
//
// Two ways in, both supported:
//   1. IMAP pull   — set IMAP_HOST / IMAP_USER / IMAP_PASS. Runs on a schedule, reads unseen, marks seen.
//   2. Webhook push — POST here from a forwarding rule (Cloudflare Email Workers, SendGrid Inbound
//      Parse, Mailgun Routes). Send JSON {from, subject, html, text, date} or the raw MIME body.
import { parseListingEmail, enrich } from './lib/parse-listing-email.mjs';
import { admin, guard, json, watchAreas, lotsFor, geocode, saveSignals } from './lib/nyc.mjs';

const MAX_PER_RUN = 60;

async function blocksByArea(sb){
  const out = {}; const areas = await watchAreas(sb);
  for (const a of areas){
    try { const {blocks} = await lotsFor(a); out[a.id] = blocks; } catch { /* area skipped, not fatal */ }
  }
  return out;
}

async function ingest(sb, messages, areas){
  let found = 0, saved = 0;
  const rows = [];
  for (const m of messages){
    const sigs = parseListingEmail(m);
    found += sigs.length;
    if (sigs.length) rows.push(...await enrich(sigs, geocode, areas));
  }
  if (rows.length) saved = await saveSignals(sb, rows);
  return {messages: messages.length, found, saved,
          sample: rows.slice(0, 5).map(r => ({address: r.address, signal: r.signal, amount: r.amount, portal: r.payload.portal, watched: !!r.watch_area_id}))};
}

// ---------- IMAP ----------
async function readImap(limit){
  const host = process.env.IMAP_HOST, user = process.env.IMAP_USER, pass = process.env.IMAP_PASS;
  if (!host || !user || !pass) return {skipped: 'IMAP_HOST / IMAP_USER / IMAP_PASS not set'};
  const {ImapFlow} = await import('imapflow');
  const {simpleParser} = await import('mailparser');
  const client = new ImapFlow({
    host, port: Number(process.env.IMAP_PORT || 993), secure: true,
    auth: {user, pass}, logger: false,
  });
  const out = [];
  await client.connect();
  const lock = await client.getMailboxLock(process.env.IMAP_MAILBOX || 'INBOX');
  const seen = [];
  try {
    const uids = await client.search({seen: false}, {uid: true});
    for (const uid of (uids || []).slice(-limit)){
      const msg = await client.fetchOne(String(uid), {source: true}, {uid: true});
      if (!msg?.source) continue;
      const p = await simpleParser(msg.source);
      out.push({from: p.from?.text || '', subject: p.subject || '', html: p.html || '', text: p.text || '', date: p.date || new Date()});
      seen.push(uid);
    }
    // only mark read once parsed, so a crash re-reads rather than silently dropping mail
    if (seen.length && process.env.IMAP_MARK_SEEN !== 'false') await client.messageFlagsAdd(seen, ['\\Seen'], {uid: true});
  } finally {
    lock.release();
    await client.logout().catch(() => {});
  }
  return {messages: out, marked: seen.length};
}

// ---------- webhook ----------
async function fromRequest(req){
  const ct = (req.headers.get('content-type') || '').toLowerCase();
  if (ct.includes('application/json')){
    const b = await req.json();
    const list = Array.isArray(b) ? b : Array.isArray(b.messages) ? b.messages : [b];
    return list.map(m => ({from: m.from || m.sender || '', subject: m.subject || '',
                           html: m.html || m['body-html'] || '', text: m.text || m['body-plain'] || '',
                           date: m.date || m.timestamp || new Date()}));
  }
  if (ct.includes('multipart/form-data') || ct.includes('application/x-www-form-urlencoded')){
    const f = await req.formData();                                  // SendGrid Inbound Parse shape
    return [{from: f.get('from') || '', subject: f.get('subject') || '',
             html: f.get('html') || '', text: f.get('text') || '', date: new Date()}];
  }
  const raw = await req.text();                                      // raw MIME
  if (!raw.trim()) return [];
  const {simpleParser} = await import('mailparser');
  const p = await simpleParser(raw);
  return [{from: p.from?.text || '', subject: p.subject || '', html: p.html || '', text: p.text || '', date: p.date || new Date()}];
}

export default async (req) => {
  const url = new URL(req.url);

  // dry run: parse a pasted email and show what would be filed, writing nothing
  if (url.searchParams.get('dry')){
    const msgs = await fromRequest(req);
    return json({dry: true, parsed: msgs.flatMap(m => parseListingEmail(m))});
  }

  if (req.method === 'POST'){
    const secret = process.env.INBOX_WEBHOOK_SECRET;
    if (secret && req.headers.get('x-inbox-secret') !== secret && url.searchParams.get('key') !== secret)
      return json({error: 'unauthorized'}, 401);
  } else {
    const bad = guard(req); if (bad) return bad;
  }

  let sb; try { sb = admin(); } catch (e){ return json({error: e.message}, 500); }
  let areas = {}; try { areas = await blocksByArea(sb); } catch { areas = {}; }

  try {
    if (req.method === 'POST'){
      const msgs = await fromRequest(req);
      if (!msgs.length) return json({ok: true, messages: 0, note: 'nothing to parse'});
      return json({ok: true, via: 'webhook', ...await ingest(sb, msgs, areas)});
    }
    const r = await readImap(Number(url.searchParams.get('limit') || MAX_PER_RUN));
    if (r.skipped) return json({ok: true, via: 'imap', skipped: r.skipped});
    return json({ok: true, via: 'imap', marked: r.marked, ...await ingest(sb, r.messages, areas)});
  } catch (e){
    return json({error: e.message}, 500);
  }
};

export const config = {path: '/api/inbox'};
