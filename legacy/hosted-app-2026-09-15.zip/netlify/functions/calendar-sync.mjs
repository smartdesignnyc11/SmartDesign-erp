// Every fifteen minutes in the working day: the calendar, both ways, without anyone pressing a button.
//
// The app stores its whole database as one row per collection in Supabase (public.collections). This
// reads the rows it needs — every project, purchase orders, vendors, obligations, the calendar shard —
// derives the dated items the way the app does (a smaller set: explicit dates only), pushes them to the
// SmartDesign ERP calendar, pulls the window back, and writes the calendar shard (the key→id map, the
// events from Google, the stamp) and any task an event moved. The browser picks the change up through
// its realtime subscription. Idempotent: running twice changes nothing.
import { admin, json } from './lib/nyc.mjs';
import { sync } from './lib/gcal.mjs';
const WS = () => process.env.WORKSPACE_ID || 'default';
const iso = d => d.toISOString().slice(0, 10);
const addDays = (s, n) => { const d = new Date(s + 'T00:00:00Z'); d.setUTCDate(d.getUTCDate() + n); return iso(d); };
const KIND = {meeting:'Meeting', escalation:'Escalation', decision:'Decision', inspection:'Inspection', milestone:'Milestone', delivery:'Delivery', obligation:'Expiry', renewal:'Renewal'};
const titled = (kind, t) => /^(Decision due|Escalate|Renew |Delivery:|Meeting:)/.test(t) || kind === 'obligation' || kind === 'milestone' ? t : `${KIND[kind] || ''}: ${t}`;
export function derive(rows, from, to){
  const E = []; const push = (key, date, title, kind, o) => { if (!date || date < from || date > to) return; E.push(Object.assign({key, date, title: titled(kind, title), kind}, o || {})); };
  const projects = rows.filter(r => r.name.startsWith('project:')).map(r => r.data);
  const pos = (rows.find(r => r.name === 'pos') || {}).data || []; const vendors = (rows.find(r => r.name === 'vendors') || {}).data || []; const obligations = (rows.find(r => r.name === 'obligations') || {}).data || [];
  projects.forEach(p => { const pn = (p.project && p.project.name || '').replace(/ —.*$/, '');
    (p.actions || []).forEach(a => { if (a.status === 'done') return; if (a.meeting || /^Meeting:/.test(a.title || '')) push(`meet|${a.id}`, a.due, (a.title || '').replace(/^Meeting:\s*/, ''), 'meeting', {time: a.time || '', project: pn}); if (a.escalateOn && a.waitsOn) push(`esc|${a.id}`, a.escalateOn, `Escalate: ${a.waitsOn} — ${a.title}`, 'escalation', {project: pn}); });
    (p.decisions || []).forEach(d => { if (d.status === 'open' && d.due) push(`dec|${d.id}`, d.due, `Decision due: ${d.name}`, 'decision', {project: pn}); });
    (p.inspections || []).forEach(i => { if (i.date && i.status !== 'passed') push(`insp|${i.id}`, i.date, `${i.name}${i.agency ? ' · ' + i.agency : ''}`, 'inspection', {project: pn}); });
    if (p.project && p.project.target) push(`target|${p.id}`, p.project.target, `${pn} — substantial completion`, 'milestone', {project: pn}); if (p.project && p.project.out) push(`out|${p.id}`, p.project.out, `${pn} — crew out`, 'milestone', {project: pn}); });
  pos.forEach(po => { if (['issued','partial'].includes(po.status) && po.expected) push(`po|${po.id}`, po.expected, `Delivery: ${po.vendor} · ${po.number}${po.deliveryWindow ? ' · ' + po.deliveryWindow : ''}`, 'delivery', {}); });
  obligations.forEach(o => { if (o.status !== 'active' || !o.expires) return; push(`obx|${o.id}`, o.expires, `${o.name} expires`, 'obligation', {}); push(`obr|${o.id}`, addDays(o.expires, -(+o.renewLead || 30)), `Renew ${o.name}`, 'renewal', {}); });
  vendors.forEach(v => { if (v.insuranceExp) push(`vins|${v.id}`, v.insuranceExp, `${v.name} — insurance certificate expires`, 'obligation', {}); });
  return E;
}
export async function run(){
  const sb = admin(); const {data: rows, error} = await sb.from('collections').select('name,data,version').eq('workspace_id', WS());
  if (error) throw new Error(`collections: ${error.message}`);
  const calRow = rows.find(r => r.name === 'calendar'); const C = Object.assign({external: [], map: {}, last: '', calendarId: ''}, (calRow && calRow.data) || {});
  const today = iso(new Date()); const from = addDays(today, -14), to = addDays(today, 120);
  const E = derive(rows, from, to);
  const r = await sync({from, to, events: E.map(e => Object.assign({}, e, {gcalId: C.map[e.key] || ''})), removed: Object.entries(C.map).filter(([k]) => !E.some(e => e.key === k)).map(([k, id]) => ({key: k, gcalId: id}))});
  if (r.error) return {skipped: r.error};
  (r.pushed || []).forEach(x => { C.map[x.key] = x.gcalId; }); (r.removed || []).forEach(k => { delete C.map[k]; }); C.calendarId = r.calendarId || C.calendarId;
  const ours = new Set(Object.values(C.map));
  C.external = (r.events || []).filter(x => !ours.has(x.id) && !/^erp:/.test(x.description || '')).map(x => ({id: x.id, title: x.title, start: x.start, end: x.end, link: x.link, projectId: ''}));
  // an ERP event someone moved in Google: move the task or the escalation, in its project row
  const touched = new Map(); let moved = 0;
  (r.events || []).forEach(x => { const key = Object.keys(C.map).find(k => C.map[k] === x.id); if (!key) return; const [k, id] = key.split('|'); const date = (x.start || '').slice(0, 10); const time = (x.start || '').length > 10 ? x.start.slice(11, 16) : ''; if (!date) return;
    for (const row of rows.filter(r => r.name.startsWith('project:'))){ const a = (row.data.actions || []).find(a => a.id === id); if (!a) continue; if (k === 'meet' && (a.due !== date || (time && a.time !== time))){ a.due = date; if (time) a.time = time; a.notes = [a.notes, `${today}: moved in Google Calendar to ${date}${time ? ' ' + time : ''}`].filter(Boolean).join('\n'); touched.set(row.name, row); moved++; } if (k === 'esc' && a.escalateOn !== date){ a.escalateOn = date; touched.set(row.name, row); moved++; } } });
  C.last = `${today} (scheduled)`; C.lastRun = new Date().toISOString();
  const writes = [{workspace_id: WS(), name: 'calendar', data: C, version: ((calRow && calRow.version) || 0) + 1, updated_at: new Date().toISOString()}];
  touched.forEach(row => writes.push({workspace_id: WS(), name: row.name, data: row.data, version: (row.version || 0) + 1, updated_at: new Date().toISOString()}));
  const {error: werr} = await sb.from('collections').upsert(writes, {onConflict: 'workspace_id,name'}); if (werr) throw new Error(`write: ${werr.message}`);
  return {pushed: (r.pushed || []).length, external: C.external.length, moved, errors: (r.errors || []).length};
}
export default async () => { try { const out = await run(); console.log('calendar-sync', JSON.stringify(out)); return json(out); } catch(e){ console.error('calendar-sync', e.message); return json({error: e.message}, 500); } };
