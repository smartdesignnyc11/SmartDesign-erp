// The 6am look at the money.
//
// The browser already spots a credit the moment someone opens Procurement. The problem with that is
// the "someone opens Procurement" part: a credit that lands on Tuesday sits unmatched until Thursday,
// and a return window that shuts on Wednesday shuts with nobody watching. So this asks the same
// questions on a schedule, using the same rule module the browser uses, and files what it finds where
// a person will meet it — in the app on next open, and in a digest if a webhook is configured.
//
// It never confirms a match. Machine proposes, person confirms, and a job running at six in the
// morning with nobody awake is the last place that rule should be relaxed.
import { proposals, orphans, overdue, expected, value, RM_STRONG } from './lib/creditmatch.mjs';
import { admin, guard, json } from './lib/nyc.mjs';

const WS = () => process.env.WORKSPACE_ID || 'default';
const money = n => '$' + Math.round(+n || 0).toLocaleString('en-US');

// The app stores one row per collection. Returns live inside `sel`; the money lives in `txns`.
async function readShards(sb, names){
  const {data, error} = await sb.from('collections').select('name,data').eq('workspace_id', WS()).in('name', names);
  if (error) throw new Error(`collections: ${error.message}`);
  return Object.fromEntries((data || []).map(r => [r.name, r.data]));
}

/* An alert is keyed by what it is about, so a job that runs every morning does not file the same
   finding thirty times. Re-running is cheap and changes nothing; that is the point. */
function alertsFrom({props, orph, late, todayISO}){
  const rows = [];
  const add = (kind, key, title, detail, amount, sev, ref) =>
    rows.push({workspace_id: WS(), kind, alert_key: key, title, detail, amount: amount == null ? null : Math.round(amount * 100) / 100, severity: sev, ref: ref || {}, first_seen: todayISO});

  for (const p of props)
    add('credit-match', `match:${p.returnId}:${p.txnId}`,
      `${money(p.txn.amt)} back from ${p.ret.vendor || 'a vendor'}`,
      `Looks like the credit for ${p.ret.name}. ${p.strong ? 'An unmistakable match.' : 'Worth a look.'} Confirm it in Procurement → Credits to confirm.`,
      p.txn.amt, p.strong ? 'info' : 'warn', {returnId: p.returnId, txnId: p.txnId, score: p.score});

  for (const t of orph)
    add('credit-orphan', `orphan:${t.id}`,
      `${money(t.amt)} in from a vendor with no return behind it`,
      `${t.desc || 'A credit'} on ${String(t.date).slice(0, 10)}. Usually a credit we were owed and had forgotten.`,
      t.amt, 'warn', {txnId: t.id});

  for (const r of late.expired)
    add('return-expired', `expired:${r.id}`,
      `Return window closed — ${money(value(r))} at risk`,
      `${r.name} to ${r.vendor}. The window shut on ${r.returnBy}. Call them anyway; a window is a policy, not a law.`,
      value(r), 'bad', {returnId: r.id});

  for (const r of late.closing)
    add('return-closing', `closing:${r.id}:${r.returnBy}`,
      `Return window closes ${r.returnBy} — ${money(value(r))}`,
      `${r.name} to ${r.vendor} is ${r.status === 'shipped' ? 'already on its way' : 'still in the office'}.`,
      value(r), 'warn', {returnId: r.id});

  for (const r of late.stale)
    add('credit-stale', `stale:${r.id}`,
      `Sent back and still not credited — ${money(expected(r))}`,
      `${r.name} went back to ${r.vendor} on ${r.shippedAt}. Nothing has landed.`,
      expected(r), 'warn', {returnId: r.id});

  return rows;
}

function digest(rows, late){
  if (!rows.length) return '';
  const by = k => rows.filter(r => r.kind === k);
  const lines = [];
  const m = by('credit-match');
  if (m.length) lines.push(`*${m.length} credit${m.length === 1 ? '' : 's'} to confirm* — ${money(m.reduce((a, r) => a + r.amount, 0))}\n` + m.map(r => `  · ${r.title}`).join('\n'));
  const e = by('return-expired');
  if (e.length) lines.push(`*${e.length} return window${e.length === 1 ? '' : 's'} already closed* — ${money(e.reduce((a, r) => a + r.amount, 0))} at risk`);
  const c = by('return-closing');
  if (c.length) lines.push(`*${c.length} closing this week* — ${money(c.reduce((a, r) => a + r.amount, 0))}`);
  const s = by('credit-stale');
  if (s.length) lines.push(`*${s.length} sent back, not credited* — ${money(s.reduce((a, r) => a + r.amount, 0))}`);
  const o = by('credit-orphan');
  if (o.length) lines.push(`*${o.length} unexplained credit${o.length === 1 ? '' : 's'}* — ${money(o.reduce((a, r) => a + r.amount, 0))}`);
  lines.push(`${money(late.outstanding)} outstanding across every open return.`);
  return lines.join('\n\n');
}

async function post(text){
  const url = process.env.ALERT_WEBHOOK;
  if (!url || !text) return {sent: false, why: url ? 'nothing to say' : 'ALERT_WEBHOOK not set'};
  try {
    const r = await fetch(url, {method: 'POST', headers: {'content-type': 'application/json'}, body: JSON.stringify({text})});
    return {sent: r.ok, status: r.status};
  } catch (e){ return {sent: false, why: e.message}; }
}

export default async (req) => {
  const bad = guard(req); if (bad) return bad;
  const url = new URL(req.url);
  const dry = !!url.searchParams.get('dry');
  const todayISO = new Date().toISOString().slice(0, 10);

  let sb; try { sb = admin(); } catch (e){ return json({error: e.message}, 500); }

  let sel, txns, vendors;
  try {
    const s = await readShards(sb, ['sel', 'txns', 'vendors']);
    sel = s.sel || {}; txns = s.txns || []; vendors = s.vendors || [];
  } catch (e){ return json({error: e.message}, 500); }

  const returns = sel.returns || [];
  if (!returns.length) return json({ok: true, note: 'no returns on file', checked: todayISO});

  const rejects = sel.creditRejects || {};
  const props = proposals({returns, txns, rejects});
  const orph = orphans({returns, txns, vendors, rejects});
  const late = overdue({returns, today: todayISO});
  const rows = alertsFrom({props, orph, late, todayISO});
  const text = digest(rows, late);

  const report = {
    ok: true, checked: todayISO,
    proposals: props.map(p => ({vendor: p.ret.vendor, item: p.ret.name, amount: p.txn.amt, score: p.score, strong: p.strong,
                                why: p.reasons.map(r => r.code)})),
    orphans: orph.length, expired: late.expired.length, closing: late.closing.length,
    stale: late.stale.length, outstanding: late.outstanding, alerts: rows.length,
  };
  if (dry) return json({...report, dry: true, digest: text});

  // Upsert on the key, so a finding that is still true tomorrow stays one row with a first-seen date.
  const {error} = await sb.from('sel_alert').upsert(rows, {onConflict: 'workspace_id,alert_key', ignoreDuplicates: false});
  if (error) return json({...report, error: `alerts: ${error.message}`}, 500);

  // Anything that has stopped being true — a credit confirmed, a return closed — should stop shouting.
  const live = rows.map(r => r.alert_key);
  const {error: clearErr} = live.length
    ? await sb.from('sel_alert').delete().eq('workspace_id', WS()).not('alert_key', 'in', `(${live.map(k => `"${k}"`).join(',')})`)
    : await sb.from('sel_alert').delete().eq('workspace_id', WS());
  if (clearErr) report.clearError = clearErr.message;

  report.notified = await post(text);
  return json(report);
};

export const config = {path: '/api/credit-watch'};
