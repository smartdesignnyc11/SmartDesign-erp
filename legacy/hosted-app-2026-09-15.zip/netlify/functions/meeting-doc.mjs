// Meeting notes Doc — the "Notes by Gemini" document behind a meeting, exported as text for the ERP to read.
//
// Google Meet mails a link to the notes Doc; the email carries the summary and next steps, the Doc holds
// the decisions, the details with timestamps and the transcript. This reads the Doc with the firm's own
// Google credentials (a refresh token with the drive.readonly scope) and returns its text. Nothing is
// stored here; the app keeps what it extracts.
//
// Env: GOOGLE_CLIENT_ID, GOOGLE_CLIENT_SECRET, GOOGLE_REFRESH_TOKEN (scope https://www.googleapis.com/auth/drive.readonly)
import { guardApp, json } from './lib/nyc.mjs';

import { accessToken } from './lib/google.mjs';
export default async (req) => {
  const denied = await guardApp(req, ['owner','pm','coord','design_mgr','controller','billing']); if (denied) return denied;
  const url = new URL(req.url); const id = (url.searchParams.get('id') || '').replace(/[^A-Za-z0-9_-]/g, '');
  if (!id) return json({error: 'id required'}, 400);
  const tok = await accessToken(); if (!tok) return json({error: 'Google Drive is not connected on the server (GOOGLE_CLIENT_ID / GOOGLE_CLIENT_SECRET / GOOGLE_REFRESH_TOKEN)'}, 501);
  // Google Docs export as plain text keeps headings as lines; the app's parser reads either markdown or this.
  const r = await fetch(`https://www.googleapis.com/drive/v3/files/${id}/export?mimeType=text/plain`, {headers: {authorization: `Bearer ${tok}`}});
  if (!r.ok) return json({error: `Drive said ${r.status}`}, r.status === 404 ? 404 : 502);
  const text = await r.text();
  return json({id, text: text.slice(0, 400000)});
};
export const config = {path: '/api/meeting-doc'};
