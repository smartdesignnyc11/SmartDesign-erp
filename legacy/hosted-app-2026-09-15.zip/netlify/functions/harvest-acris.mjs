// ACRIS distress and transfer signals for every active watch area. Public records, no keys.
// Ported from harlem_harvest.py with its guards kept. Scheduled daily; idempotent.
import { DS, soda, admin, guard, json, watchAreas, lotsFor, bblOf, enrichFromLot, saveSignals, probe } from './lib/nyc.mjs';

// what actually signals a deal, roughly in order of how early it fires
const DOC = {
  LSP:   ['Lis pendens',           'distress',   100],
  NPN:   ['Notice of pendency',    'distress',   100],
  'AL&R':['Assignment of leases',  'distress',    60],
  RDED:  ["Referee's deed",        'foreclosed',  95],
  MTGE:  ['New mortgage',          'activity',    30],
  SAT:   ['Mortgage satisfied',    'activity',    35],
  DEED:  ['Deed recorded',         'traded',      50],
  DEEDO: ['Deed, other',           'traded',      45],
};
const chunk = (a, n) => Array.from({length: Math.ceil(a.length / n)}, (_, i) => a.slice(i * n, i * n + n));
const q = v => `'${String(v).replace(/'/g, "''")}'`;
const title = s => String(s || '').toLowerCase().replace(/\b([a-z])/g, c => c.toUpperCase()).trim();

async function acris(area, lots, blocks, since){
  const types = Object.keys(DOC).map(q).join(',');
  const master = await soda(DS.acrisMaster, {
    $select: 'document_id,doc_type,document_date,recorded_datetime,document_amt',
    $where: `doc_type IN (${types}) AND recorded_datetime > '${since}T00:00:00'`,
  });
  if (!master.length) return [];
  const byId = Object.fromEntries(master.map(m => [m.document_id, m]));

  const hits = [];
  for (const part of chunk([...blocks], 300)){          // Legals is huge — filter server-side, in chunks
    const rows = await soda(DS.acrisLegal, {
      $select: 'document_id,borough,block,lot,street_number,street_name,unit',
      $where: `borough=${q(area.borough || '1')} AND block IN (${part.map(q).join(',')})`,
    });
    for (const r of rows) if (byId[r.document_id]) hits.push(r);
  }

  return hits.map(leg => {
    const m = byId[leg.document_id];
    const [signal, category, base] = DOC[m.doc_type] || [m.doc_type, 'other', 10];
    const bbl = bblOf(leg.borough, leg.block, leg.lot);
    const amt = Number(m.document_amt);
    return enrichFromLot({
      source: 'acris', source_ref: m.document_id, signal, category, score: base, bbl,
      address: title(`${leg.street_number || ''} ${leg.street_name || ''}`),
      occurred_on: String(m.recorded_datetime || '').slice(0, 10),
      amount: isFinite(amt) && amt > 0 ? amt : null,
      watch_area_id: area.id, workspace_id: area.workspace_id,
      payload: {unit: leg.unit || '', doc_type: m.doc_type,
                document_date: String(m.document_date || '').slice(0, 10),
                url: `https://a836-acris.nyc.gov/DS/DocumentSearch/DocumentImageView?doc_id=${m.document_id}`},
    }, lots);
  });
}

export default async (req) => {
  const bad = guard(req); if (bad) return bad;
  const url = new URL(req.url);
  if (url.searchParams.get('probe')) return json({probe: await probe([DS.acrisMaster, DS.acrisLegal, DS.pluto])});
  const days = Number(url.searchParams.get('days') || 7);
  const since = new Date(Date.now() - days * 86400000).toISOString().slice(0, 10);

  let sb; try { sb = admin(); } catch (e){ return json({error: e.message}, 500); }
  let areas = [];
  try { areas = await watchAreas(sb); } catch (e){ return json({error: `watch areas: ${e.message}`}, 500); }
  if (!areas.length) return json({ok: true, note: 'no active watch areas', days});

  const report = [];
  for (const area of areas){
    try {
      const {lots, blocks} = await lotsFor(area);
      const rows = await acris(area, lots, blocks, since);
      report.push({area: area.label, blocks: blocks.size, found: rows.length, saved: await saveSignals(sb, rows)});
    } catch (e){ report.push({area: area.label, error: e.message}); }
  }
  return json({ok: true, days, since, areas: report});
};

export const config = {path: '/api/harvest-acris'};
