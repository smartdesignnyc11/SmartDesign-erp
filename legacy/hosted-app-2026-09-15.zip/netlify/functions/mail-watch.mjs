// Mail watch — the firm's inbox, read into the ERP every few minutes.
//
// Reads the mailbox named by MAIL_IMAP_USER over IMAP (Gmail / Google Workspace with an app password),
// from the last UID it saw, and stores each message as the record the app's Messages screen imports
// (from, to, subject, the writer's text, attachments as data URLs). It never marks anything read and
// never moves mail: the cursor is ours, the mailbox stays exactly as Alan left it.
//
// Env: MAIL_IMAP_USER, MAIL_IMAP_PASS (16-char app password), optional MAIL_IMAP_HOST (imap.gmail.com),
//      MAIL_IMAP_MAILBOX (INBOX), MAIL_MAX_PER_RUN (40), MAIL_BACKFILL_DAYS (30, first run only), WORKSPACE_ID.
import { admin, guard, json } from './lib/nyc.mjs';
import { mailToComm } from './lib/mail-to-comm.mjs';

export default async (req) => {
  const denied = guard(req); if (denied) return denied;
  const user = process.env.MAIL_IMAP_USER, pass = process.env.MAIL_IMAP_PASS;
  if (!user || !pass) return json({skipped: 'MAIL_IMAP_USER / MAIL_IMAP_PASS not set'});
  const ws = process.env.WORKSPACE_ID || 'default'; const box = process.env.MAIL_IMAP_MAILBOX || 'INBOX';
  const max = Number(process.env.MAIL_MAX_PER_RUN || 40);
  const sb = admin();
  const {data: cur} = await sb.from('mail_cursor').select('*').eq('workspace_id', ws).eq('mailbox', user).maybeSingle();
  const {ImapFlow} = await import('imapflow'); const {simpleParser} = await import('mailparser');
  const client = new ImapFlow({host: process.env.MAIL_IMAP_HOST || 'imap.gmail.com', port: Number(process.env.MAIL_IMAP_PORT || 993), secure: true, auth: {user, pass}, logger: false});
  const out = []; let lastUid = cur ? cur.last_uid : 0; let validity = null;
  await client.connect();
  const lock = await client.getMailboxLock(box);
  try {
    validity = Number(client.mailbox.uidValidity || 0);
    if (cur && cur.uidvalidity && validity && Number(cur.uidvalidity) !== validity) lastUid = 0;   // the mailbox was rebuilt: start over
    let uids;
    if (!lastUid){ const since = new Date(Date.now() - Number(process.env.MAIL_BACKFILL_DAYS || 30) * 86400000); uids = await client.search({since}, {uid: true}); }
    else uids = await client.search({uid: `${lastUid + 1}:*`}, {uid: true});
    uids = (uids || []).filter(u => u > lastUid).sort((a, b) => a - b).slice(0, max);
    for (const uid of uids){
      const msg = await client.fetchOne(String(uid), {source: true}, {uid: true}); if (!msg || !msg.source) continue;
      const p = await simpleParser(msg.source);
      const rec = mailToComm(p, user);
      out.push({workspace_id: ws, msg_id: rec.msgId, mailbox: user, uid, payload: rec, noise: rec.noise});
      lastUid = Math.max(lastUid, uid);
    }
  } finally { lock.release(); await client.logout().catch(() => {}); }
  let saved = 0;
  if (out.length){ const {error, count} = await sb.from('mail_inbox').upsert(out, {onConflict: 'workspace_id,msg_id', ignoreDuplicates: true, count: 'exact'}); if (error) return json({error: error.message}, 500); saved = count ?? out.length; }
  await sb.from('mail_cursor').upsert({workspace_id: ws, mailbox: user, last_uid: lastUid, uidvalidity: validity, updated_at: new Date().toISOString()}, {onConflict: 'workspace_id,mailbox'});
  return json({mailbox: user, read: out.length, saved, lastUid, noise: out.filter(o => o.noise).length});
};
export const config = {path: '/api/mail-watch'};
