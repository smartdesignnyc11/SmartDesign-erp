// The sourcing feed, read as the signed-in user so row-level security decides what comes back.
import { createClient } from '@supabase/supabase-js';
export default async (req) => {
  const auth = req.headers.get('authorization') || '';
  const j = (b, s = 200) => new Response(JSON.stringify(b), {status: s, headers: {'content-type': 'application/json'}});
  if (!auth.startsWith('Bearer ')) return j({error: 'sign in first'}, 401);
  const sb = createClient(process.env.SUPABASE_URL, process.env.SUPABASE_ANON_KEY, {global: {headers: {Authorization: auth}}});
  const url = new URL(req.url);
  const status = (url.searchParams.get('status') || 'new,reviewed').split(',');
  const {data, error} = await sb.from('mb_signal').select('*').in('status', status)
    .order('score', {ascending: false}).order('occurred_on', {ascending: false}).limit(200);
  if (error) return j({error: error.message}, 400);
  return j(data);
};
export const config = {path: '/api/signals'};
