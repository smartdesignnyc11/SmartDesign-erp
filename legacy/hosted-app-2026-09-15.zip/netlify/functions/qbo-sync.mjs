// The daily pull from QuickBooks, before anyone opens the app: purchases and deposits become ledger
// lines in the txns collection (never twice — keyed qbo:<Id>), and the pull stamp lands on the company
// collection so the app's plugin row shows it. Invoice payments are left for the app (it knows its
// clients); it applies them from the same pull on next open.
import { admin, json } from './lib/nyc.mjs';
import { accessToken, pull } from './lib/qbo.mjs';
const WS = () => process.env.WORKSPACE_ID || 'default';
const acctFor = (accounts, name) => { const n = String(name || '').trim().toLowerCase(); if (!n) return null; const A = accounts || []; return A.find(a => String(a.name || '').toLowerCase() === n) || A.find(a => String(a.name || '').toLowerCase().includes(n) || n.includes(String(a.name || '').toLowerCase())) || null; };
export function applyTxns(txns, accounts, j){ let n = 0;
  (j.purchases || []).forEach(x => { const id = 'qbo:' + x.id; if (txns.some(t => t.id === id || t.extId === id)) return; const acct = acctFor(accounts, x.account) || (/credit ?card/i.test(x.method || '') ? (accounts || []).find(a => a.type === 'card') : null); txns.push({id, date: x.date, acct: acct ? acct.id : '', qboAccount: x.account || '', needsAccount: !acct, desc: x.desc || x.vendor || 'QuickBooks purchase', amt: -Math.abs(+x.amount || 0), cat: 'uncat', projectId: '', code: '', vendor: x.vendor || '', memo: x.memo || '', receipt: '', status: 'new', actor: '', source: 'quickbooks', line: '', qty: '', unit: '', extId: id}); n++; });
  (j.deposits || []).forEach(x => { const id = 'qbo:' + x.id; if (txns.some(t => t.id === id || t.extId === id)) return; const acct = acctFor(accounts, x.account) || (accounts || []).find(a => a.type === 'bank') || null; txns.push({id, date: x.date, acct: acct ? acct.id : '', qboAccount: x.account || '', needsAccount: !acct, desc: x.desc || 'QuickBooks deposit', amt: Math.abs(+x.amount || 0), cat: 'income', projectId: '', code: '', vendor: '', memo: x.memo || '', receipt: '', status: 'new', actor: '', source: 'quickbooks', line: '', qty: '', unit: '', extId: id}); n++; });
  return n; }
// a guarded write: only if the row is still at the version we read; otherwise the app wrote meanwhile and the next run picks it up
export async function writeIfUnchanged(sb, ws, name, data, version){ const now = new Date().toISOString(); if (version){ const {data: rows, error} = await sb.from('collections').update({data, version: version + 1, updated_at: now}).eq('workspace_id', ws).eq('name', name).eq('version', version).select('name'); if (error) throw new Error(`write ${name}: ${error.message}`); return (rows || []).length > 0; } const {error} = await sb.from('collections').upsert({workspace_id: ws, name, data, version: 1, updated_at: now}, {onConflict: 'workspace_id,name'}); if (error) throw new Error(`write ${name}: ${error.message}`); return true; }
export async function run(){
  const tok = await accessToken(); if (!tok) return {skipped: 'QuickBooks not connected'};
  const sb = admin(); const {data: rows, error} = await sb.from('collections').select('name,data,version').eq('workspace_id', WS()).in('name', ['txns', 'accounts', 'company']);
  if (error) throw new Error(`collections: ${error.message}`);
  const R = Object.fromEntries((rows || []).map(r => [r.name, r])); const company = (R.company && R.company.data) || {}; const since = (company.qboLast && company.qboLast.through) || new Date(Date.now() - 30 * 864e5).toISOString().slice(0, 10);
  const j = await pull(tok, since); const txns = (R.txns && R.txns.data) || []; const n = applyTxns(txns, (R.accounts && R.accounts.data) || [], j);
  company.qboLast = {at: j.through, txns: n, paid: 0, through: j.through, pendingInvoices: j.invoices.filter(x => x.paid > 0)}; company.plugins = company.plugins || {}; company.plugins.quickbooks = Object.assign({approval: {}}, company.plugins.quickbooks || {}, {connected: true});
  const now = new Date().toISOString();
  const {error: werr} = await sb.from('collections').upsert([{workspace_id: WS(), name: 'txns', data: txns, version: ((R.txns && R.txns.version) || 0) + 1, updated_at: now}, {workspace_id: WS(), name: 'company', data: company, version: ((R.company && R.company.version) || 0) + 1, updated_at: now}], {onConflict: 'workspace_id,name'}); if (werr) throw new Error(`write: ${werr.message}`);
  return {txns: n, invoices: j.invoices.length, through: j.through};
}
export default async () => { try { const out = await run(); console.log('qbo-sync', JSON.stringify(out)); return json(out); } catch(e){ console.error('qbo-sync', e.message); return json({error: e.message}, 500); } };
