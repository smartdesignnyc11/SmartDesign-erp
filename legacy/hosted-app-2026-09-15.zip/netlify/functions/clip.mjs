// The clipper's landing point.
//
//   POST /api/clip   — the browser extension sends what it read from the page the designer had open.
//   GET  /api/clip?url=…  — the fallback for a phone or a link someone texted: the server fetches the
//                           page itself. Honest about the limit: several vendors refuse a request from
//                           a data centre, and when that happens this says so instead of returning a
//                           half-empty record that looks like a real one.
//
// Nothing is crawled. One page, because a person asked for that page.
import { fromJsonLd, fromMeta, fromItemprop, fromSpecTable, docsFrom, mergeCapture, normalizeUrl, vendorOf, num, clean } from '../../extension/lib/extract.mjs';
import { admin, json } from './lib/nyc.mjs';
import crypto from 'node:crypto';

const UA = 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Safari/537.36';

/* ---------- a very small HTML reader ----------
   Not a DOM. It only needs the four machine-readable layers, and those are all attribute-shaped. */
function scrapeParts(html){
  const jsonld = [...html.matchAll(/<script[^>]+type=["']application\/ld\+json["'][^>]*>([\s\S]*?)<\/script>/gi)].map(m => m[1]).slice(0, 30);
  const metas = [...html.matchAll(/<meta\b([^>]*)>/gi)].map(m => {
    const at = m[1];
    const g = k => (at.match(new RegExp(k + '\\s*=\\s*["\']([^"\']*)["\']', 'i')) || [])[1] || '';
    return {property: g('property'), name: g('name'), content: g('content')};
  }).filter(m => m.content);
  const props = [...html.matchAll(/<([a-z0-9]+)\b([^>]*itemprop\s*=\s*["']([^"']+)["'][^>]*)>([\s\S]{0,300}?)<\/\1>/gi)].slice(0, 400).map(m => {
    const content = (m[2].match(/content\s*=\s*["']([^"']*)["']/i) || [])[1];
    return {prop: m[3], value: content != null ? content : clean(m[4].replace(/<[^>]+>/g, ' '))};
  });
  const pairs = [];
  for (const m of html.matchAll(/<tr[^>]*>\s*<t[hd][^>]*>([\s\S]{0,120}?)<\/t[hd]>\s*<t[hd][^>]*>([\s\S]{0,240}?)<\/t[hd]>\s*<\/tr>/gi))
    pairs.push([clean(m[1].replace(/<[^>]+>/g, ' ')), clean(m[2].replace(/<[^>]+>/g, ' '))]);
  for (const m of html.matchAll(/<dt[^>]*>([\s\S]{0,120}?)<\/dt>\s*<dd[^>]*>([\s\S]{0,240}?)<\/dd>/gi))
    pairs.push([clean(m[1].replace(/<[^>]+>/g, ' ')), clean(m[2].replace(/<[^>]+>/g, ' '))]);
  const links = [...html.matchAll(/<a\b[^>]*href\s*=\s*["']([^"']+)["'][^>]*>([\s\S]{0,120}?)<\/a>/gi)]
    .map(m => ({href: m[1], text: clean(m[2].replace(/<[^>]+>/g, ' '))})).slice(0, 600);
  const h1 = clean(((html.match(/<h1[^>]*>([\s\S]{0,300}?)<\/h1>/i) || [])[1] || '').replace(/<[^>]+>/g, ' '));
  const text = clean(html.replace(/<script[\s\S]*?<\/script>/gi, ' ').replace(/<style[\s\S]*?<\/style>/gi, ' ').replace(/<[^>]+>/g, ' ')).slice(0, 12000);
  return {jsonld, metas, props, pairs, links, h1, text};
}

export function readCapture(capture){
  const parts = {
    jsonld: fromJsonLd(capture.jsonld),
    meta: fromMeta(capture.metas),
    microdata: fromItemprop(capture.props),
    spec: fromSpecTable(capture.pairs),
    page: {title: clean(capture.h1 || capture.title), price: num(capture.priceText), images: capture.images || [], docs: docsFrom(capture.links)},
  };
  return mergeCapture(parts, capture.url, capture.text);
}

async function fetchAndRead(url){
  const r = await fetch(url, {headers: {'User-Agent': UA, Accept: 'text/html,application/xhtml+xml', 'Accept-Language': 'en-US,en;q=0.9'}, redirect: 'follow'});
  if (!r.ok){
    const why = r.status === 403 || r.status === 429 ? 'refused' : 'failed';
    const e = new Error(`The vendor ${why} the request (HTTP ${r.status}). Several sites answer a browser and refuse a server — open the page in Chrome and use the clipper button there.`);
    e.blocked = r.status === 403 || r.status === 429;
    throw e;
  }
  const html = await r.text();
  const c = scrapeParts(html);
  c.url = r.url || url;
  const clip = readCapture(c);
  // A page that rendered entirely in JavaScript gives back a shell. Say so rather than filing a husk.
  if (!clip.title && !clip.sku && !clip.price){
    const e = new Error('The page came back with nothing readable — it builds itself in the browser. Use the clipper button on the open page.');
    e.blocked = true;
    throw e;
  }
  return clip;
}

/* ---------- normalisation ---------- */
// The AI's only job is to tidy what was read. It is never asked to supply a fact the page did not carry:
// an invented SKU is worse than a blank one, because a blank one gets flagged.
async function tidy(clip){
  const key = process.env.ANTHROPIC_API_KEY;
  if (!key || (clip.title && clip.sku && clip.finish)) return clip;
  try {
    const r = await fetch('https://api.anthropic.com/v1/messages', {
      method: 'POST',
      headers: {'content-type': 'application/json', 'x-api-key': key, 'anthropic-version': '2023-06-01'},
      body: JSON.stringify({
        model: process.env.ANTHROPIC_MODEL || 'claude-sonnet-4-5',
        max_tokens: 600,
        messages: [{role: 'user', content: `Tidy this product capture from a building-materials vendor page into clean fields. Use ONLY what is present in the capture — never infer, complete or invent a value that is not there; leave it empty instead, because an empty field is flagged downstream and a wrong one is not.
CAPTURE: ${JSON.stringify({title: clip.title, desc: (clip.desc || '').slice(0, 900), specs: clip.specs, sku: clip.sku, brand: clip.brand, finish: clip.finish, dims: clip.dims, price: clip.price})}
Reply ONLY as JSON: {"title":"","brand":"","sku":"","finish":"","dims":"","category":"","components":["parts sold separately that this product needs, only if the capture says so"]}`}],
      }),
    });
    if (!r.ok) return clip;
    const j = await r.json();
    const txt = (j.content || []).map(c => c.text || '').join('');
    const o = JSON.parse(txt.replace(/^[^{]*/, '').replace(/[^}]*$/, ''));
    ['title', 'brand', 'sku', 'finish', 'dims'].forEach(k => { if (!clip[k] && o[k]){ clip[k] = o[k]; clip.source[k] = 'tidied'; } });
    if (o.category) clip.category = o.category;
    if (Array.isArray(o.components) && o.components.length) clip.components = o.components;
    clip.missing = ['sku', 'price', 'finish', 'dims'].filter(k => !clip[k]);
  } catch (e){ /* tidying is optional; the raw read still stands */ }
  return clip;
}

/* ---------- who is clipping ----------
   The board issues a token, shows it once and keeps only its hash. Here we hash what arrived and look
   for the row. An unknown or revoked token is refused; a valid one names the person, so the clip is
   attributable rather than anonymous. If no tokens have been issued yet the door is open, because a
   fresh install with nobody able to clip is a worse failure than an open one on an unpublished URL —
   set CLIP_REQUIRE_TOKEN=1 to close it. */
async function whoIsClipping(req, sb){
  const sent = (req.headers.get('authorization') || '').replace(/^Bearer\s+/i, '').trim()
            || new URL(req.url).searchParams.get('token') || '';
  if (!sb) return {name: '', open: true};
  const {count} = await sb.from('sel_token').select('id', {count: 'exact', head: true}).is('revoked_at', null);
  const strict = process.env.CLIP_REQUIRE_TOKEN === '1';
  if (!count && !strict) return {name: '', open: true, note: 'no tokens issued yet — anyone with the address can clip'};
  if (!sent) return {error: 'This board needs a clipper token. Issue one in Procurement → Clipper access.'};
  const hash = crypto.createHash('sha256').update(sent).digest('hex');
  const {data} = await sb.from('sel_token').select('id,name,revoked_at').eq('hash', hash).maybeSingle();
  if (!data) return {error: 'That clipper token is not recognised.'};
  if (data.revoked_at) return {error: `That token was revoked on ${String(data.revoked_at).slice(0, 10)}.`};
  sb.from('sel_token').update({used_at: new Date().toISOString()}).eq('id', data.id).then(() => {}, () => {});
  return {name: data.name, id: data.id};
}

export default async (req) => {
  const url = new URL(req.url);

  if (req.method === 'GET'){
    const target = url.searchParams.get('url');
    if (!target) return json({error: 'pass ?url='}, 400);
    try {
      const clip = await tidy(await fetchAndRead(normalizeUrl(target)));
      return json({ok: true, via: 'server-fetch', clip});
    } catch (e){
      return json({error: e.message, blocked: !!e.blocked, url: normalizeUrl(target)}, e.blocked ? 422 : 502);
    }
  }

  if (req.method !== 'POST') return json({error: 'POST a capture, or GET with ?url='}, 405);

  let body; try { body = await req.json(); } catch (e){ return json({error: 'expected JSON'}, 400); }
  let clip = body.clip;
  if (!clip && body.capture) clip = readCapture(body.capture);
  if (!clip && body.url){ try { clip = await fetchAndRead(normalizeUrl(body.url)); } catch (e){ return json({error: e.message, blocked: !!e.blocked}, 422); } }
  if (!clip) return json({error: 'nothing to clip — send clip, capture or url'}, 400);
  clip = await tidy(clip);

  let sb; try { sb = admin(); } catch (e){ return json({ok: true, stored: false, note: e.message, clip}); }

  const who = await whoIsClipping(req, sb).catch(() => ({name: '', open: true}));
  if (who.error) return json({error: who.error}, 401);

  const row = {
    workspace_id: body.workspace || process.env.WORKSPACE_ID || 'default',
    project_id: body.projectId || '',
    room: body.room || '', fm: body.fm || '',
    qty: Number(body.qty) > 0 ? Number(body.qty) : 1,
    need_on_site: body.needOnSite || null,
    url: clip.url, vendor: clip.vendor || vendorOf(clip.url),
    clip, status: 'new', created_by: who.name || body.by || '',
  };
  const {data, error} = await sb.from('sel_clip').upsert(row, {onConflict: 'workspace_id,project_id,url', ignoreDuplicates: false}).select('id').maybeSingle();
  if (error) return json({error: error.message, clip}, 500);
  return json({ok: true, stored: true, id: data?.id || null, by: who.name || null, note: who.note, clip});
};

export const config = {path: '/api/clip'};
