// The board pulls new clips from here, as the signed-in user, so row-level security decides what comes back.
// Claiming a clip marks it taken, so two people opening the board do not both create the same item.
import { createClient } from '@supabase/supabase-js';

const j = (b, s = 200) => new Response(JSON.stringify(b), {status: s, headers: {'content-type': 'application/json'}});

export default async (req) => {
  const auth = req.headers.get('authorization') || '';
  if (!auth.startsWith('Bearer ')) return j({error: 'sign in first'}, 401);
  const sb = createClient(process.env.SUPABASE_URL, process.env.SUPABASE_ANON_KEY, {global: {headers: {Authorization: auth}}});
  const url = new URL(req.url);

  if (req.method === 'POST'){
    let b; try { b = await req.json(); } catch (e){ return j({error: 'expected JSON'}, 400); }
    const ids = [].concat(b.ids || []).filter(Boolean);
    if (!ids.length) return j({error: 'pass ids'}, 400);
    const {error} = await sb.from('sel_clip').update({status: b.status || 'taken', taken_at: new Date().toISOString()}).in('id', ids);
    if (error) return j({error: error.message}, 400);
    return j({ok: true, claimed: ids.length});
  }

  let q = sb.from('sel_clip').select('*').eq('status', url.searchParams.get('status') || 'new').order('created_at', {ascending: true}).limit(100);
  const pid = url.searchParams.get('projectId');
  if (pid) q = q.eq('project_id', pid);
  const {data, error} = await q;
  if (error) return j({error: error.message}, 400);
  return j(data || []);
};

export const config = {path: '/api/clips'};
